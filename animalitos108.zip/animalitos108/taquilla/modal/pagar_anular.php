	<?php
		if (isset($con))
		{
	?>
	<!-- Modal -->
	<div class="modal fade" id="myModalPagar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel"> Pagar Ticket</h4>
		  </div>
		  <div class="modal-body">
			<form class="form-horizontal" method="post" id="pagar_ticket" name="pagar_ticket">
			
			<div id="form">
			  <div class="form-group">
				<label for="user_password_new3" class="col-sm-4 control-label">Nro Ticket</label>
				<div class="col-sm-4">
				  <input type="text" class="form-control" id="ticket" name="ticket" placeholder="Nro Ticket" pattern=".{1,}" title="Nro Ticket" required>
  				</div>
			  </div>
			  <div class="form-group">
				<label for="user_password_repeat3" class="col-sm-4 control-label">Nro Serial</label>
				<div class="col-sm-4">
				  <input type="text" class="form-control" id="serial" name="serial" placeholder="Nro Serial" pattern=".{6,}" required>
				</div>
			  </div>
			  </div>   
		  </div>
		  <div id="resultados_ajax3"></div> 
		  <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
			<button type="submit" class="btn btn-primary" id="btnpagar">Buscar Ticket</button>
		  </div>
		  </form>
		</div>
	  </div>
	</div>

	<div class="modal fade" id="myModalAnular" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel"> Anular Ticket</h4>
		  </div>
		  <div class="modal-body">
			<form class="form-horizontal" method="post" id="anular_ticket" name="anular_ticket"> 
			<div id="resultados_ajax2"></div>
			 
			  <div class="form-group">
				<label for="user_password_new3" class="col-sm-4 control-label">Nro Ticket</label>
				<div class="col-sm-4">
				  <input type="text" class="form-control" id="ticket" name="ticket" placeholder="Nro Ticket" pattern=".{1,}" title="Nro Ticket" required>
  				</div>
			  </div>
			  <div class="form-group">
				<label for="user_password_repeat3" class="col-sm-4 control-label">Nro Serial</label>
				<div class="col-sm-4">
				  <input type="text" class="form-control" id="serial" name="serial" placeholder="Nro Serial" pattern=".{6,}" required>
				</div>
			  </div>
			
			
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
			<button type="submit" class="btn btn-primary" id="btnanular">Anular Ticket</button>
		  </div>
		  </form>
		</div>
	  </div>
	</div>
	<?php
		}
	?>	