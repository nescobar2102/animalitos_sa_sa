<?php
include('is_logged.php'); //Archivo verifica que el usario que intenta acceder a la URL esta logueado
/* Connect To Database */
require_once ("../config/db.php"); //Contiene las variables de configuracion para conectar a la base de datos
require_once ("../config/conexion.php"); //Contiene funcion que conecta a la base de datos

$action = (isset($_REQUEST['action']) && $_REQUEST['action'] != NULL) ? $_REQUEST['action'] : '';
if ($action == 'ajax') {
    $id_tipo = intval($_GET['q']);
    $id_vendedor = $_SESSION['user_id'];
 ini_set('date.timezone','America/Caracas'); 
    $hora= date('H:i:s');

   $sql_producto = mysqli_query($con, "select * from products where status_producto='1' and tipo='2' and id_tipo='$id_tipo' and hora_inicio<='$hora' and hora_cierre>='$hora'");
 
    ?>

    <div class="col-md-3">
        <div id="div1">
            <form id="ruleta" action="">
                <table  class="table table-striped">
                             <tbody>
                        <?php
                        while ($row = mysqli_fetch_array($sql_producto)) {
                            $id_producto = $row['id_producto'];
                            $codigo_producto = $row['codigo_producto'];
                            $nombre_producto = $row['nombre_producto'];
                            ?>                 

                            <tr>
                                <td><input type="checkbox" id="id[]"value="<?php echo $id_producto; ?>"  onClick="imprimirValor(<?= $id_producto;?>,'<?= $nombre_producto;?>')"><?php echo $nombre_producto; ?></td>

                            </tr>              
    <?php } ?>
                    </tbody>
                </table>
            </form>
        </div>
    </div>
    <?php
}
?>
        
