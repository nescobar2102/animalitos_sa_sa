<?php
include('is_logged.php'); //Archivo verifica que el usario que intenta acceder a la URL esta logueado
/* Connect To Database */
require_once ("../config/db.php"); //Contiene las variables de configuracion para conectar a la base de datos
require_once ("../config/conexion.php"); //Contiene funcion que conecta a la base de datos

$action = (isset($_REQUEST['action']) && $_REQUEST['action'] != NULL) ? $_REQUEST['action'] : '';
if ($action == 'ajax') {
    $id_tipo = intval($_GET['q']);
    $id_vendedor = $_SESSION['user_id'];
    ini_set('date.timezone','America/Caracas'); 
    $hora = date('H:m:s');
    $num_permitidos = array();
    $sql_ruleta = mysqli_query($con, "select id,nombre,color,ruta_img from ruleta where status='1' and id_tipo_ruleta='$id_tipo'");
    ?>                    
            <div class="row" >                  
                <?php
                $cant = 0;
                while ($row = mysqli_fetch_array($sql_ruleta)) {
                    $id_ruleta = $row['id'];
                    $nombre = $row['nombre'];
                    $color = $row['color'];
                    $img = $row['ruta_img'];
                    $cant = $cant + 1;
                    array_push($num_permitidos,$nombre);
                    ?>      
              <div class="col-md-2 div_ruleta" 
                    style="
                        position: relative;
                        background-image: url('img/ruleta/<?= $img ?>');
                        background-size: contain;
                        background-position: center;
                        background-repeat: no-repeat;
                        height: 200px;
                        color: white;
                        text-align: center;
                        padding-top: 10px;
                        border: 1px solid #ccc;
                        cursor: pointer;
                    "
                    onclick="toggleCheckbox(this,'<?= $nombre;?>')">

                    <input type="checkbox" name="ruleta[]" 
                        onclick="imprimirValorRuleta('<?= $nombre;?>')" 
                        style="position: relative; z-index: 2;" />
                    <br>
                    <span style="color: darkgoldenrod; position: relative; z-index: 2;">
                        <?= $nombre; ?>
                    </span>
                </div>
                    <?php if ($cant % 6 == 0) { ?>
                </div>            
                    <br>
                <div class="row">
                    <?php }
                }
                $string = implode(",",$num_permitidos);                
                ?>
                 <input  type="hidden"  name="num_permitido"  id="num_permitido" value="<?= $string ?>" /><br> 
            </div>        
    
<?php } ?>



