<?php
include('is_logged.php');//Archivo verifica que el usario que intenta acceder a la URL esta logueado
$session_id= session_id();
 
	/* Connect To Database*/
	require_once ("../config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
	require_once ("../config/conexion.php");//Contiene funcion que conecta a la base de datos
	//Archivo de funciones PHP
	include("../funciones.php");

$delete=mysqli_query($con,"DELETE FROM tmp WHERE session_id='".$session_id."'");
?>
<div id="venta">
<table class="table">
<tr>
 
</tr>
<?php
	$sumador_total=0;
	$sql=mysqli_query($con, "select * from products, tmp,signo,jugada where products.id_producto=tmp.id_producto and signo.id=tmp.signo  and jugada.id=tmp.jugada  and tmp.session_id='".$session_id."' order by id_tmp asc");
	while ($row=mysqli_fetch_array($sql))
	{
	$id_tmp=$row["id_tmp"];
	$codigo_producto=$row['codigo_producto'];
	$cantidad=$row['cantidad_tmp'];
	$nombre_producto=$row['nombre_producto'];
	$signo=$row['nombre'];
     	
	$precio_venta=$row['precio_tmp'];
	$precio_venta_f=number_format($precio_venta,2);//Formateo variables
	$precio_venta_r=str_replace(",","",$precio_venta_f);//Reemplazo las comas
	$precio_total=$precio_venta_r*$cantidad;
	$precio_total_f=number_format($precio_total,2);//Precio total formateado
	$precio_total_r=str_replace(",","",$precio_total_f);//Reemplazo las comas
	$sumador_total+=$precio_venta_r;//Sumador
	
		?>
		<tr> 
                        <td><?php echo $nombre_producto ;?></td>
                        <td class='text-center'><?php echo $signo;?></td>
			<td class='text-center'><?php echo $cantidad;?></td>			
			<td class='text-right'><?php echo $precio_venta_f;?></td>
			<td class='text-center'><a href="#" onclick="eliminar('<?php echo $id_tmp ?>')"><i class="glyphicon glyphicon-trash"></i></a></td>
		</tr>		
		<?php
	}
	$impuesto=get_row('perfil','impuesto', 'id_perfil', 1);
	$subtotal=number_format($sumador_total,2,'.','');
	$total_iva=($subtotal * $impuesto )/100;
	$total_iva=number_format($total_iva,2,'.','');
	$total_factura=$subtotal+$total_iva;

?>
<tr>
<!--	<td class='text-center' colspan=3>TOTAL <?php //echo $simbolo_moneda;?></td>-->
<!--	<td class='text-center'><?php //echo number_format($subtotal,2);?></td>-->
	<td></td>
</tr>


</table>
</div>