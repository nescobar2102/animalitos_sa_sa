<?php
	/*-------------------------
        Descripcion:Sistema de Venta y Control de juegos de azar
	Autor: Ing .Norbelys Naguanagua	 
	Mail: norbelysnaguanagua21@gmail.com
        Version: 1.0       
	---------------------------*/
	include('is_logged.php');//Archivo verifica que el usario que intenta acceder a la URL esta logueado
	/* Connect To Database*/
	require_once ("../config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
	require_once ("../config/conexion.php");//Contiene funcion que conecta a la base de datos
	
	$action = (isset($_REQUEST['action'])&& $_REQUEST['action'] !=NULL)?$_REQUEST['action']:'';
	if (isset($_GET['id'])){
          
	}
            if($action == 'ajax'){
                 $id_vendedor=$_SESSION['user_id'];
                    // escaping, additionally removing everything that could be (html/javascript-) code
                $q = mysqli_real_escape_string($con,(strip_tags($_REQUEST['q'], ENT_QUOTES)));
                $p = mysqli_real_escape_string($con,(strip_tags($_REQUEST['p'], ENT_QUOTES)) );
                $tipo = mysqli_real_escape_string($con,(strip_tags($_REQUEST['tipo'], ENT_QUOTES)));
              
		include 'pagination.php'; //include pagination file
		//pagination variables
		$page = (isset($_REQUEST['page']) && !empty($_REQUEST['page']))?$_REQUEST['page']:1;
		$per_page = 10; //how much records you want to show
		$adjacents  = 4; //gap between pages after number of adjacents
		$offset = ($page - 1) * $per_page;
		//Count the total number of row in your table*/
	    $count_query   = mysqli_query($con, " SELECT count(*) AS numrows 
						FROM 
							facturas f
						JOIN 
							users u ON f.id_vendedor = u.user_id
						JOIN 
							comisiones c ON u.user_id = c.pago_id_vendedor and f.id_moneda =c.id_moneda 
						JOIN 
							currencies cu ON f.id_moneda = cu.id
						WHERE 
							u.user_id = '$id_vendedor' 
							AND f.estado_factura IN (1, 2, 3) 
							AND f.fecha_factura BETWEEN '$q' AND '$p' 
						GROUP BY 
							f.id_moneda, f.id_vendedor
						LIMIT 0, 10;");
		$row= mysqli_fetch_array($count_query); 
			if ($row) {
				$numrows = $row['numrows'];
			} else {
				$numrows = 0; // O cualquier valor por defecto que quieras usar
			}
		$total_pages = ceil($numrows/$per_page);
		$reload = './facturas.php';
		//main query to fetch the data
                if($tipo==1){
                    $tipo_comision="comision_triple";
                }else{
                   $tipo_comision="comision_terminal";
                }
		
					  $sql=" SELECT 
								f.id_vendedor,
								SUM(f.total_venta) AS ventas,
								SUM(f.premio) AS premios,
								SUM(f.total_venta * c.comision_triple / 100) AS comision,
								cu.symbol
							FROM 
								facturas f
							JOIN 
								users u ON f.id_vendedor = u.user_id
							JOIN 
								comisiones c ON u.user_id = c.pago_id_vendedor and f.id_moneda =c.id_moneda 
							JOIN 
								currencies cu ON f.id_moneda = cu.id
							WHERE 
								u.user_id ='$id_vendedor' 
								AND f.estado_factura IN (1, 2, 3) 
								AND f.fecha_factura BETWEEN '$q' AND '$p' 
							GROUP BY 
								f.id_moneda, f.id_vendedor
							LIMIT 0, 10;" ;
	 
		$query = mysqli_query($con, $sql);
                
		//loop through fetched data
		if ($numrows>0){
			echo mysqli_error($con);
			?>
			<div class="table-responsive">
			  <table class="table">
				<tr  class="info">
					<th>ID</th>
					<th>Nombre</th>					
					<th>Ventas</th>
					<th>Premios</th>
                    <th>Comision</th>					
					<th>Participacion</th>
					<th>Total</th>
                    <th> </th>
				</tr>
				<?php
					
					$ventast=0;
					$premiost=0;
					$comisiont=0;
					$particit=0;
					$total_venta =0;
				while ($row=mysqli_fetch_array($query)){
						$id_vendedor=$row['id_vendedor'];
						$ventas=$row['ventas'];
						$premios=$row['premios'];
						$comision=$row['comision'];		
						$symbol=$row['symbol'];					 
				$sql1="select * from users where user_id=$id_vendedor"; 
				$query1 = mysqli_query($con, $sql1);
                                 $row1= mysqli_fetch_array($query1);
                                  $user_name=$row1['user_name'];
                                    $totall=$ventas-$premios-$comision-$particit;
					?>
					<tr>
						<td><?php echo $id_vendedor; ?></td>
						<td><?php echo $user_name; ?></td>
						<td><?php echo number_format ($ventas,2);  ?></td>						 
						<td><?php echo number_format ($premios,2);   ?></td>
						<td><?php echo number_format ($comision,2);   ?></td>	
						<td><?php echo number_format ($particit,2);  ?></td>	
						<td><?php echo number_format ($totall,2);  ?></td>	
                                      
					</tr>
					<?php
						
					    $ventast=+$ventas;
				 	    $premiost=+$premios;
						$comisiont=+$comision;
						$particit=+$particit;
						$total_venta=$total_venta+$totall;
                                           
                                }
                     ?>
                                       
				<tr>
					<td colspan=8><span class="pull-right"><?php
					 echo paginate($reload, $page, $total_pages, $adjacents);
					?></span></td>
				</tr>
                 				
					<th><?php echo number_format ($ventast,2); ?></th>
					<th><?php echo number_format ($premiost,2); ?></th>
                    <th><?php echo number_format ($comisiont,2); ?></th>					
					<th><?php echo number_format ($particit,2); ?></th>
					<th><?php echo number_format ($total_venta,2); ?></th>
                    <th></th>					 
					
				</tr-->
			  </table>
			</div>
			<?php
		}else{ ?>
              
            <div class="alert alert-success alert-dismissible" role="alert">
			  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			  <strong>Aviso!</strong> No existen ventas  para la fecha seleccionada.
			</div>
               <?php } 
	}
?>