<?php
	/*-------------------------
        Descripcion:Sistema de Venta y Control de juegos de azar
		Autor: Ing .Norbelys Naguanagua	 
		Mail: norbelysnaguanagua21@gmail.com
        Version: 1.1       
	---------------------------*/
	include('is_logged.php');//Archivo verifica que el usario que intenta acceder a la URL esta logueado
	/* Connect To Database*/
	require_once ("../config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
	require_once ("../config/conexion.php");//Contiene funcion que conecta a la base de datos
	
	$action = (isset($_REQUEST['action'])&& $_REQUEST['action'] !=NULL)?$_REQUEST['action']:'';

	if($action == 'ajax'){
		// escaping, additionally removing everything that could be (html/javascript-) code
         $q = mysqli_real_escape_string($con,(strip_tags($_REQUEST['q'], ENT_QUOTES)));
		$sTable = "resultados";
		 $sWhere = "";
		if ( $_GET['q'] != "" )
		{
		$sWhere.= " where numero='$_GET[q]'";
			
		}
		
		$sWhere.=" order by resultados.id desc";
		include 'pagination.php'; //include pagination file
		//pagination variables
		$page = (isset($_REQUEST['page']) && !empty($_REQUEST['page']))?$_REQUEST['page']:1;
		$per_page = 10; //how much records you want to show
		$adjacents  = 4; //gap between pages after number of adjacents
		$offset = ($page - 1) * $per_page;
		//Count the total number of row in your table*/
		$count_query   = mysqli_query($con, "SELECT count(*) AS numrows FROM $sTable  $sWhere");
		$row= mysqli_fetch_array($count_query);
		$numrows = $row['numrows'];
		$total_pages = ceil($numrows/$per_page);
		$reload = './resultados.php';
		//main query to fetch the data
		  $sql="SELECT * FROM  $sTable $sWhere LIMIT $offset,$per_page";
		$query = mysqli_query($con, $sql);
		//loop through fetched data
		if ($numrows>0){
			echo mysqli_error($con);
			?>
			<div class="table-responsive">
			  <table class="table">
				<tr  class="info">     
					<th>Loteria </th>
					<th>Signo </th>
					<th>Número Sorteado</th>
					<th>Fecha del Sorteo</th>
				</tr>
				<?php
				while ($row=mysqli_fetch_array($query)){
						$id_loteria=$row['id_loteria'];
                        $id_signo=$row['id_signo'];
						$numero=$row['numero'];
						$fecha=$row['fecha_sorteo'];

							$sqlj="select * from products where id_producto='$id_loteria'";
								$queryj=mysqli_query($con, $sqlj);
								
							$sqlsig="select * from signo where id='$id_signo'";
								$querysig=mysqli_query($con, $sqlsig);
								?>
					<tr>
                                            <td>	
						 <?php while ($rowj=mysqli_fetch_array($queryj)){
                                               echo "<option  value='".$rowj["nombre_producto"]."'>".$rowj["nombre_producto"]."</option>"; }
                                               ?>
                                            </td>
                                             <td>	
						  <?php while ($row=mysqli_fetch_array($querysig)){
                                               echo "<option  value='".$row["nombre"]."'>".$row["nombre"]."</option>"; }
                                               ?>
                                            </td>
                                            <td class='text'><?php echo $numero; ?></td>	
                                            <td><?php echo $fecha; ?></td>						
											
					</tr>
					<?php
                                            }
                                        ?>
				<tr>
					<td colspan=7><span class="pull-right"><?php
					 echo paginate($reload, $page, $total_pages, $adjacents);
					?></span></td>
				</tr>
			  </table>
			</div>
			<?php
		}
	}
?>