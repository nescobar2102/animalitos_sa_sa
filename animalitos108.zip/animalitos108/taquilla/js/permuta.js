
function permuta (cad_I, cad_D) 

{

  if (cad_D.length == 1)
  {
  document.write(++conta + " = " + cad_I + cad_D + "<br>");
  return;
  }

  for (var i =0; i < cad_D.length ; i++) 
  {
  permuta (cad_I + cad_D.charAt(i), cad_D.replace(cad_D.charAt(i),""));
  } return;

}

function inicia_per(id) 

{
    var num=document.getElementById('cantidad_'+id).value;
   
  conta =0;
  cadena =num;
  permuta ("",cadena);
}


 function serie(numero,monto)

        {
            var total=0;
            for(var i=0; i < 10;i++)

            { 
                          serie=+i+""+numero;
                          

            }
            return  serie;

        }

