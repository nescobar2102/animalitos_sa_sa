let parameters_tri = []
function removeElement(event, position) {
    event.target.parentElement.remove()
    delete parameters_tri[position]
    recorrerTicket();    
}

const addJsonElement = json => { 
    parameters_tri.push(json)
    return parameters_tri.length - 1
}

let monto_total = 0.00;
let  myArrayHorario =[];
let  myArrayNombre =[];
let  myArrayRuleta =[];
let  myArrayRuletaNum =[];
let $j=0;


function imprimirValorRuleta(numero) {
    const input = document.getElementById("cantidad"); // El input donde se guarda la jugada
    let valores = input.value.trim();

    // Convertir string en array para manejo
    let lista = valores ? valores.split("-").map(v => v.trim()) : [];

    const index = lista.indexOf(String(numero));

    if (index !== -1) {
        // Si ya existe, lo quitamos
        lista.splice(index, 1);
    } else {
        // Si no está, lo agregamos
        lista.push(String(numero));
    }

    // Actualizar el input con los valores actualizados
    input.value = lista.join("-");
    console.log("Jugadas actuales:", input.value);
}

function imprimirValor(id_sorteo,nombre ){
     var myIndex = myArray.indexOf(id_sorteo);
    if (myIndex !== -1) {
        myArray.splice(myIndex, 1);
    }else{
        console.log(myArray.push(id_sorteo))
    }

    var myIndexNombre = myArrayNombre.indexOf(nombre);
    if (myIndexNombre !== -1) {
        myArrayNombre.splice(myIndexNombre, 1);
    }else{
        console.log(myArrayNombre.push(nombre))
    } 

  }
 
  function recorrerTicket(){ 
       monto_total=0;
        $j= 0; 
       parameters_tri.forEach(function(preventa) { //loterias
        console.log(preventa.precio_venta);
        monto_total = monto_total+ parseFloat(preventa.precio_venta);
        $j++;
    }); 
   $("#monto_total").html('');     
   $("#monto_total").html('Total monto: ' + monto_total + ' VES ' );

   $("#total_jugada").html('Total Jugadas: ' +$j);
 
  }
  
 function borrar_todo() {
    monto_total = 0.00;
    parameters_tri = [];
    myArrayHorario =[];
    myArrayNombre =[];     
    myArrayRuletaNum=[];
    myHorario = [] ;
    myHorarioNombre = [];
    $j= 0; 
    $("#total_jugada").html('Total Jugadas: ' +$j);
    $("#monto_total").html('Total monto: ' + monto_total + ' VES ' );
    const $divElements = document.getElementById("divElements")
    $divElements.innerHTML = "";
    $(".outer_div1").html('');
    document.getElementById("frmUsers").reset();
      $('#horario').select2({
        placeholder: "",
        allowClear: true
    });
}

function buscar() {
   myHorario=[];
   myHorarioNombre =[];
   myArrayNombre =[];
   mySigno =[];
   mysignoNombre =[];
   myArrayRuletaNum=[];
   var id_tipr = $("#id_tipr").val();  
   $("#cantidad").val(''); 
   $("#precio_venta").val(''); 
   buscar1(id_tipr);
}

(function load(){ 
    const $divElements = document.getElementById("divElements")
    const $btnSave = document.getElementById("btnSave")
    const $btnAdd = document.getElementById("btnAdd")

    const templateElement = (data, position) => {       
        return (`       
         ${data}
        <img src="img/iconos/anular.png" width="20px" 
        title="Quitar Numero" onclick="removeElement(event, ${position})">   
    `)
    }

    $btnAdd.addEventListener("click", (event) => {
    let myHorario = [];
    let myHorarioNombre = [];

    // Recorre los checkboxes seleccionados en el contenedor de horarios
    $('#horario-checkboxes input[type="checkbox"]:checked').each(function () {
        const horarioId = $(this).val();
        const horarioNombre = $('label[for="' + $(this).attr('id') + '"]').text();

        myHorario.push(horarioId);
        myHorarioNombre.push(horarioNombre);
    });

    const inputValue = document.getElementById("num_permitido").value;
    let arr = inputValue.split(',');

    if ($("#precio_venta").val() !== "" && $("#cantidad").val() !== "") {
        let nameRuleta = $("#id_tipr").find("option:selected").text();
         let $i = 0;
         let $j = 0; 
         let $x = 0;
            myHorario.forEach(function (horario) {
                console.log("horario nuevo", horario);
                console.log("nombre horario", myHorarioNombre[$x]);
                var cantidad = $("#cantidad").val();
                    $j++; 
                     monto_total = monto_total+ parseFloat($("#precio_venta").val());

                    let index = addJsonElement({
                         precio_venta:$("#precio_venta").val(),
                        cantidad: cantidad,
                        loteria: nameRuleta,
                        tipo_loteria: $("#id_tipr").val(),
                        nombre: nameRuleta,
                        horario: horario,
                        nombre_horario: myHorarioNombre[$x]
                    });
 
                    const $div = document.createElement("div");
                    $div.classList.add("notification", "is-link", "is-light", "py-2", "my-1");
                    $div.innerHTML = templateElement(`${nameRuleta} -- ${myHorarioNombre[$x]} -- (${cantidad})-- ${$("#precio_venta").val()}`, index);
                    $divElements.insertBefore($div, $divElements.firstChild);
                    $x++;             
            });
            $i++;   

        $("#total_jugada").html('Total Jugadas: ' + $j);
        $("#monto_total").html('Total monto: ' + monto_total + ' VES');

    } else {
        alert("Complete los campos");
    }
});
 

    $btnSave.addEventListener("click", (event) =>{ 
        parameters_tri = parameters_tri.filter(el => el != null)
        const $jsonDiv = document.getElementById("jsonDiv")
        $jsonDiv.innerHTML = `JSON: ${JSON.stringify(parameters_tri)}`
        var id_vendedor =  $("#taquilla").val();
        $divElements.innerHTML = "";
        $.ajax({
            url: './ajax/script.php',
            type: 'GET',
            data: {"variable":parameters_tri},
            success: function(data, textStatus, xhr) {            
                VentanaCentrada('./pdf/documentos/imp_factura_tripleta.php?id_vendedor=' + id_vendedor, 'Factura', '', '1024', '768', 'true');
               }
            });
        parameters_tri = [];
        monto_total=0.00; 
        $("#monto_total").html('Total monto:'+monto_total+' VES'); 
     
    })
})()

function toggleCheckbox(div,nombre) {
    // Encuentra el checkbox dentro del div
    const checkbox = div.querySelector('input[type="checkbox"]');
    
    // Cambia el estado del checkbox
    checkbox.checked = !checkbox.checked;     
    imprimirValorRuleta(nombre);
    
}
