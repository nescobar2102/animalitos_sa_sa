 function premiar_t(id,s,p){

  var ticket=  $("#ticket").val();
  var serial=  $("#serial").val();

if (confirm("¿Desea pagar este ticket?")){
        
        $.ajax({
        type: "GET",
        url: "./ajax/pagar_ticket.php",                
        data: "id="+id+"&s="+s+"&p="+p+"&ticket="+ticket+"&serial="+serial,
        success: function(datos){
        console.log("---------", datos)
        }

});
    
        }
    }