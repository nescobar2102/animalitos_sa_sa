<?php
$resultado = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $jugada = [intval($_POST['jugada1']), intval($_POST['jugada2']), intval($_POST['jugada3'])];
    $sorteo = [intval($_POST['sorteo1']), intval($_POST['sorteo2']), intval($_POST['sorteo3'])];
    $monto = floatval($_POST['monto']); // Monto apostado
    $multiplicador = 600; // Premio por acertar tripleta exacta

    function validarTripleta($jugada, $sorteo) {
        return $jugada === $sorteo;
    }

    if (validarTripleta($jugada, $sorteo)) {
        $ganancia = $monto * $multiplicador;
        $resultado = "<strong style='color: green;'>¡Ganaste la tripleta!<br>Ganancia: Bs " . number_format($ganancia, 2) . "</strong>";
    } else {
        $resultado = "<strong style='color: red;'>No acertaste la tripleta. Perdiste Bs " . number_format($monto, 2) . "</strong>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Jugada Tripleta</title>
</head>
<body>
    <h2>Jugada Tripleta con Monto</h2>

    <form method="POST">
        <fieldset>
            <legend><strong>Tu Jugada</strong></legend>
            <label>Número 1:</label>
            <input type="number" name="jugada1" required><br>
            <label>Número 2:</label>
            <input type="number" name="jugada2" required><br>
            <label>Número 3:</label>
            <input type="number" name="jugada3" required><br>
            <label>Monto apostado (Bs):</label>
            <input type="number" name="monto" min="1" step="0.01" required><br>
        </fieldset>

        <fieldset>
            <legend><strong>Resultado del Sorteo</strong></legend>
            <label>1er lugar:</label>
            <input type="number" name="sorteo1" required><br>
            <label>2do lugar:</label>
            <input type="number" name="sorteo2" required><br>
            <label>3er lugar:</label>
            <input type="number" name="sorteo3" required><br>
        </fieldset>

        <br>
        <input type="submit" value="Verificar Tripleta">
    </form>

    <br>
    <?php if ($resultado): ?>
        <p><?php echo $resultado; ?></p>
    <?php endif; ?>
</body>
</html>
