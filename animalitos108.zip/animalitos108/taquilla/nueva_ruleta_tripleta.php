<?php

session_start();
if (!isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] != 1) {
    header("location: login.php");
    exit;
}
$active_facturas = "active";
$active_productos = "";
$active_clientes = "";
$active_usuarios = "";
$title = "Nuevo Ticket | Venta";
unset($_SESSION['variable']);
/* Connect To Database */
require_once ("config/db.php"); //Contiene las variables de configuracion para conectar a la base de datos
require_once ("config/conexion.php"); //Contiene funcion que conecta a la base de datos
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include("head.php"); ?>
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js" defer></script>
        <style>
            .custom-radio {
                display: inline-block;
                margin-right: 10px;
            }
             .custom-control-inline {
                display:grid;
            }
            .custom-control-input:checked ~ .custom-control-label {
                background-color: #007bff;
                color: white;
            }
            .custom-control-input {
                display: none; /* Ocultar el input radio */
            }
            .custom-control-label {
                padding: 10px 20px;
                border: 1px solid #007bff;
                border-radius: 5px;
                cursor: pointer;
                transition: background-color 0.3s;
                display:grid;
            }
             .div_ruleta {                         
                background-color: #ffe1e1;
              /*  border-radius: 50%;        /* Forma circular */
               
                flex-direction: column;
                justify-content: center;   /* Centra los elementos en el eje vertical */
                align-items: center;       /* Centra los elementos en el eje horizontal */
                text-align: center;        /* Centra el texto */
                padding: 10px;
                box-sizing: border-box;
                position: relative;
            }
 
        .div_ruleta span {
                color: #FFD700 !important; /* Dorado brillante */
                font-weight: bold;
                font-size: 25px;
                text-shadow: 1px 1px 2px black; /* Opcional: da más contraste sobre fondos claros u oscuros */
            }

            .div_ruleta img {
                margin-top: 10px;   /* Espacio entre el número y la imagen */
                max-width: 50%;     /* Ajusta el tamaño de la imagen */
                height: auto;
            }

        </style>
    </head>
    <body>
        <?php
        include("navbar.php");
        include("modal/pagar_anular.php");
        ?>  
       	<br> 	 
           <div class="container-fluid">
            <form class="form-horizontal" role="form" id="frmUsers"> 
               
                <div class="form-group row">
                    <label for="empresa" class="col-md-1 control-label">Agencia</label>
                    <div class="col-md-2">
                        <select class="form-control input-sm" id="id_vendedor" id="id_vendedor">
                            <?php
                            $sql_vendedor = mysqli_query($con, "select user_id, firstname,lastname from users where user_id= $_SESSION[user_id]");
                            while ($rw = mysqli_fetch_array($sql_vendedor)) {
                                $id_vendedor = $rw["user_id"];
                                $nombre_vendedor = $rw["firstname"] . " " . $rw["lastname"];
                                if ($id_vendedor == $_SESSION['user_id']) {
                                    $selected = "selected";
                                } else {
                                    $selected = "";
                                }
                                ?>
                                <option value="<?php echo $id_vendedor ?>" <?php echo $selected; ?>><?php echo $nombre_vendedor ?></option>
                                <?php
                            }
                            ?>
                        </select>
                        <input type="hidden" id="taquilla" name="taquilla" value="<?= $id_vendedor ?>">
                    </div>
                    <label for="tel2" class="col-md-1 control-label">Fecha</label>
                    <div class="col-md-1">
                        <input type="text" class="form-control input-sm" id="fecha" value="<?php echo date("d/m/Y"); ?>" reaformdonly>
                    </div>
                    <label for="email" class="col-md-1 control-label">Pago</label>
                    <div class="col-md-2"> 
                    <select class='form-control input-sm' id="condiciones">
                            <option value="1">Efectivo</option>
                        </select>
                        </div>
                    <label for="email" class="col-md-1 control-label">Moneda</label>
                    <div class="col-md-2">
                   
                        <select class='form-control input-sm' id="moneda"> 
                            <?php
                            $sql_vendedor = mysqli_query($con, "SELECT c.id, c.name, c.symbol, c.code FROM comisiones AS co JOIN currencies AS c ON co.id_moneda = c.id WHERE co.pago_id_vendedor='$_SESSION[user_id]' AND c.estatus = 1 ");
                            while ($rw = mysqli_fetch_array($sql_vendedor)) {
                                    $id_moneda = $rw["id"];
                                    $moneda = $rw["name"] . " " . $rw["symbol"];
                                    $simbolo = $rw["symbol"];
                                  
                                ?>
                                <option value="<?php echo $id_moneda ?>"><?php echo $moneda ?></option>
                                <?php
                            }
                            ?>
                        </select>
                        <input type="hidden"  id="symbol" value="<?php echo $simbolo; ?>">
                    </div>
                </div>          

        <div class="container-fluid">
            <form class="form-horizontal" role="form" id="frmUsers"> 
               
            <?php
             $sql_vendedor = mysqli_query($con, "select user_id, firstname,lastname from users where user_id= $_SESSION[user_id]");
                    while ($rw = mysqli_fetch_array($sql_vendedor)) {
                        $id_vendedor = $rw["user_id"];
                        $nombre_vendedor = $rw["firstname"] . " " . $rw["lastname"];
                        if ($id_vendedor == $_SESSION['user_id']) {
                            $selected = "selected";
                        } else {
                            $selected = "";
                        }
                        ?> <?php  }   ?>
                <div class=""> 
                    <div class="row">
                        <div class="col-md-2">
                            <div class="card mb-2">
                                <div class="card-body">                                 
                                        <div class="form-group">
                                            <label for="tipoLoteria">Tipo de Ruleta</label>                                       
                                            <select class="form-control input-sm" id="id_tipr" onchange="filtrarHorarios()">
                                            <option value="0">Seleccione</option>
                                            <?php
                                            $sql_tip_rule = mysqli_query($con, "select id_producto,nombre_producto from products where status_producto='1' and tipo ='2'");
                                            while ($rw = mysqli_fetch_array($sql_tip_rule)) {
                                                $tipo_ruleta = $rw["id_producto"];
                                                $nombre_tipo_r = $rw["nombre_producto"];
                                                ?>
                                                <option value="<?= $tipo_ruleta ?>"><?= $nombre_tipo_r ?></option>
                                            <?php } ?>
                                        </select>
                                        </div>
                                            <div class="form-group">                                      
                                                <label for="horario">Horarios disponibles</label>
                                                <div id="horario-checkboxes">
                                                    <!-- Los checkboxes se insertan aquí dinámicamente -->
                                                </div>
                                            </div>
                                            
                                            <div class="form-group">                            
                                                <label for="numero">Número</label>
                                            <input type="text" class="form-control" id="cantidad" name="cantidad" value="" required>
                                            </div>
                                                <div class="form-group">
                                                    <label for="monto">Monto</label>
                                                    <input type="number" class="form-control" id="precio_venta" name="precio_venta" value="" required>
                                                </div>
                        
                                            <div class="alert alert-danger alert-dismissible" role="alert">
                                            <strong> <p id="total_jugada"  style="font-weight: bold;"></p></strong>  
                                                <br> 
                                                <strong><p id="monto_total"  style="font-weight: bold;"></p></strong>  
                                                <br> 
                                            </div>
                                        <?php                             
                                        $query=mysqli_query($con,"select vender,pagar,anular from permisos where user_id='$id_vendedor'");
                                            $rw=mysqli_fetch_array($query); 
                                            $loteria=$rw['vender'];
                                            $pagar=$rw['pagar'];
                                            $anular=$rw['anular'];
                                        ?>
                                        <?php if ($loteria=='1'){ ?>     
                                            <button   id="btnAdd" type="button" class="btn btn-success"> + Ingresar Jugada </button>                                
                                        
                                            <?php } ?>        
                                            <button type="reset" class="btn btn-danger" onclick="borrar_todo()">Limpiar</button>
                                            </div>     
                                </div> 
                            </div>
                               <div class="col-md-7">
                            <div class="card mb-3">
                                <div class="card-body">
                                    <h5 class="card-title">Tripleta</h5> 
                                       <div class="outer_div1"></div> 
                                </div>
                            </div>  
                        </div>
                        
                        <div class="col-md-3">
                            <div class="card mb-3">
                                <div class="card-body">
                                    <h5 class="card-title">Ticket</h5>
                                   
                                    <div id="jsonDiv"  style="display: none;">   </div> 
                                        <div id="divElements"></div>           
                                                
                                        <?php                             
                                        $query=mysqli_query($con,"select vender,pagar,anular from permisos where user_id='$id_vendedor'");
                                            $rw=mysqli_fetch_array($query); 
                                            $loteria=$rw['vender'];
                                            if ($loteria=='1'){ ?>     
                                                
                                                <button id="btnSave" type="button"   class="btn btn-primary">
                                                    Vender - Imprimir
                                                </button>
                                            <?php } ?>   
                                </div>
                            </div>  
                        </div>          
                         
                    </div>  
                 </div> 
                    </form> 
                </div>   
        <?php
        include("footer.php");
        ?>
            <script>

                $(document).ready(function () {
            $('.basic-multiple').select2();
        });
            $('.modal').on('hidden.bs.modal', function(){  
                $("#resultados_ajax3").html("");
                $(this).find('form')[0].reset();  
                $("label.error").remove();  
            });
            $( "#pagar_ticket" ).submit(function( event ) {
              $('#btnpagar').attr("disabled", true);
            
            var parametros = $(this).serialize();
                $.ajax({
                        type: "POST",
                        url: "ajax/verpagar.php",
                        data: parametros,
                        beforeSend: function(objeto){
                            $("#resultados_ajax3").html("Mensaje: Cargando...");
                        },
                        success: function(datos){ 
                        $("#resultados_ajax3").html(datos);
                        $('#btnpagar').attr("disabled", false);  
                    }
                });
            event.preventDefault();
            })
            $(document).ready(function(){
                $(document).keypress(function(e) {		
                    	 
                    if(e.which == 80 || e.which == 112 ) {                 
                    $('#myModalPagar').modal({show:true});
                } 	 
            if(e.which == 97 || e.which == 65 ) {                 
                 $('#myModalAnular').modal({show:true});
               }     
               if(e.which == 98 || e.which == 66 ) {                 
                borrar_todo();
               }          
                });	
            });
            $( "#anular_ticket" ).submit(function( event ) { 
              $('#btnanular').attr("disabled", true);
            
            var parametros = $(this).serialize();
                $.ajax({
                        type: "POST",
                        url: "ajax/anular_ticket.php",
                        data: parametros,
                        beforeSend: function(objeto){
                            $("#resultados_ajax2").html("Mensaje: Cargando...");
                        },
                        success: function(datos){  
                        $("#resultados_ajax2").html(datos);
                        $('#btnanular').attr("disabled", false);  
                    }
                });
            event.preventDefault();
            })
            </script>
            <script>
                function filtrarHorarios() {
                    buscar();
                    var id_producto = document.getElementById('id_tipr').value;

                    fetch('filtrar_horarios.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'id_producto=' + id_producto
                    })
                    .then(response => response.text())
                    .then(data => {
                        document.getElementById('horario-checkboxes').innerHTML = data;
                    })
                    .catch(error => console.error('Error:', error));
                    }
                </script>
            <script type="text/javascript" src="js/VentanaCentrada.js"></script>
            <script type="text/javascript" src="js/nueva_tripleta.js"></script> 
             <script type="text/javascript" src="js/nueva_ruleta.js"></script> 
            <link href="css/jquery-ui.css" rel="stylesheet" type="text/css"/>
            <script src="boostrap/jquery-iu.js" type="text/javascript"></script>
            <link href="css/style_1.css" rel="stylesheet" type="text/css"/> 
	
    </body>
</html>