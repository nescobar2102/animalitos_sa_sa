<?php
/* -------------------------
  Descripcion:Sistema de Venta y Control de juegos de azar
  Autor: Ing .Norbelys Naguanagua
  Mail: norbelysnaguanagua21@gmail.com
  Version: 1.1
  --------------------------- */
session_start();
if (!isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] != 1) {
    header("location: login.php");
    exit;
}
$active_facturas = "active";
$active_productos = "";
$active_clientes = "";
$active_usuarios = "";
$title = "Nuevo Ticket | Venta";

/* Connect To Database */
require_once ("config/db.php"); //Contiene las variables de configuracion para conectar a la base de datos
require_once ("config/conexion.php"); //Contiene funcion que conecta a la base de datos
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include("head.php"); ?>
    </head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.1/css/bulma.min.css">
    <script defer src="https://use.fontawesome.com/releases/v5.14.0/js/all.js"></script>
    <body>
        <?php
        include("navbar.php");
        ?>  

        <div class="container-fluid">
        <form action="" id="frmUsers">
                <div class="form-group row">
                    <label for="empresa" class="col-md-1 control-label">Agencia</label>
                    <div class="col-md-3">
                        <select class="form-control input-sm" id="id_vendedor">
                            <?php
                            $sql_vendedor = mysqli_query($con, "select * from users where user_id= $_SESSION[user_id]");
                            while ($rw = mysqli_fetch_array($sql_vendedor)) {
                                $id_vendedor = $rw["user_id"];
                                $nombre_vendedor = $rw["firstname"] . " " . $rw["lastname"];
                                if ($id_vendedor == $_SESSION['user_id']) {
                                    $selected = "selected";
                                } else {
                                    $selected = "";
                                }
                                ?>
                                <option value="<?php echo $id_vendedor ?>" <?php echo $selected; ?>><?php echo $nombre_vendedor ?></option>
                                <?php
                            }
                            ?>
                        </select>
                    </div>
                    <label for="tel2" class="col-md-1 control-label">Fecha</label>
                    <div class="col-md-2">
                        <input type="text" class="form-control input-sm" id="fecha" value="<?php echo date("d/m/Y"); ?>" readonly>
                    </div>
                    <label for="email" class="col-md-1 control-label">Pago</label>
                    <div class="col-md-3">
                        <select class='form-control input-sm' id="condiciones">
                            <option value="1">Efectivo</option>
                        </select>
                    </div>
                </div>
            

            <hr>
            <div class="col-md-2">                
                <label for="email" control-label>Tipo Loteria</label>
                <select class="form-control input-sm" id="id_tipr" name="id_tipr">
                    <option value="0" >Seleccione</option>
                    <?php
                    $sql_tip_rule = mysqli_query($con, "select * from tipo_loteria where status='1'");
                    while ($rw = mysqli_fetch_array($sql_tip_rule)) {
                        $tipo_ruleta = $rw["id"];
                        $nombre_tipo_r = $rw["nombre"];
                        ?>
                        <option  value="<?php echo $tipo_ruleta ?>"><?php echo $nombre_tipo_r ?></option>
                        <?php
                    }
                    ?>
                </select> 
            </div> 

            <div class="outer_div"></div>
            <div class="col-md-2">
            <div id="div3">
               
                    <?php
                    $sql_jugada = mysqli_query($con, "select * from jugada where status='1'");
                    ?>
                    <table class="table table-striped" cellspacing="5">
                        <thead>
                            <tr>
                        <p class="bg-primary">JUGADAS</p>
                        </tr>
                        </thead>                       
                        <tbody>
                                <?php
                                while ($row = mysqli_fetch_array($sql_jugada)) {
                                    $id_jug = $row['id'];
                                    $nombre_jug = $row['nombre_j'];
                                ?>                 
                                <tr>
                                    <td><input type="radio" id="jugada" name='jugada' value="<?php echo $id_jug; ?>"><?php echo $nombre_jug; ?></td>
                                </tr>              
                            <?php } ?>
                        </tbody>
                    </table>
               
            </div> 

                <div id="venta">
               
                    <?php
                    $sql_signo = mysqli_query($con, "select * from signo where status='1'");
                    ?>
                    <table border="0"  class="table table-striped " cellspacing="5">
                        <thead>
                        <p class="bg-primary">SIGNOS ZODIACALES</p> 
                        </thead> 
                        <tr>
                            <td><input type="checkbox" id="signo" value="1" checked> ----------------</td> 
                        </tr> 
                        <tbody>
                            <?php
                            while ($row = mysqli_fetch_array($sql_signo)) {
                                $id_signo = $row['id']; 
                                $nombre_signo = $row['nombre'];
                                ?>               
                                <tr>
                                    <td><input type="checkbox" id="signo" value="<?php echo $id_signo; ?>"><?php echo $nombre_signo; ?></td>
                                  </tr>              
                            <?php } ?>
                        </tbody>
                    </table>
                 
                </div>
            </div>
            
            <div class="col-md-3">
                <table border="1" cellspacing="5" class="table table-striped"  id="tablaprueba">
                    <thead>
                        <tr>
                        <p class="bg-primary">TAQUILLA</p>
                  
                    </tr>
                    </thead> 
                  
                    <div id="jsonDiv">                 
                        
                    </div> <tbody>

            
            <div class="field is-grouped"><br>
                <div class="control has-icons-left"> 
                  <input class="input" name="cantidad"  type="number" placeholder="000-999" autocomplete="off">                  
                </div>
                            </div>
                               
            <div class="field is-grouped">
                <div class="control has-icons-left"> 
                    <input class="input" name="precio_venta" type="number" placeholder="0,00" autocomplete="off">                     
                  </div>
           </div>
             <div class="field is-grouped">           
                  <div class="control">
                    <button id="btnAdd" name="btnAdd" type="button" class="button is-danger">
                        <span class="icon">
                            <i class="fas fa-plus"></i>
                        </span>
                      </button>
                  </div>
                  <div class="control">
                    <button id="btnSave" type="button" class="button is-info">
                     Vender - Imprimir
                      </button>
                  </div>
            </div>
        </form>
        <hr>
        <p class="bg-primary">TICKET EN VENTA</p>
        <div id="divElements">
         
                  
        </div>
    </div>
   
  
                    </tbody>
                </table>
                <table>
    <tr>
        <td class='text-center' colspan=3>TOTAL: </td>
        <td class='text-center'> 
                <input type="number"  class="form-control" placeholder="000-999" style="text-align:center"  size="10" maxlength="3" id="total"  value="0.00" >
            </td>
        <td></td>
    </tr>
</table>
            </div>
        </div>  


        <?php
        include("footer.php");
        ?>
        <script type="text/javascript">
            $(document).ready(function () {  
                $("#precio_venta").keydown(function (event) {
                    var num = event.which; 
                    if (num === 13 ) {
                    //    agregar();
                    agregarFila();
                    }
                });

            });


            $('#id_tipr').on('change', function () {
                var id_tipr = $("#id_tipr").val();
                $.ajax({
                    url: './ajax/productos_factura_1.php?action=ajax&q=' + id_tipr,
                    beforeSend: function (objeto) {
                        $('#loader').html('<img src="./img/ajax-loader.gif"> Cargando...');
                    },
                    success: function (data) {
                        $(".outer_div").html(data).fadeIn('slow');
                        $('#loader').html('');

                    }
                }); 

            });

        </script>
        <script type="text/javascript" src="js/VentanaCentrada.js"></script>
        <script type="text/javascript" src="js/nueva_factura.js"></script>
        <script type="text/javascript" src="js/nueva_factura1.js"></script>
        <link href="css/style.css" rel="stylesheet" type="text/css"/>

    </body>
</html>