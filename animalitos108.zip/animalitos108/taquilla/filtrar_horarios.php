<?php
/* Connect To Database */
require_once ("config/db.php"); // Contiene las variables de configuracion para conectar a la base de datos
require_once ("config/conexion.php"); // Contiene funcion que conecta a la base de datos

$id_producto = isset($_POST['id_producto']) ? intval($_POST['id_producto']) : 0;
$tipo = isset($_POST['tipo']) ? intval($_POST['tipo']) : 0;

if ($id_producto > 0 && $tipo > 0) {
    // Primero consultar los id_productos
    $sql111 = "SELECT id_producto FROM products WHERE status_producto='1' AND tipo='1' AND id_tipo='$id_producto'";
    $query111 = mysqli_query($con, $sql111);

    // Crear un array para almacenar los id_productos
    $id_productos = [];
    
    while ($row111 = mysqli_fetch_array($query111)) {
        $id_productos[] = $row111['id_producto'];
    }

    // Si hay id_productos, construir la consulta para horarios
    if (!empty($id_productos)) {
        $ids = implode(',', $id_productos);
        $sql = "SELECT id, descripcion FROM hora_jugadas WHERE ids_loterias IN ($ids)";
    } 
} else {
    // Si no hay selección válida, no muestra horarios
    $sql = "SELECT id, descripcion FROM hora_jugadas WHERE ids_loterias = $id_producto";
}

$query = mysqli_query($con, $sql);

while ($row = mysqli_fetch_array($query)) {
    $id = $row['id'];
    $desc = $row['descripcion'];
    echo '
        <div class="form-check">
            <input class="form-check-input8" type="checkbox" name="horario[]" id="horario_' . $id . '" value="' . $id . '">
            <label class="form-check-label" for="horario_' . $id . '">' . $desc . '</label>
        </div>';
}
?>