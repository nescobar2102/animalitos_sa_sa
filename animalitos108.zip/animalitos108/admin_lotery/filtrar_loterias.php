<?php
/* Connect To Database */
require_once ("config/db.php"); // Contiene las variables de configuración
require_once ("config/conexion.php"); // Contiene la función que conecta a la base de datos

$tipo_jugada = $_POST['tipo_jugada'];

// Ejecutar la consulta
$sql = "SELECT id_producto, nombre_producto 
        FROM products 
        WHERE status_producto='1' 
          AND tipo_jugada LIKE '%$tipo_jugada%' 
        ORDER BY 1 ASC";

$result = mysqli_query($con, $sql);

echo '<div class="form-group">'; 
echo '<select class="form-control input-sm" id="id_tipr" name="tipoLoteria" onchange="filtrarHorarios()">';
echo '<option value="0">Seleccione</option>';

if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_array($result)) {
        $id = $row['id_producto'];
        $desc = $row['nombre_producto'];
        echo '<option value="' . $id . '">' . $desc . '</option>';
    }
} else {
    echo '<option value="">No hay resultados</option>';
}

echo '</select>';
echo '</div>';
?>
