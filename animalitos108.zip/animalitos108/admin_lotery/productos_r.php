<?php
    /*-------------------------
    Descripcion:Sistema de Venta y Control de juegos de azar
    Autor: Ing .Norbelys Naguanagua	 
    Mail: norbelysnaguanagua21@gmail.com
    Version: 1.1   
    ---------------------------*/
    session_start();
    if (!isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] != 1) {
    header("location: login.php");
            exit;
    }

    /* Connect To Database*/
    require_once ("config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
    require_once ("config/conexion.php");//Contiene funcion que conecta a la base de datos

    $active_facturas="";
    $active_productos="active";
    $active_clientes="";
    $active_usuarios="";	
    $title="Admin | Ruleta";
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include("head.php");?>
  </head>
  <body>
	<?php
	include("navbar.php");
	?>
	
    <div class="container">
	<div class="panel panel-info">
		<div class="panel-heading">
		    <div class="btn-group pull-right">
				<button type='button' class="btn btn-info" data-toggle="modal" data-target="#nuevoProducto"> Nuevos Sorteos Animalitos</button>
			</div>
                    <h4><img src="img/iconos/LOTERIA.png" width="30px" >Configurar Jugada Animalitos</h4>
		</div>
		<div class="panel-body">
			<?php
			include("modal/registro_productos_r.php");
			include("modal/editar_productos.php");
			?>
			<form class="form-horizontal" role="form" id="datos_cotizacion">
			     <label for="email" class="col-md-1 control-label">Tipo Animalitos</label>
                    <div class="col-md-2">
                <select class="form-control input-sm" id="id_tipr" onchange="load(1)">
                       <option value="0" >Seleccione</option>
                    <?php
                    $sql_tip_rule=mysqli_query($con,"select id,nombre from tipo_ruleta where  status='1'");
                    while ($rw=mysqli_fetch_array($sql_tip_rule)){
                             $tipo_ruleta=$rw["id"];
                             $nombre_tipo_r=$rw["nombre"];
                            ?>
                    <option  value="<?php echo $tipo_ruleta?>"><?php echo $nombre_tipo_r?></option>
                            <?php
                    }
                      ?>
                </select>
            </div>   
                       <label for="email" class="col-md-1 control-label">Número-Nombre</label>
                    <div class="col-md-2">
                        <input name="numero" id="numero" class="form-control" placeholder="00-Delfin">
                </div>
                <label for="email" class="col-md-1 control-label">Imagen</label>
                    <div class="col-md-2">
                        <select class="form-control input-sm" id="imagen"  required="true">
						<option value="">SELECCIONE</option >
						<option value="aguila.png">aguila</option>
						<option value="alacran.png">alacran</option>
						<option value="araña.png">araña</option>
						<option value="ardilla.png">ardilla</option>
        			    <option value="avestruz.png">avestruz</option>
        				 <option value="ballena.png">Ballena</option>
        				 <option value="burro.png">burro</option>
        				 <option value="caballo.png">caballo</option>
        				 <option value="caiman.png">caiman</option>
        				 <option value="camello.png">camello</option>
        				 <option value="carnero.png">carnero</option>
        				 <option value="cebra.png">cebra</option>
        				 <option value="chivo.png">chivo</option>
        				 <option value="ciempie.png">ciempie</option>
        				 <option value="cochino.png">cochino</option>
        				 <option value="condor.png">condor</option>
        				 <option value="conejo.png">conejo</option>
        				 <option value="culebra.png">culebra</option>
        				 <option value="delfin.png">delfin</option>
        				 <option value="elefante.png">elefante</option>
        				 <option value="gallina.png">gallina</option>
        				 <option value="gallo.png">gallo</option>
        				 <option value="garza-real.png">Garza Real</option>
        				 <option value="gato.png">Gato</option>
        				 <option value="Guacamaya.png">Guacamaya</option>
        				 <option value="hipopotamo.png">Hipopotamo</option>
        				 <option value="Hormiga.png">Hormiga</option>
        				 <option value="iguana.png">iguana</option>
        				 <option value="jirafa.png">jirafa</option>
        				 <option value="koala.png">koala</option>
        				 <option value="lapa.png">lapa</option>
        				 <option value="LECHUZA.png">Lechuza</option>
        				 <option value="leon.png">leon</option>
        				 <option value="lobo.png">lobo</option>
        				 <option value="Mariposa.png">Mariposa</option>
        				 <option value="mono.png">Mono</option>
        				 <option value="oso.png">oso</option>
        				 <option value="oveja.png">oveja</option>
        				 <option value="PAJARO.png">Pajaro</option>
        				 <option value="paloma.png">paloma</option>
        				 <option value="pato.png">pato</option>
        				 <option value="pavo.png">pavo</option>
        				 <option value="perico.png">perico</option>
        				 <option value="perro.png">Perro</option>
        				 <option value="pescado.png">pescado</option>
        				 <option value="pulpo.png">pulpo</option>
        				 <option value="puma.png">Puma</option>
        				 <option value="rana.png">Rana</option>
        				 <option value="Raton.png">Raton</option>
        				<option value="rinoceronte.png">rinoceronte</option>
        				<option value="tigre.png">tigre</option>
        				<option value="toro.png">Toro</option>
        				<option value="tortuga.png">tortuga</option>
        				<option value="tuburon.png">Tiburon</option>
        				<option value="vaca.png">Vaca</option>
        				<option value="venado.png">Venado</option>
        				<option value="zamuro.png">Zamora</option>
        				<option value="zorro.png">Zorro</option>

                    </select>
                </div>
                  <label for="email" class="col-md-1 control-label">Color</label>
                    <div class="col-md-2">
                         <select class="form-control input-sm" id="color"  required="true">
                            <option value="">SELECCIONE</option >
                            <option value="white">BLANCO</option>
                            <option value="blue">AZUL </option>
                            <option value="red">ROJO</option>
                            <option value="background">AZUL CLARO</option>
                            <option value="pink">ROSADO</option>
                            <option value="#5e5e5e">NEGRO SUAVE</option>
                            <option value="#fcefa1">AMARILLO SUAVE</option>
                            <option value="#ce8483">NEGRO</option>
                            <option value="#8c8c8c">GRIS</option>
                         </select>
                </div>
                   <div class="col-md-2">
                       <button class=" btn btn-info" onclick="agregar()"> Guardar</button></td>
                  </div>                 
			</form>
                <div id="resultados"></div><!-- Carga los datos ajax -->
                <div class='outer_div'></div><!-- Carga los datos ajax -->
			
  </div>
</div>
		 
	</div>
    <hr>
    <?php
    include("footer.php");
    ?>
    <script type="text/javascript" src="js/ruleta.js"></script>
  </body>
</html>
<script type="text/javascript">
$( "#guardar_producto" ).submit(function( event ) {
  $('#guardar_datos').attr("disabled", true);
  
 var parametros = $(this).serialize();
	 $.ajax({
			type: "POST",
			url: "ajax/nueva_ruleta.php",
			data: parametros,
			 beforeSend: function(objeto){
				$("#resultados_ajax_productos").html("Mensaje: Cargando...");
			  },
			success: function(datos){
			$("#resultados_ajax_productos").html(datos);
			$('#guardar_datos').attr("disabled", false);
			load(1);
		  }
	});
  event.preventDefault();
})

$( "#editar_producto" ).submit(function( event ) {
  $('#actualizar_datos').attr("disabled", true);
  
 var parametros = $(this).serialize();
	 $.ajax({
			type: "POST",
			url: "ajax/editar_producto.php",
			data: parametros,
			 beforeSend: function(objeto){
				$("#resultados_ajax2").html("Mensaje: Cargando...");
			  },
			success: function(datos){
			$("#resultados_ajax2").html(datos);
			$('#actualizar_datos').attr("disabled", false);
			load(1);
		  }
	});
  event.preventDefault();
})

	function obtener_datos(id){
			var codigo_producto = $("#codigo_producto"+id).val();
			var nombre_producto = $("#nombre_producto"+id).val();
			var estado = $("#estado"+id).val();
			var precio_producto = $("#precio_producto"+id).val();
			$("#mod_id").val(id);
			$("#mod_codigo").val(codigo_producto);
			$("#mod_nombre").val(nombre_producto);
			$("#mod_precio").val(precio_producto);
			$("#mod_estado").val(estado);
		}
</script>
