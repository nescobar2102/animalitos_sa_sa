<?php
	
	/*-------------------------
        Descripcion:Sistema de Venta y Control de juegos de azar
		Autor: Ing .Norbelys Naguanagua	 
		Mail: norbelysnaguanagua21@gmail.com
        Version: 1.1    
	---------------------------*/
	session_start();
	if (!isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] != 1) {
        header("location: login.php");
		exit;
        }
        
	$active_facturas="active";
	$active_productos="";
	$active_clientes="";
	$active_usuarios="";	
	$title="Nuevo Ticket | Venta";
	
	/* Connect To Database*/
	require_once ("config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
	require_once ("config/conexion.php");//Contiene funcion que conecta a la base de datos
	    ini_set('date.timezone','America/Caracas');
    $date = date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include("head.php");?>
  </head>
  <body>
	<?php
	include("navbar.php");
	?>  
    <div class="container">
	<div class="panel panel-info">
		<div class="panel-heading">
          <h4><img src="img/iconos/reportes.png" width="30px" > Resultados de Loteria</h4>
		</div>
		<div class="panel-body">
		<?php 
			include("modal/buscar_productos.php");

		?> 
			 <form class="form-horizontal" role="form" id="datos_cotizacion">				
				<div class="form-group row">
						<label for="q" class="col-md-2 control-label"> Fecha </label>
						<div class="col-md-2">
								<input type="text" class="tcal form-control" id="q"  value="<?= $date;?>"  onkeyup='search();'>
						</div>
						<div class="col-md-3">
								<button type="button" class="btn btn-default" onclick='search();'>
										Buscar</button>
								<span id="loader"></span>
								
						</div>
						<div class="col-md-3">
				 		<button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">
							 <span>
								 <img src="img/iconos/TICKET VENDIDOS.png" width="30px">
								</span> 
								Cargar Resultados de Loterias
						</button>									
						</div>
						<div class="col-md-12">
				 		<a href="http://localhost/animalitos/taquilla/nueva_taquilla.php" type="button" class="btn btn-success" >
							 <span>
								 <img src="img/iconos/TICKET VENDIDOS.png" width="30px">
								</span> 
								Vender loteria
							</a>	
                            <a href="http://localhost/animalitos/taquilla/nueva_ruleta.php" type="button" class="btn btn-success" >
							 <span>
								 <img src="img/iconos/TICKET VENDIDOS.png" width="30px">
								</span> 
								Vender Animalitos
							</a>
                            <a href="http://localhost/animalitos/taquilla/nueva_ruleta_tripleta.php" type="button" class="btn btn-success" >
							 <span>
								 <img src="img/iconos/TICKET VENDIDOS.png" width="30px">
								</span> 
								Vender Tripleta
							</a>								
						</div>
				</div>				 
			</form>		
			
		<div id="resultados" class='col-md-12' style="margin-top:10px"></div><!-- Carga los datos ajax -->	
		<div id="loader_lo"></div>		
		<div id="resultados_lo"></div> 	
    </div>
	</div>		
		  <div class="row-fluid">
			<div class="col-md-12">
			</div>	
		 </div>
	</div>
	<hr>
	<?php
	include("footer.php");
	?>
	<script type="text/javascript" src="js/VentanaCentrada.js"></script>
        <script type="text/javascript" src="js/cargar_resultados.js"></script>
         <link href="css/jquery-ui.css" rel="stylesheet" type="text/css"/>
     <script src="boostrap/jquery-iu.js" type="text/javascript"></script>
	

  </body>
</html>

<script>
	$(document).ready(function(){
		search();
	});
    function showEdit(editableObj) {
        $(editableObj).css("background", "#FFF");
    }

    function saveToDatabase(editableObj, column, id) {
        $(editableObj).css("background", "#FFF url(loaderIcon.gif) no-repeat right");
        $.ajax({
            url: "server_1.php",
            type: "POST",
            data: 'column=' + column + '&editval='+editableObj.innerHTML+'&id=' + id,
            success: function (data) {
                $(editableObj).css("background", "#FDFDFD");
            }
        });
    }
	
	function search() {
    var fecha = $("#q").val();

			$.ajax({
				url: 'buscar_resultados.php',
				type: 'POST',
				data: { fecha: fecha },
				beforeSend: function () {
					$('#loader_lo').html('Cargando...');
				},
				success: function (data) {
					$("#resultados_lo").html(data);
					$('#loader_lo').html('');
				}
			});
	}

</script>