<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=gb18030">
        <?php include("head.php"); ?>

    </head>
    <body>
        <?php
        include("navbar.php");
       /* Connect To Database */
            require_once ("config/db.php"); //Contiene las variables de configuracion para conectar a la base de datos
            require_once ("config/conexion.php"); //Contiene funcion que conecta a la base de datos


          /* -------------------------
          Descripcion:Sistema de Venta y Control de juegos de azar
          Autor: Ing .Norbelys Naguanagua
          Mail: norbelysnaguanagua21@gmail.com
          Version: 1.1
          --------------------------- */
          session_start();
          if (!isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] != 1) {
              header("location: login.php");
              exit;
          }

        if (empty($_POST['producto'])) {
            $errors[] = "Loteria vacía";
        } else if (empty($_POST['numero'])) {
            $errors[] = "Numero vacío";
        } else if (
                !empty($_POST['producto']) &&
                !empty($_POST['numero'])
        ) {
            /* Connect To Database */
      
           
            // escaping, additionally removing everything that could be (html/javascript-) code
            $producto = mysqli_real_escape_string($con, (strip_tags($_POST["producto"], ENT_QUOTES)));

            $numero = floatval($_POST['numero']);
            $date_added = date("Y-m-d");
            $id_vendedor = $_POST['usuario'];

            $sql = "INSERT INTO limites (id_loteria, monto,id_vendedor) VALUES ('$producto','$numero','$id_vendedor')";


            $query_new_insert = mysqli_query($con, $sql);
            if ($query_new_insert) {
                $messages[] = "Su cambio fue realizado con éxito. Límite establecido";
            } else {
                $errors [] = "Lo siento algo ha salido mal intenta nuevamente." . mysqli_error($con);
            }
        } else {
            $errors [] = "Error desconocido.";
        }

        if (isset($errors)) {
            ?>
           <div class="container">
            <div class="panel panel">
                <div class="panel-heading">
                      <div class="panel-body">
                        <div class="form-group row">
                            <div class="form-group">
			<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert">&times;</button>
					<strong>Error!</strong> 
					<?php
						foreach ($errors as $error) {
								echo $error;
							}
						?>
			</div>
                            </div>
                        </div>
                      </div>
                </div>
            </div>
        </div>
            <?php
        }
        if (isset($messages)) {
            ?>
              <div class="container">
            <div class="panel panel">
                <div class="panel-heading">
                      <div class="panel-body">
                        <div class="form-group row">
                            <div class="form-group">
				<div class="alert alert-success" role="alert">
                                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                                    <strong>¡Bien hecho!</strong>
                                    <?php
                                            foreach ($messages as $message) {
                                                            echo $message;
                                                    }
                                            ?>
				</div>
                            </div>
                        </div>
                </div>
                </div>
            </div>
        </div>
                <?php
            }


            include 'footer.php';
            ?>

    </body>

<script type="text/javascript">
    function redireccionar() {
     window.history.back();      
    }
    setTimeout("redireccionar()", 2000);
</script>
</html>
