<?php	/*-------------------------
        Descripcion:Sistema de Venta y Control de juegos de azar
	Autor: Ing .Norbelys Naguanagua	 
	Mail: norbelysnaguanagua21@gmail.com
        Version: 1.1      
	---------------------------*/
	session_start();
	if (!isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] != 1) {
        header("location: ../../login.php");
		exit;
        }
    /* Connect To Database*/
	include("../../config/db.php");
	include("../../config/conexion.php");
	//Archivo de funciones PHP
	include("../../funciones.php");
        
	$id_factura=intval($_GET['id_factura']); 
	$simbolo_moneda=get_row('perfil','moneda', 'id_perfil', 1);
       
	?> 
<style type="text/css">
<!--
table { vertical-align: top; }
tr    { vertical-align: top; }
td    { vertical-align: top; }
.midnight-blue{
	background:#2c3e50;
	padding: 4px 4px 4px;
	color:white;
	font-weight:bold;
	font-size:12px;
}
.silver{
	background:white;
	padding: 3px 4px 3px;
}
.clouds{
	background:#ecf0f1;
	padding: 3px 4px 3px;
}
.border-top{
	border-top: solid 1px #bdc3c7;	
}
.border-left{
	border-left: solid 1px #bdc3c7;
}
.border-right{
	border-right: solid 1px #bdc3c7;
}
.border-bottom{
	border-bottom: solid 1px #bdc3c7;
}
table.page_footer {width: 100%; border: none; background-color: white; padding: 2mm;border-collapse:collapse; border: none;}

</style>
<page backtop="10mm" backbottom="10mm" backleft="10mm" backright="10mm" style="font-size: 8pt; font-family: arial" >
        <page_footer>
        <table class="page_footer">
            <tr>
                <td style="width: 50%; text-align: left">
               
                </td>
                <td style="width: 50%; text-align: right">
                    &copy; <?php  echo  $anio=date('Y'); ?>
                </td>
            </tr>
        </table>
    </page_footer> 
       <br>
       <br>
	<table cellspacing="0" style="width: 35%; text-align: left; font-size: 8pt;">
            <?php 
                       
            $sql_fact=mysqli_query($con,"select * from facturas where numero_factura='$id_factura'");
                        $resulf=mysqli_fetch_array($sql_fact);
                        $id_vendedor=$resulf['id_vendedor'];
                        $condiciones=$resulf['condiciones'];
                        
            
                        $sql_user=mysqli_query($con,"select * from users where user_id='$id_vendedor'");
                        $rw_user=mysqli_fetch_array($sql_user);
                      
                ?>
        
		<tr>
                    <td style="width:35%;">
                      Vendedor:<?php echo $rw_user['firstname']." ".$rw_user['lastname'];?>
                    </td>
                </tr>
                <tr>
                    
		    <td style="width:25%;">
                      Fecha:<?php  echo $resulf['fecha_factura'];?>
                    </td>
                    <td >
                      Ticket Nro:<?php echo $resulf['numero_factura'];?>
                    </td>
                </tr>
                <tr>
		   <td style="width:35%;" >Forma de Pago:Efectivo                       
		   </td>
                </tr>
	
        </table>
	<br>  
    <table cellspacing="0" style="width: 35%; text-align: left; font-size: 5pt;">
        <tr>
            <th style="width:10%; text-align:center; font-size: 5pt;" class='midnight-blue'>Número</th>
            <th style="width:15%; font-size: 5pt;" class='midnight-blue'>Loteria</th>
            <th style="width:10%; font-size: 5pt; text-align: right" class='midnight-blue'>Monto</th>
        </tr>

<?php
$nums=1;
$sumador_total=0;//loteria
if($condiciones ==1){
    $sql=mysqli_query($con, "SELECT * FROM detalle_factura,products,signo WHERE numero_factura='$id_factura'
    and detalle_factura.id_producto=products.id_producto 
    and detalle_factura.id_signo=signo.id"); 

}else{
    $sql=mysqli_query($con, "SELECT * FROM detalle_factura,products,signo WHERE numero_factura='$id_factura'
    and detalle_factura.id_producto=products.codigo_producto 
    and detalle_factura.id_signo=signo.id"); 

}
  
 
while ($row=mysqli_fetch_array($sql))
	{
	$cantidad=$row['cantidad'];
	$nombre_producto=$row['nombre_producto'];
    $id_signo=$row['nombre'];	
	$precio_venta=$row['precio_venta'];
	$precio_venta_f=number_format($precio_venta,2);//Formateo variables
	$precio_venta_r=str_replace(",","",$precio_venta_f);//Reemplazo las comas
	$precio_total=$precio_venta_r;
	$precio_total_f=number_format($precio_total,2);//Precio total formateado
	$precio_total_r=str_replace(",","",$precio_total_f);//Reemplazo las comas
	$sumador_total+=$precio_total_r;//Sumador
	if ($nums%2==0){
		$clase="clouds";
	} else {
		$clase="silver";
	} 
     $loteria=$nombre_producto." -". $id_signo;
         
	?>  
        <tr>
            <td class='<?php echo $clase;?>' style="width: 10%; text-align: center; font-size: 7pt;"><?php echo $cantidad; ?></td>
            <td class='<?php echo $clase;?>' style="width: 15%; text-align: center; font-size: 7pt;"><?php echo  $loteria; ?></td>
            <td class='<?php echo $clase;?>' style="width: 10%; text-align: right; font-size: 7pt;"><?php echo $precio_venta_f;?></td>
        </tr>

	<?php 	
	}
        $impuesto=get_row('perfil','impuesto', 'id_perfil', 1);
        $subtotal=number_format($sumador_total,2,'.','');
        $total_iva=($subtotal * $impuesto )/100;
        $total_iva=number_format($total_iva,2,'.','');
        $total_factura=$subtotal;        
    ?>

    </table>
	        <div>_________________________________________________</div>
         <table cellspacing="0" style="width: 35%; text-align: left; font-size: 7pt;">
        <tr>
            <td style="width:15%; text-align: center;">TOTAL <?php echo $simbolo_moneda;?> </td>
            <td style="width: 20%; text-align: right;"> <?php echo number_format($subtotal,2);?></td>
        </tr>
        <tr><td style="font-size:7pt;text-align:center;font-weight:bold"><br>Gracias por su compra!</td>
        <tr>
            <td> <br><br>                                  
                <div id="logo_impresora"align="center"><input width="50px" img src="../../img/imprimir.png" type="image" onclick="window.print();"/></div>
            </td>
        </tr>
        </tr> 
    </table>

</page>
