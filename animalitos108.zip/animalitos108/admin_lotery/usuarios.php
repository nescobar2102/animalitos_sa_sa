<?php
	session_start();
	if (!isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] != 1) {
        header("location: login.php");
		exit;
        }

	/* Connect To Database*/
	require_once ("config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
	require_once ("config/conexion.php");//Contiene funcion que conecta a la base de datos
	$active_facturas="";
	$active_productos="";
	$active_clientes="";
	$active_usuarios="active";	
	$title="Admin | Usuarios-Permisos";
?>
<!DOCTYPE html>
<html lang="en">
  <head>
	<?php include("head.php");?>
  </head>
  <body>
 	<?php
	include("navbar.php");
	?> 
    <div class="container">
		<div class="panel panel-info">
		<div class="panel-heading">
		    <div class="btn-group pull-right">
				<button type='button' class="btn btn-info" data-toggle="modal" data-target="#myModal"> Nueva Taquilla</button>
			</div>
                    <h4>  <img src="img/iconos/crear taquilla.png" width="25px">Buscar Taquillas-Administradores</h4>
                      
		</div>			
			<div class="panel-body">
			<?php
			include("modal/registro_usuarios.php");
			include("modal/editar_usuarios.php");
			include("modal/cambiar_password.php");
            include("modal/bloquear_num.php");
            include("modal/comisiones.php");
			
			?>
			<form class="form-horizontal" role="form" id="datos_cotizacion">
				<div class="form-group row">
                                    <label for="q" class="col-md-2 control-label">Tipo de Usuarios:</label>
                                    <div class="col-md-4">	
                                        
                                  
									<select id="q" name="q" class="form-control" onchange='load(0);'>
                                                <option value="0">Seleccione </option>
												<option value="1">Administrador </option>
												<option value="2">Banca </option>
												<option value="4">Intermediarios </option>
												<option value="5">Agencia </option> 
												<option value="3">Taquilla </option> 
								</select>
								</div>
                    <span id="loader"></span>
                                    <div class="col-md-3">
                                            <button type="button" class="btn btn-default" onclick='load(0);'>
                                                   Buscar</button>
                                            <span id="loader"></span>
                                    </div>
				</div>
				
				
				
			</form>
				<div id="resultados"></div><!-- Carga los datos ajax -->
				<div class='outer_div'></div><!-- Carga los datos ajax -->
						
			</div>
		</div>

	</div>
	<hr>
	<?php
	include("footer.php");
	?>
	<script type="text/javascript" src="js/usuarios.js"></script>

  </body>
</html>
<script type="text/javascript">

$('.modal').on('hidden.bs.modal', function(){  
                $("#resultados_ajax").html("");
                $(this).find('form')[0].reset();  
                $("label.error").remove();  
            });
$( "#guardar_usuario" ).submit(function( event ) {
$('#guardar_datos').attr("disabled", true);
  
 var parametros = $(this).serialize();
 
	 $.ajax({
			type: "POST",
			url: "ajax/nuevo_usuario.php",
			data: parametros,
			 beforeSend: function(objeto){
				$("#resultados_ajax").html("Mensaje: Cargando...");
			  },
			success: function(datos){
			$("#resultados_ajax").html(datos);
			$('#guardar_datos').attr("disabled", false);
			load(1);
		  }
	});
  event.preventDefault();
})

$( "#editar_usuario" ).submit(function( event ) {
$('#actualizar_datos2').attr("disabled", true);
  
 var parametros = $(this).serialize();
	 $.ajax({
			type: "POST",
			url: "ajax/editar_usuario.php",
			data: parametros,
			 beforeSend: function(objeto){
				$("#resultados_ajax2").html("Mensaje: Cargando...");
			  },
			success: function(datos){
			$("#resultados_ajax2").html(datos);
			$('#actualizar_datos2').attr("disabled", false);
			load(1);
		  }
	});
  event.preventDefault();
})

$( "#editar_password" ).submit(function( event ) {
$('#actualizar_datos3').attr("disabled", true);
  
 var parametros = $(this).serialize();
	 $.ajax({
			type: "POST",
			url: "ajax/editar_password.php",
			data: parametros,
			 beforeSend: function(objeto){
				$("#resultados_ajax3").html("Mensaje: Cargando...");
			  },
			success: function(datos){
			$("#resultados_ajax3").html(datos);
			$('#actualizar_datos3').attr("disabled", false);
			load(1);
		  }
	});
  event.preventDefault();
})
	function get_user_id(id){
		$("#user_id_mod").val(id);
	}

	function obtener_datos(id){
			var nombres = $("#nombres"+id).val();
			var apellidos = $("#apellidos"+id).val();
			var usuario = $("#usuario"+id).val();
			var email = $("#email"+id).val();
			
			$("#mod_id").val(id);
			$("#firstname2").val(nombres);
			$("#lastname2").val(apellidos);
			$("#user_name2").val(usuario);
			$("#user_email2").val(email);
			
		}
                
	function obtener_comision(id){                        
            var codigo_producto = $("#triple"+id).val();
			var nombre_producto = $("#terminal"+id).val();
			var pago = $("#pago"+id).val();
			var pagot = $("#pagot"+id).val();
			var moneda = $("#moneda"+id).val();
            $("#id_usuarios").val(id);  
			$("#comision_t").val(codigo_producto);
			$("#comision_ter").val(nombre_producto);		
			$("#pago").val(pago); 
			$("#pagot").val(pagot); 
			$("#moneda").val(moneda); 
		}
                
                
$( "#guardar_comision" ).submit(function( event ) {
$('#actualizar_datos2').attr("disabled", true);
  
 var parametros = $(this).serialize();
	 $.ajax({
              
			type: "POST",
			url: "ajax/nueva_comision.php",
			data: parametros,
			 beforeSend: function(objeto){
				$("#resultados_ajax2").html("Mensaje: Cargando...");
			  },
			success: function(datos){
			$("#resultados_ajax2").html(datos);
			$('#actualizar_datos2').attr("disabled", false);
			load(1);
		  }
	});
  event.preventDefault();
});

function bloq_num(id){  
    $("#usuario").val(id); 
}

$( "#guardar_limites" ).submit(function( event ) {
$('#guardar_datos').attr("disabled", true);
  
 var parametros = $(this).serialize();
	 $.ajax({
			type: "POST",
			url: "ajax/nuevo_bloqueo.php",
			data: parametros,
			 beforeSend: function(objeto){
				$("#resultados_ajax_productos").html("Mensaje: Cargando...");
			  },
			success: function(datos){
			$("#resultados_ajax_productos").html(datos);
			$('#guardar_datos').attr("disabled", false);
			load(1);
		  }
	});
  event.preventDefault();
});


function limite(id){
        window.location="limites.php?id="+id; 
}

$('#tipo_user').change(function () { 
    var id = $('select option').filter(':selected').val()
    $.ajax({
        type: 'POST',
        url: 'ajax/buscar_tipousuario.php',
        data: {
            'id': id
        },
        success: function (data) { 
			document.getElementById("div").innerHTML=data; 
        }
    });  
});
</script>



