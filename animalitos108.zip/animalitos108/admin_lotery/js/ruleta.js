function load(page) {

    var q = $("#id_tipr").val();
    $("#loader").fadeIn('slow');
    $.ajax({
        url: './ajax/buscar_ruleta.php?action=ajax&page=' + page + '&q=' + q,
        beforeSend: function (objeto) {
            $('#loader').html('<img src="./img/ajax-loader.gif"> Cargando...');
        },
        success: function (data) {
            $(".outer_div").html(data).fadeIn('slow');
            $('#loader').html('');

        }
    });
}


function agregar() {
    var numero = $('#numero').val();
    var imagen = $('#imagen').val();
    var id_tipr = $('#id_tipr').val();
    var color = $('#color').val();  
    $.ajax({
        type: "POST",
        url: "./ajax/buscar_ruleta.php",
        data: "id=" + id_tipr + "&numero=" + numero + "&imagen=" + imagen + "&color=" + color + "&action1=insertar",        
        beforeSend: function (objeto) {
            $("#resultados").html("Mensaje: Cargando...");
        },
        success: function (datos) {
            $("#resultados").html(datos);
        }
    });
}

function eliminar(id) {
    var id_tipr = $('#id_tipr').val();
    if (confirm("Realmente deseas eliminar?")) {
        $.ajax({
            type: "GET",
            url: "./ajax/borrar_ruleta.php",
            data: "id=" + id + "&tipo=" + id_tipr,
            beforeSend: function (objeto) {
                $("#resultados").html("Mensaje: Cargando...");
            },
            success: function (datos) {
                $("#resultados").html(datos);
                load(1);
            }
        });
    }
}
