		$(document).ready(function(){
			load(1);
		});

		function load(page){
			var q= $("#q").val();
			$("#loader").fadeIn('slow');
			$.ajax({
				url:'./ajax/buscar_signo.php?action=ajax&page='+page+'&q='+q,
				 beforeSend: function(objeto){
				 $('#loader').html('<img src="./img/ajax-loader.gif"> Cargando...');
			  },
				success:function(data){
					$(".outer_div").html(data).fadeIn('slow');
					$('#loader').html('');
					
				}
			})
		}

	
		//para cambiar los estatus de las jugadas
                //s= status,id= id de jugada
                //valor=1; activo; valor=0; inactivo;
                
	function status (id,s)
		{
		if(s==='0'){
			var nom='desactivar';
		}else{
			nom= 'activar';
		}
                    
		var q= $("#q").val();                        
		if (confirm("¿Realmente deseas "+nom+" el signo?")){	
                        $.ajax({
                type: "GET",
                url: "./ajax/buscar_signo.php",
                data: "id="+id+"&s="+s,"q":q,
                         beforeSend: function(objeto){
                                $("#resultados").html("Mensaje: Cargando...");
		  },
        success: function(datos){
		$("#resultados").html(datos);
		load(1);
		}
			});
		}
		}
                 