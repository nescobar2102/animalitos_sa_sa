function load(page) {
    var q = $("#q").val();
    var sorteo = $("#sorteo").val();
    $("#loader").fadeIn('slow');
    $.ajax({
        url: './ajax/num_vendidos.php?action=ajax&page=' + page + '&q=' + q + '&sorteo=' + sorteo,
        beforeSend: function (objeto) {
            $('#loader').html('<img src="./img/ajax-loader.gif"> Cargando...');
        },
        success: function (data) {
            $(".outer_div").html(data).fadeIn('slow');
            $('#loader').html('');
            $('[data-toggle="tooltip"]').tooltip({html: true});

        }
    })
}
