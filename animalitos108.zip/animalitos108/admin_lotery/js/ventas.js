function load(tipo, user_id){
    console.log("iduser", tipo)
    console.log("tipo", tipo)
     var q= $("#q").val(); 
    
     console.log("tipo user select", q)
     $("#loader").fadeIn('slow');
     $.ajax({
               url:'./ajax/buscar_usuarios_ventas.php?action=ajax&page=1&q='+q+'&tipo='+tipo+'&iduser='+user_id,
              beforeSend: function(objeto){
              $('#loader').html('<img src="./img/ajax-loader.gif"> Cargando...');
       },
             success:function(data){ 
                     $(".outer_div").html(data).fadeIn('slow');
                     $('#loader').html('');
 
             }
     });
 }

function eliminar(id, s) {
    var q = $("#q").val();
    if (confirm("¿Estas seguro que desea anular el Ticket?")) {
        $.ajax({
            type: "GET",
            url: "./ajax/buscar_facturas.php",
            // data: "id="+id,"q":q,
            data: "id=" + id + "&s=" + s,
            "q": q,
            beforeSend: function (objeto) {
                $("#resultados").html("Mensaje: Cargando...");
            },
            success: function (datos) {
                $("#resultados").html(datos);
                load(1);
            }
        });
    }
}

function pagarticket(id, s) {
    var q = $("#q").val();
    if (confirm("¿Desea pagar este ticket?")) {
        $.ajax({
            type: "GET",
            url: "./ajax/buscar_facturas.php",
            // data: "id="+id,"q":q,
            data: "id=" + id + "&s=" + s,
            "q": q,
            beforeSend: function (objeto) {
                $("#resultados").html("Mensaje: Cargando...");
            },
            success: function (datos) {
                $("#resultados").html(datos);
                load(1);
            }
        });
    }
}

function imprimir_factura(id_factura) {
    VentanaCentrada('./pdf/documentos/ver_factura.php?id_factura=' + id_factura, 'Factura', '', '1024', '768', 'true');
}
