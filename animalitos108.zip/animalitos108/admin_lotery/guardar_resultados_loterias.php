<?php
/* Connect To Database */
require_once("config/db.php");
require_once("config/conexion.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') { 
    $tipo_jugada = mysqli_real_escape_string($con, $_POST['tipo_jugada']);
    $tipoLoteria = mysqli_real_escape_string($con, $_POST['tipoLoteria']);
    $cantidad = mysqli_real_escape_string($con, $_POST['cantidad']);
    $horario = mysqli_real_escape_string($con, $_POST['horario']); 

    ini_set('date.timezone','America/Caracas');
    $date = date('Y-m-d');

    // Verificar si ya existe un registro para esa combinación
echo    $check_sql = "SELECT id 
                  FROM resultados 
                  WHERE id_loteria = '$tipoLoteria' 
                    AND tipo_jugada = '$tipo_jugada'
                    AND id_horario = '$horario' 
                    AND fecha_sorteo = '$date'";
    $check_result = mysqli_query($con, $check_sql);

        if ($check_result === false) {
            die("Error en la consulta: " . mysqli_error($con) . " - SQL: " . $check_sql);
        }

        if (mysqli_num_rows($check_result) > 0) {
            // Ya existe → actualizar cantidad
            $update_sql = "UPDATE resultados 
                        SET numero = '$cantidad'
                        WHERE id_loteria = '$tipoLoteria' 
                            AND tipo_jugada = '$tipo_jugada'
                            AND id_horario = '$horario' 
                            AND fecha_sorteo = '$date'";
            if (mysqli_query($con, $update_sql)) {
                echo "Resultado actualizado.";
            } else {
                echo "Error al actualizar: " . mysqli_error($con);
            }
        } else {
            // No existe → insertar nuevo
            $insert_sql = "INSERT INTO resultados (id_loteria, numero, id_signo, id_horario, fecha_sorteo, tipo_jugada)
                        VALUES ('$tipoLoteria', '$cantidad', '1', '$horario', '$date', '$tipo_jugada')";
            if (mysqli_query($con, $insert_sql)) {
                echo "Resultado guardado.";
            } else {
                echo "Error al guardar: " . mysqli_error($con);
            }
        }
}
?>
