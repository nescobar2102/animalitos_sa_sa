<?php
/* -------------------------
  Descripcion:Sistema de Venta y Control de juegos de azar
  Autor: Ing .Norbelys Naguanagua
  Mail: norbelysnaguanagua21@gmail.com
  Version: 1.0
  --------------------------- */
session_start();
if (!isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] != 1) {
    header("location: login.php");
    exit;
}

/* Connect To Database */
require_once ("config/db.php"); //Contiene las variables de configuracion para conectar a la base de datos
require_once ("config/conexion.php"); //Contiene funcion que conecta a la base de datos

$active_facturas = "";
$active_productos = "active";
$active_clientes = "";
$active_usuarios = "";
$title = "Admin | Ruleta";
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include("head.php"); ?>
    </head>
    <body>
        <?php
        include("navbar.php");
        ?>

        <div class="container">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <div class="btn-group pull-right">
                        <button type='button' class="btn btn-info" data-toggle="modal" data-target="#nuevoProducto">  Agregar Tipo</button>
                    </div>

                    <h4><img src="img/iconos/LOTERIA.png" width="20px" > Tipo Loteria</h4>
                </div>
                <div class="panel-body">
                    <?php
                    include("modal/registro_tipo_loteria.php");
                    ?>
                    <form class="form-horizontal" role="form" id="datos_cotizacion">
                        <?php
                        $sql = "select * from tipo_loteria";

                        $queryRecords = mysqli_query($con, $sql) or die("error to fetch employees data");
                        ?>

                        <table id="employee_grid" class="table table-condensed table-hover table-striped bootgrid-table" width="60%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Id Loteria</th>
                                    <th>Nombre Loteria</th>
                                    <th>Estatus 1=activo 2=inactivo</th>
                                </tr>
                            </thead>
                            <tbody id="_editable_table">
                                <?php foreach ($queryRecords as $res) : ?>

                                    <tr class="table table-striped">	 
                                        <td  onBlur="saveToDatabase(this, 'id_loteria', '<?php echo $res["id"]; ?>')" onClick="showEdit(this);"><?php echo $res["id"]; ?></td>
                                        <td contenteditable="true" onBlur="saveToDatabase(this, 'nombre', '<?php echo $res["id"]; ?>')" onClick="showEdit(this);"><?php echo $res["nombre"]; ?></td>
                                        <td contenteditable="true" onBlur="saveToDatabase(this, 'status', '<?php echo $res["id"]; ?>')" onClick="showEdit(this);"><?php echo $res["status"]; ?></td>

                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>

                    </form>


                </div>
            </div>

        </div>
        <hr>
        <?php
        include("footer.php");
        ?>


    </body>
</html>
<script type="text/javascript">
    $("#guardar_producto").submit(function (event) {
        $('#guardar_datos').attr("disabled", true);

        var parametros = $(this).serialize();
        $.ajax({
            type: "POST",
            url: "ajax/nuevo_tipo_loteria.php",
            data: parametros,
            beforeSend: function (objeto) {
                $("#resultados_ajax_productos").html("Mensaje: Cargando...");
            },
            success: function (datos) {
                $("#resultados_ajax_productos").html(datos);
                $('#guardar_datos').attr("disabled", false);
                load(1);
            }
        });
        event.preventDefault();
    })

    $("#editar_producto").submit(function (event) {
        $('#actualizar_datos').attr("disabled", true);

        var parametros = $(this).serialize();
        $.ajax({
            type: "POST",
            url: "ajax/editar_producto.php",
            data: parametros,
            beforeSend: function (objeto) {
                $("#resultados_ajax2").html("Mensaje: Cargando...");
            },
            success: function (datos) {
                $("#resultados_ajax2").html(datos);
                $('#actualizar_datos').attr("disabled", false);
                load(1);
            }
        });
        event.preventDefault();
    })

    function obtener_datos(id) {
        var codigo_producto = $("#codigo_producto" + id).val();
        var nombre_producto = $("#nombre_producto" + id).val();
        var estado = $("#estado" + id).val();
        var precio_producto = $("#precio_producto" + id).val();
        $("#mod_id").val(id);
        $("#mod_codigo").val(codigo_producto);
        $("#mod_nombre").val(nombre_producto);
        $("#mod_precio").val(precio_producto);
        $("#mod_estado").val(estado);
    }


</script>

<script>
    function showEdit(editableObj) {
        $(editableObj).css("background", "#FFF");
    }

    function saveToDatabase(editableObj, column, id) {
        $(editableObj).css("background", "#FFF url(loaderIcon.gif) no-repeat right");
        $.ajax({
            url: "server.php",
            type: "POST",
            data: 'column=' + column + '&editval=' + editableObj.innerHTML + '&id=' + id,
            success: function (data) {
                $(editableObj).css("background", "#FDFDFD");
            }
        });
    }
</script>