<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Información</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f4f4f4;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        button {
            padding: 10px 15px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .hidden {
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Seleccione el tipo de persona</h2>
        <form id="form">
            <label>
                <input type="radio" name="tipo_persona" value="natural" required onchange="showForm()">
                Natural
            </label><br>
            <label>
                <input type="radio" name="tipo_persona" value="juridica" required onchange="showForm()">
                Jurídica
            </label><br><br>
            
            <div id="form-personal" class="hidden">
                <h3>Formulario Personal</h3>
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" required><br><br>
                <label for="apellido">Apellido:</label>
                <input type="text" id="apellido" name="apellido" required><br><br>
                <label for="dni">DNI:</label>
                <input type="text" id="dni" name="dni" required><br><br>
            </div>

            <div id="form-juridico" class="hidden">
                <h3>Formulario Jurídico</h3>
                <label for="razon_social">Razón Social:</label>
                <input type="text" id="razon_social" name="razon_social" required><br><br>
                <label for="ruc">RUC:</label>
                <input type="text" id="ruc" name="ruc" required><br><br>
                <label for="representante">Representante Legal:</label>
                <input type="text" id="representante" name="representante" required><br><br>
            </div>

            <button type="submit">Enviar</button>
        </form>
    </div>

    <script>
        function showForm() {
            const tipoPersona = document.querySelector('input[name="tipo_persona"]:checked').value;
            document.getElementById('form-personal').classList.toggle('hidden', tipoPersona !== 'natural');
            document.getElementById('form-juridico').classList.toggle('hidden', tipoPersona !== 'juridica');
        }
    </script>
</body>
</html>