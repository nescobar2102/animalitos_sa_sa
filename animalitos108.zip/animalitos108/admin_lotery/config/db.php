<?php
  /**
define('DB_HOST', 'localhost');//DB_HOST:  generalmente suele ser "127.0.0.1"
define('DB_USER', 'root');//Usuario de tu base de datos
define('DB_PASS', '0!1fipRYPJixU5h');//Contraseña del usuario de la base de datos
define('DB_NAME', 'morpheus_loteria');//Nombre de la base de datos**/
 

define('DB_HOST', 'localhost');//DB_HOST:  generalmente suele ser "127.0.0.1"
define('DB_USER', 'root');//Usuario de tu base de datos 
define('DB_NAME', 'morpheus_loteria_1');//Nombre de la base de datos
define('DB_PASS', '');//Contraseña del usuario de la base de datos

?>
