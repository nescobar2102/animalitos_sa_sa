<?php

/* Connect To Database */
require_once ("config/db.php"); //Contiene las variables de configuracion para conectar a la base de datos
require_once ("config/conexion.php"); //Contiene funcion que conecta a la base de datos

$colum = $_POST["column"];
$val = $_POST["editval"];
$id = $_POST["id"];

$update = "update resultados SET $colum='$val' where id='$id'";
$status = mysqli_query($con, $update) or die("database error:" . mysqli_error($con));
?>