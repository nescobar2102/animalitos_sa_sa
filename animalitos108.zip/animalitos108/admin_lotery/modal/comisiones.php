	<!-- Modal -->
	<div class="modal fade" id="nuevoComisiones" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel"> Comisiones</h4>
		  </div>
		  <div class="modal-body">
			<form class="form-horizontal" method="post" id="guardar_comision" name="guardar_comision">
			<div id="resultados_ajax2"></div>
                        
                         <div class="form-group">
                        <label for="comision" class="col-sm-3 control-label">Comision Triple</label>
                        <div class="col-sm-5">
                             <input type="text" class="form-control" value="0.00" id="comision_t" name="comision_t" placeholder="Comision Triple" required pattern="^[0-9]{1,5}(\.[0-9]{0,2})?$" title="Ingresa sólo números con 0 ó 2 decimales" maxlength="10">
                             <input type="hidden" id="id_usuarios" name="id_usuarios" value="">
                        </div>
                         </div>
                        <div class="form-group">
                        <label for="codigo" class="col-sm-3 control-label">Comision Terminal</label>
                        <div class="col-sm-5">
                                    <input type="text" class="form-control" value="0.00" id="comision_ter" name="comision_ter" placeholder="Comision Terminal" required pattern="^[0-9]{1,5}(\.[0-9]{0,2})?$" title="Ingresa sólo números con 0 ó 2 decimales" maxlength="10">

                        </div>
                         </div>
			  <div class="form-group">
				<label for="codigo" class="col-sm-3 control-label"> Pago triple</label>
				<div class="col-sm-5">
                                    <select class="form-control" id="pago" name="pago" required>
									<option value="">-- Selecciona --</option>
									<?php foreach (range(5, 15) as $num): ?>										
											<option value="<?php echo $num; ?>"><?php echo $num ; ?></option>
											<?php endforeach; ?>
                                    </select>
                                </div>
			  </div>
			  <div class="form-group">
				<label for="codigo" class="col-sm-3 control-label"> Pago Terminal</label>
				<div class="col-sm-5">
                                    <select class="form-control" id="pagot" name="pagot" required>
                                        <option value="">-- Selecciona --</option>
										<?php foreach (range(5, 15) as $num): ?>
											<option value="<?php echo $num; ?>"><?php echo $num ; ?></option>
											<?php endforeach; ?>
                                    </select>
                                </div>
			  </div>
			  <div class="form-group">
				<label for="moneda" class="col-sm-3 control-label">Moneda</label>
				<div class="col-sm-5">
				<select class='form-control input-sm' name="moneda" id="moneda"  required>
										<?php 
											$sql="select id,name, symbol from currencies WHERE estatus=1 order by name";
											$query=mysqli_query($con,$sql);
											while($rw=mysqli_fetch_array($query)){
												$id=$rw['id'];
												$simbolo=$rw['symbol'];
												$moneda=$rw['name'];
												if ($row['id']==$id){
													$selected="selected";
												} else {
													$selected="";
												}
												?>
												<option value="<?php echo $id;?>" <?php echo $selected;?>><?php echo $moneda; echo " - "; echo ($simbolo);?></option>
												<?php
											}
										?>
							</select>
                                </div>
			  </div>
			 
			 
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
			<button type="submit" class="btn btn-primary" id="guardar_datos">Guardar datos</button>
		  </div>
		  </form>
		</div>
	  </div>
	</div>