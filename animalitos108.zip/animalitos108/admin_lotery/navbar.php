<?php
  
  require_once ("config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
  require_once ("config/conexion.php");//Contiene funcion que conecta a la base de datos

    if (isset($title))  {       
        if (session_status() == PHP_SESSION_NONE) {
          session_start();
         }
      	if (!isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] != 1) {
            header("location: login.php");
            exit;
        }
        $session_id = $_SESSION['user_id'];
               
        $query=mysqli_query($con,"select * from permisos where user_id='$session_id'");
	      $rw=mysqli_fetch_array($query);
          $vender_r=$rw['vender_r'];
          $loteria=$rw['vender'];
          $pagar=$rw['pagar'];
          $anular=$rw['anular'];
          $crear_taq=$rw['crear_taquilla'];
          $reportes=$rw['reportes'];
          $crear_lot=$rw['crear_lot'];
          $crear_r=$rw['crear_r'];
          $permisos=$rw['permisos']; 
?>  

<nav class="navbar navbar-default" role="navigation">
  <!-- El logotipo y el icono que despliega el menú se agrupan
       para mostrarlos mejor en los dispositivos móviles -->
  
 
  <!-- Agrupar los enlaces de navegación, los formularios y cualquier
       otro elemento que se pueda ocultar al minimizar la barra -->
  <div class="collapse navbar-collapse navbar-ex1-collapse">
 
    <ul class="nav navbar-nav">
      <li class="dropdown">
         <img src="img/iconos/logo1.png">           
      </li>
     
       <!--li class="dropdown">
           <a href="" class="dropdown-toggle" data-toggle="dropdown">
           <img src="img/iconos/administrador.png"  width="40px">
        
          Administrador<b class="caret"></b>
        </a>
        <ul class="dropdown-menu">
          <li><a href="bloqueo.php">Bloquear Núm Jug</a></li>
           <?php if ($crear_lot=='1'){ ?>
              <li><a href="tipo_loteria.php">Tipo Loteria</a></li>
              <li><a href="productos.php">Nuevo Loteria</a></li>
              <li><a href="jugadas.php">Tipos Jugadas</a></li>
              <li><a href="signo.php">Tipos Signos</a></li>
          <?php } ?>
           <?php if ($crear_r=='1'){ ?>
            <li><a href="productos_r.php">Configurar Animalitos</a></li>         
            <li><a href="ruleta.php">Nuevos Animalitos</a></li>
           <?php } ?>
        </ul>
      </li-->
       
      
       <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
           <img src="img/iconos/LOTERIA.png"  width="40px">
       
          Loteria <b class="caret"></b>
        </a>
        <ul class="dropdown-menu">
            <li><a href="resultados.php">Cargar Resultados  </a></li>            
            <li><a href="scrape.php">Buscar Resultados  </a></li>     
            <li><a href="facturas.php">Ticket Vendidos </a></li>
            <li><a href="num_vendidos.php">Numeros mas vendidos</a></li>
            <li><a href="premio.php">Premios por sorteo</a></li>
            <li><a href="venta_sorteo.php">Venta por sorteo</a></li>
        </ul>
      </li>
        <!--li class="dropdown">
          
        <a href="" class="dropdown-toggle" data-toggle="dropdown">
              <img src="img/iconos/banca.png"  width="40px">
          Banca<b class="caret"></b>
        </a>
        <ul class="dropdown-menu">
             <?php if ($permisos=='1'){ ?>
            <li ><a href="usuarios.php">Usuarios-Permisos</a></li>
              <?php } ?>
          <li ><a href="ventas.php">Ventas</a></li>
      
        </ul>
      </li>
       <li class="dropdown">
          
        <a href="" class="dropdown-toggle" data-toggle="dropdown">
             <img src="img/iconos/reportes.png" width="40px">
          Reportes<b class="caret"></b>
        </a>
        <ul class="dropdown-menu">
             <?php if ($reportes=='1'){ ?>
          <li ><a href="ventas_1.php">Historico de Ventas</a></li>        
          <li ><a href="ticket_premiado.php">Ticket Premiado</a></li>    
          <?php } ?>
        </ul>
      </li-->
    </ul>
    <ul class="nav navbar-nav navbar-right">
         <li>            
             <a href="" target='_blank'>  <img src="img/iconos/soporte.png" width="40px">
                 Soporte</a>
            </li>
	 <li>             
             <a href="login.php?logout"><img src="img/iconos/cerrar sesion.png" width="40px">
                 Salir</a></li>
    </ul>
  </div>
</nav>

<?php
 }else {  ?>  
  <nav class="navbar navbar-default" role="navigation">
  <!-- El logotipo y el icono que despliega el menú se agrupan
       para mostrarlos mejor en los dispositivos móviles -->
  
 
  <!-- Agrupar los enlaces de navegación, los formularios y cualquier
       otro elemento que se pueda ocultar al minimizar la barra -->
  <div class="collapse navbar-collapse navbar-ex1-collapse">
 
    <ul class="nav navbar-nav">
      <li class="dropdown">
         <img src="img/iconos/logo1.png">           
      </li>
     
       <li class="dropdown">
           <a href="" class="dropdown-toggle" data-toggle="dropdown">
           <img src="img/iconos/administrador.png"  width="40px">
        
          Administrador Lotto Pal-Parley<b class="caret"></b>
        </a> 
      </li> 
 </ul>
  </div>
</nav>
<?php } 

?>