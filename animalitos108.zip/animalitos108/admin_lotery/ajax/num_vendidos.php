<?php
/* -------------------------
  Descripcion:Sistema de Venta y Control de juegos de azar
  Autor: Ing .Norbelys Naguanagua
  Mail: norbelysnaguanagua21@gmail.com
  Version: 1.1
  --------------------------- */
include('is_logged.php'); //Archivo verifica que el usario que intenta acceder a la URL esta logueado
/* Connect To Database */
require_once ("../config/db.php"); //Contiene las variables de configuracion para conectar a la base de datos
require_once ("../config/conexion.php"); //Contiene funcion que conecta a la base de datos

$action = (isset($_REQUEST['action']) && $_REQUEST['action'] != NULL) ? $_REQUEST['action'] : '';
if (isset($_GET['id'])) {
    $id_vendedor = $_SESSION['user_id'];
    $status = intval($_GET['s']);
    
    $numero_factura = intval($_GET['id']);
}
if ($action == 'ajax') {
    $q = mysqli_real_escape_string($con, (strip_tags($_REQUEST['q'], ENT_QUOTES)));
    $sorteo = mysqli_real_escape_string($con, (strip_tags($_REQUEST['sorteo'], ENT_QUOTES)));
    $id_vendedor = $_SESSION['user_id'];


    if ($id_vendedor === '1') {
        $adm = "select numero_factura ,symbol from facturas ,users ,currencies
                    where facturas.id_vendedor=users.user_id and facturas.id_moneda=currencies.id ";
    } else {
       $adm = "select numero_factura ,symbol from facturas ,users ,currencies
                    where facturas.id_vendedor=users.user_id and facturas.id_moneda=currencies.id 
                    and users.id_admin='$id_vendedor'";
    }
    $queryadm = mysqli_query($con, $adm);

    $idf = "";
    while ($row3 = mysqli_fetch_array($queryadm)) {
        $id = $row3['numero_factura'];
        $symbol = $row3['symbol'];
        $idf = $idf . "" . $id . "," . "";
    }

    $sql = "select count( cantidad) as numero_v_juga ,cantidad, id_producto,sum(precio_venta) as venta"
            . " from detalle_factura where fecha='$q' and id_producto='$sorteo' group by cantidad,id_producto";

    $query = mysqli_query($con, $sql);

    $row = mysqli_num_rows($query);
    
    if($row>0){
    //loop through fetched data
    ?>
    <div class="table-responsive">
        <table class="table">
            <tr  class="info">
                <th>N# jugadas</th>
                <th>Número Vendido</th>
                <th>Loteria</th>
                <th>Monto de Apuesta</th>
                <th>Fecha</th>
            </tr>
    <?php
    while ($row = mysqli_fetch_array($query)) {
        $numero_v_juga = $row['numero_v_juga'];
        $numero = $row['cantidad'];
        $id_loteria = $row['id_producto'];
        $ventas = $row['venta'];
        $fecha = $q;

        $sql1 = "select * from products where id_producto=$id_loteria";
        $query1 = mysqli_query($con, $sql1);
        $row1 = mysqli_fetch_array($query1);
        $name = $row1['nombre_producto'];
        $tipo = $row1['tipo'];

        //busca el numero equivalente a la ruleta seleccionada
        if ($tipo == "2") {
            $sql33 = "select * from ruleta where id='$numero'";
            $query33 = mysqli_query($con, $sql33);
            $row33 = mysqli_fetch_array($query33);
            $numero = $row33['nombre'];
        }
        ?>
            <tr>
                <td><?php echo $numero_v_juga; ?></td>
                <td><?php echo $numero; ?></td>
                <td><?php echo $name; ?></td>
                <td><?php echo number_format($ventas, 2); echo " ";?></td>
                <td><?php echo $fecha; ?></td>	
            </tr>
        <?php
         }
    ?>
        </table>
    </div>
            <?php
        }else { ?>
              <div class="alert alert-success alert-dismissible" role="alert">
			  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			  <strong>Aviso!</strong> No existen tickets vendidos para la fecha seleccionada.
			</div>
       <?php } }
 ?>