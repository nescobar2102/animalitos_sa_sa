    <?php
	/*-------------------------
        Descripcion:Sistema de Venta y Control de juegos de azar
	Autor: Ing .Norbelys Naguanagua	 
	Mail: norbelysnaguanagua21@gmail.com
        Version: 1.1       
	---------------------------*/
	include('is_logged.php');//Archivo verifica que el usario que intenta acceder a la URL esta logueado
	/* Connect To Database*/
	require_once ("../config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
	require_once ("../config/conexion.php");//Contiene funcion que conecta a la base de datos
	
	$action = (isset($_REQUEST['action'])&& $_REQUEST['action'] !=NULL)?$_REQUEST['action']:'';

		if($action == 'ajax'){
				// escaping, additionally removing everything that could be (html/javascript-) code
		$q = mysqli_real_escape_string($con,(strip_tags($_REQUEST['q'], ENT_QUOTES)));
		$p = mysqli_real_escape_string($con,(strip_tags($_REQUEST['p'], ENT_QUOTES)));
		$sTable = "products";  
		 
		include 'pagination.php'; //include pagination file
		//pagination variables
		$page = (isset($_REQUEST['page']) && !empty($_REQUEST['page']))?$_REQUEST['page']:1;
		$per_page = 10; //how much records you want to show
		$adjacents  = 4; //gap between pages after number of adjacents
		$offset = ($page - 1) * $per_page;
		//Count the total number of row in your table*/
		$count_query   = mysqli_query($con, "SELECT count(*) AS numrows FROM $sTable ");
		$row= mysqli_fetch_array($count_query);
		$numrows = $row['numrows'];
		$total_pages = ceil($numrows/$per_page);
		$reload = './facturas.php';
		//main query to fetch the data
		$sql=" SELECT  * from $sTable ";
		$query = mysqli_query($con, $sql);
		//loop through fetched data
		if ($numrows>0){ 
			?>
			<div class="table-responsive">
			  <table class="table ">
				<tr  class="info">
					<th>ID</th>
					<th>Nombre</th>					
					<th>Ventas</th>
					<th>Premios</th>
                    <th>Comision</th>					
					<th>Participacion</th>
					<th>Total</th> 
				</tr>
				<?php
					
					$ventast=0;
					$premiost=0;
					$comisiont=0;
					$particit=0;
					$totalt=0;

				while ($row=mysqli_fetch_array($query)){
					  $codigo_loteria=$row['codigo_producto'];
						$id_loteria=$row['id_producto'];
						$nombre=$row['nombre_producto'];      
						$tipo_loteria=$row['tipo'];      
						if($tipo_loteria==1)    { 

		 		 	$sql1=" SELECT sum(detalle_factura.precio_venta) as ventas, sum(detalle_factura.premio) as premios ,
										sum( precio_venta*( select comision_terminal from comisiones where pago_id_vendedor=id_vendedor )/100 ) as comision ,currencies.symbol 
										FROM facturas,detalle_factura,currencies  where facturas.numero_factura=detalle_factura.numero_factura
										 and estado_factura in(1,2,3)
										and id_producto='$id_loteria'
										and fecha BETWEEN '$q'  AND '$p' and facturas.id_moneda=currencies.id GROUP by facturas.id_moneda"; 
						}   else {
						$sql1=" SELECT sum(detalle_factura.precio_venta) as ventas, sum(detalle_factura.premio) as premios ,
										sum( precio_venta*( select comision_terminal from comisiones where pago_id_vendedor=id_vendedor )/100 ) as comision ,currencies.symbol 
										FROM facturas,detalle_factura,currencies  where facturas.numero_factura=detalle_factura.numero_factura
										 and estado_factura in(1,2,3)
										and id_producto='$id_loteria'
										and fecha BETWEEN '$q'  AND '$p' and facturas.id_moneda=currencies.id GROUP by facturas.id_moneda"; 
						}                        
		 
								$query22  = mysqli_query($con, $sql1);
										while ($row1=mysqli_fetch_array($query22)){ 
											$ventas=$row1['ventas'];
											$premios=$row1['premios'];
											$comision=$row1['comision'];
											$symbol=$row1['symbol'];
											$total= $ventas-($premios+$comision); 
									?>
									<tr>
										<td><?php echo $id_loteria; ?></td>
										<td><?php echo $nombre; ?></td>
										<td><?php echo number_format ($ventas,2);  echo " ";echo $symbol; ?></td>
										<td><?php echo number_format ($premios,2); echo " ";echo $symbol;?></td>
										<td><?php echo number_format ($comision,2);  echo " ";echo $symbol;?></td>	
										<td><?php echo number_format ($particit,2);  echo " ";echo $symbol;?></td>	
										<td><?php echo number_format ($total,2);  echo " ";echo $symbol;?></td>	 
									</tr>
									<?php					
										$ventast=$ventast+$ventas;
										$premiost=$premiost+$premios;
										$comisiont=$comisiont+$comision;
										$particit=$particit+$particit;
										$totalt=$totalt+$total;
										}
					}
                ?>
                   <!--tr  class="info">
					<th>******</th>                                      
					<th>******</th>					
					<th><?php echo number_format ($ventast,2); ?></th>
					<th><?php echo number_format ($premiost,2); ?></th>
                    <th><?php echo number_format ($comisiont,2); ?></th>					
					<th><?php echo number_format ($particit,2); ?></th>
					<th><?php echo number_format ($totalt,2); ?></th>
                    <th></th> 
					
				</tr-->
			  </table>
			</div>
			<?php
		}
	}
?>