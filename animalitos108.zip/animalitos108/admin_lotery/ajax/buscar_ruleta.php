<?php

	/*-------------------------
        Descripcion:Sistema de Venta y Control de juegos de azar
	Autor: Ing .Norbelys Naguanagua	 
	Correo: norbelysnaguanagua21@gmail.com
        Version: 1.1      
	---------------------------*/
	include('is_logged.php');//Archivo verifica que el usario que intenta acceder a la URL esta logueado
	/* Connect To Database*/
	require_once ("../config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
	require_once ("../config/conexion.php");//Contiene funcion que conecta a la base de datos
	//Archivo de funciones PHP
	include("../funciones.php");
	$action = (isset($_REQUEST['action'])&& $_REQUEST['action'] !=NULL)?$_REQUEST['action']:'';
      
	if (isset($_POST['numero'])){$numero=$_POST['numero'];}
            if (isset($_POST['imagen'])){$imagen=$_POST['imagen'];}
            if (isset($_POST['id'])){$id_tipo=$_POST['id'];}
            if (isset($_POST['color'])){$color=$_POST['color'];}
            if (isset($_POST['action1'])){$action1=$_POST['action1'];}

        if (isset($_POST['action1'] ) && $action1=='insertar'){  
                        $query=mysqli_query($con, "insert into ruleta (nombre,color,status,ruta_img,id_tipo_ruleta)
                        values ('$numero','$color','1','$imagen','$id_tipo')");
             }  
                if($action=='ajax'){  ?>
                <br>
                        <table class="table">
                        <tr  class="info">
                                <th>Numero-Nombre </th>
                                <th>Color</th>
                                <th>Imagen</th>
                                <th>Acciones</th>
                        </tr>
                        <?php
                        
                    $sql=mysqli_query($con, "select * from ruleta where id_tipo_ruleta='$_GET[q]'");
                    while ($row=mysqli_fetch_array($sql))
                    {
                    $id=$row["id"];
                    $nombre=$row['nombre'];
                    $color=$row['color'];
                    $imagen=$row['ruta_img'];

		?>
                <tr> 
                        <td><?php echo $nombre ;?></td>
                        <td class=''><?php echo $color;?></td>
			<td class=''><?php echo $imagen;?></td>	
			<td class=''><a title='Borrar' href="#" onclick="eliminar('<?php echo $id ?>')"><img src="img/iconos/eliminar.png" width="30px"> </a></td>
		</tr>		
                  
	 <?php
                    
             }
           }
        
?>