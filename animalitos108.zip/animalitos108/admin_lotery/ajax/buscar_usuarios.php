<?php
/* -------------------------
  Descripcion:Sistema de Venta y Control de juegos de azar
  Autor: Ing .Norbelys Naguanagua
  Mail: norbelysnaguanagua21@gmail.com
  Version: 1.0
  --------------------------- */
/* Connect To Database */
require_once ("../config/db.php"); //Contiene las variables de configuracion para conectar a la base de datos
require_once ("../config/conexion.php"); //Contiene funcion que conecta a la base de datos
include('is_logged.php'); //Archivo verifica que el usario que intenta acceder a la URL esta logueado
$action = (isset($_REQUEST['action']) && $_REQUEST['action'] != NULL) ? $_REQUEST['action'] : '';
$id_vendedor = $_SESSION['user_id'];
if (isset($_GET['id'])) {

    $user_id = intval($_GET['id']);
    $query = mysqli_query($con, "select * from users where user_id='" . $id_vendedor . "'");
    $rw_user = mysqli_fetch_array($query);
    $count = $rw_user['user_id'];
    if ($user_id != 1) {
        if ($delete1 = mysqli_query($con, "DELETE FROM users WHERE user_id='" . $user_id . "'")) {
            ?>
            <div class="alert alert-success alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <strong>Aviso!</strong> Datos eliminados exitosamente.
            </div>v
            <?php
        } else {
            ?>
            <div class="alert alert-danger alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <strong>Error!</strong> Lo siento algo ha salido mal intenta nuevamente.
            </div>
            <?php
        }
    } else {
        ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong>Error!</strong> No se puede borrar el usuario administrador. 
        </div>
        <?php
    }
}
if ($action == 'ajax') {
    // escaping, additionally removing everything that could be (html/javascript-) code
    $q = mysqli_real_escape_string($con, (strip_tags($_REQUEST['q'], ENT_QUOTES)));
    $aColumns = array('user_name'); //Columnas de busqueda
    $sTable = "users";
    $sWhere = "";
    if ($_GET['q'] != "") { 
        $select = $_GET['q'];
    }
    if ($_GET['tipo'] != "") { 
        $user_tipo = $_GET['tipo'];
    }
    if ($_GET['iduser'] != "") { 
        $user_depende = $_GET['iduser'];
    }
    $sWhere.="  order by user_id desc";
    include 'pagination.php'; //include pagination file
    //pagination variables
    $page = (isset($_REQUEST['page']) && !empty($_REQUEST['page'])) ? $_REQUEST['page'] : 1;
    $per_page = 10; //how much records you want to show
    $adjacents = 4; //gap between pages after number of adjacents
    $offset = ($page - 1) * $per_page;  
    $search = '';
    $reload = './usuarios.php';
    //main query to fetch the data
    $id_vendedor = $_SESSION['user_id']; 
    if($user_tipo!='0'){
    switch ($user_tipo) {
        case '1': 
             $search = "and id_administrador='$user_depende' and id_banca=0 ";                               
            break;
        case '2':                    
            $search = "and id_banca='$user_depende' and id_intermediario=0";     
          break; 
        case '4':
            $search = "and id_intermediario='$user_depende'  and  id_agencia=0 ";    
            break;
        case '5':
            $search = "and id_agencia='$user_depende' ";    
            break;
      
    }
        }else{
            $search = "and tipo_user='$select' ";    
        }
    $sql = "SELECT * FROM  $sTable where id_admin='$id_vendedor' $search order by id_admin  LIMIT $offset,$per_page";
    $query = mysqli_query($con, $sql);
    $numrows=mysqli_num_rows($query);
    $total_pages = ceil($numrows / $per_page);
    //loop through fetched data
    if ($numrows > 0) {
        ?>
       <div class="table-responsive"> 
       <table class="table">
                <tr class="info">
                    <th></th>
                    <th>Nombres y Apellidos</th>
                    <th>Usuario</th>
                    <th>Tipo Usuario</th>
                    <th>Fecha creación</th>
                    <th><span class="pull-right">Acciones</span></th>
                </tr>
    </table>
 <?php
          while ($row = mysqli_fetch_array($query)) {
                    $user_id = $row['user_id'];

                    $fullname = $row['firstname'] . " " . $row["lastname"];
                    $user_name = $row['user_name'];
                    $user_tipo_o = $row['tipo_user']; 
                
                    switch ($user_tipo_o) {
                        case '4':                        
                            $user_tipo = 'Intermediario';                      
                            break;
                        case '2':                    
                            $user_tipo = 'Banca';
                          break;
                        case '3':
                            $user_tipo = 'Taquilla';
                            break;
                        case '1':
                            $user_tipo = 'Administrador';                     
                            break;
                        case '5':
                            $user_tipo = 'Agencia';
                            break;
                    }

                    $date_added = date('d/m/Y', strtotime($row['date_added']));

                    $com = "select * from comisiones where pago_id_vendedor='$user_id'";
                    $querycom = mysqli_query($con, $com);
                    $rowcom = mysqli_fetch_array($querycom); 
                        ?>
                         <div class="panel-group" id="accordion">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                 <h4 class="panel-title">
                                 <p data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $user_id; ?>"><?php echo $fullname; ?></p>
                                 </h4>

                                 </div>
                                 <div id="collapse<?php echo $user_id; ?>" class="panel-collapse collapse">
                                 <div class="panel-body">
                                        <input type="hidden" value="<?php echo $rowcom['comision_triple']; ?>" id="triple<?php echo $user_id; ?>">
                                        <input type="hidden" value="<?php echo $rowcom['comision_terminal']; ?>" id="terminal<?php echo $user_id; ?>">
                                        <input type="hidden" value="<?php echo $rowcom['pago_terminal']; ?>" id="pagot<?php echo $user_id; ?>">
                                        <input type="hidden" value="<?php echo $rowcom['pago_triple']; ?>" id="pago<?php echo $user_id; ?>">
                                        <input type="hidden" value="<?php echo $rowcom['id_moneda']; ?>" id="moneda<?php echo $user_id; ?>">
                                        <input type="hidden" value="<?php echo $row['firstname']; ?>" id="nombres<?php echo $user_id; ?>">
                                        <input type="hidden" value="<?php echo $row['lastname']; ?>" id="apellidos<?php echo $user_id; ?>">
                                        <input type="hidden" value="<?php echo $user_name; ?>" id="usuario<?php echo $user_id; ?>">
                                    <table class="table">
                            
                                        <tr>
                                            <td><?php ?></td>
                                            <td><?php echo $fullname; ?></td>
                                            <td> <a  onclick="load('<?=$user_tipo_o; ?>' ,'<?= $user_id; ?>')" ><?php echo $user_name; ?></a></td>
                                            <td><?php echo $user_tipo; ?></td>
                                            <td><?php echo $date_added; ?></td>
                                            <td><span class="pull-right">

                                            <a  title='Modificar' onclick="obtener_datos('<?php echo $user_id; ?>');" data-toggle="modal" data-target="#myModal2"><img src="img/iconos/activar.png" width="40px"> </a>

                                            <a title='Permisos de usuario' onclick="redirect('<?php echo $user_id; ?>');" ><img src="img/iconos/permisos.png" width="40px"> </a>
                                            <a title='Eliminar Taquilla/Administrador' onclick="eliminar('<?php echo $user_id; ?>')">
                                                <img src="img/iconos/eliminar_administrador.png" width="40px"> </a>
                                            <a title='Limitar Sorteos' data-toggle="modal" data-target="#nuevoLimite" onclick="bloq_num('<?php echo $user_id; ?>');">
                                                <img src="img/iconos/limitar_sorteo.png" width="40px"> </a>
                                            <a title='Comisiones' onclick="obtener_comision('<?php echo $user_id; ?>');" data-toggle="modal" data-target="#nuevoComisiones" >
                                                <img src="img/iconos/porcentaje.png" width="40px"> </a>
                                            <a title='Limite de Venta' onclick="limite('<?php echo $user_id; ?>');"  >
                                                <img src="img/iconos/limite_taq.png" width="40px"> </a>

                                            </td>

                                        </tr>
                                        </table>
                            </div>
                        </div>
                        </div>
                        <?php  
                }
                ?>  
   
</div>
        <!--div class="table-responsive">
            <table class="table">
                <tr class="info">
                    <th></th>
                    <th>Nombres y Apellidos</th>
                    <th>Usuario</th>
                    <th>Tipo Usuario</th>
                    <th>Fecha creación</th>
                    <th><span class="pull-right">Acciones</span></th>
                </tr>
                <?php
                while ($row = mysqli_fetch_array($query)) {
                    $user_id = $row['user_id'];

                    $fullname = $row['firstname'] . " " . $row["lastname"];
                    $user_name = $row['user_name'];
                    $user_tipo = $row['tipo_user']; 
                
                    switch ($user_tipo) {
                        case '4':                        
                            $user_tipo = 'Intermediario';
                      
                            break;
                        case '2':                    
                            $user_tipo = 'Banca';
                          break;
                        case '3':
                            $user_tipo = 'Taquilla';
                            break;
                        case '1':
                            $user_tipo = 'Administrador';                     
                            break;
                        case '5':
                            $user_tipo = 'Agencia';
                            break;
                    }

                    $date_added = date('d/m/Y', strtotime($row['date_added']));

                    $com = "select * from comisiones where pago_id_vendedor='$user_id'";
                    $querycom = mysqli_query($con, $com);
                    $rowcom = mysqli_fetch_array($querycom); 
                        ?>
                        <input type="hidden" value="<?php echo $rowcom['comision_triple']; ?>" id="triple<?php echo $user_id; ?>">
                        <input type="hidden" value="<?php echo $rowcom['comision_terminal']; ?>" id="terminal<?php echo $user_id; ?>">
                        <input type="hidden" value="<?php echo $rowcom['pago_terminal']; ?>" id="pagot<?php echo $user_id; ?>">
                        <input type="hidden" value="<?php echo $rowcom['pago_triple']; ?>" id="pago<?php echo $user_id; ?>">
                        <input type="hidden" value="<?php echo $rowcom['id_moneda']; ?>" id="moneda<?php echo $user_id; ?>">
                        <input type="hidden" value="<?php echo $row['firstname']; ?>" id="nombres<?php echo $user_id; ?>">
                        <input type="hidden" value="<?php echo $row['lastname']; ?>" id="apellidos<?php echo $user_id; ?>">
                        <input type="hidden" value="<?php echo $user_name; ?>" id="usuario<?php echo $user_id; ?>">

                        <tr>
                            <td><?php ?></td>
                            <td><?php echo $fullname; ?></td>
                            <td><?php echo $user_name; ?></td>
                            <td><?php echo $user_tipo; ?></td>
                            <td><?php echo $date_added; ?></td>
                            <td><span class="pull-right">

                                    <a  title='Modificar' onclick="obtener_datos('<?php echo $user_id; ?>');" data-toggle="modal" data-target="#myModal2"><img src="img/iconos/activar.png" width="40px"> </a>

                                    <a title='Permisos de usuario' onclick="redirect('<?php echo $user_id; ?>');" ><img src="img/iconos/permisos.png" width="40px"> </a>
                                    <a title='Eliminar Taquilla/Administrador' onclick="eliminar('<?php echo $user_id; ?>')">
                                        <img src="img/iconos/eliminar_administrador.png" width="40px"> </a>
                                    <a title='Limitar Sorteos' data-toggle="modal" data-target="#nuevoLimite" onclick="bloq_num('<?php echo $user_id; ?>');">
                                        <img src="img/iconos/limitar_sorteo.png" width="40px"> </a>
                                    <a title='Comisiones' onclick="obtener_comision('<?php echo $user_id; ?>');" data-toggle="modal" data-target="#nuevoComisiones" >
                                        <img src="img/iconos/porcentaje.png" width="40px"> </a>
                                    <a title='Limite de Venta' onclick="limite('<?php echo $user_id; ?>');"  >
                                        <img src="img/iconos/limite_taq.png" width="40px"> </a>

                            </td>

                        </tr>
                        <?php  
                }
                ?>
                <tr>
                    <td colspan=9><span class="pull-right">
                            <?php
                            echo paginate($reload, $page, $total_pages, $adjacents);
                            ?></span></td>
                </tr>
            </table>
        </div>
 
        <?php
    }else{ ?>
        <div class="alert alert-info alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
         <strong>Aviso!</strong>  NO EXISTEN USUARIOS 
                      
        </div-->
             
    <?php }
}
?>
