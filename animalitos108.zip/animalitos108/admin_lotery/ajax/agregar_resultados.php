<?php

//
/* -------------------------
  Descripcion:Sistema de Venta y Control de juegos de azar
  Autor: Ing .Norbelys Naguanagua
  Mail: norbelysnaguanagua21@gmail.com
  Version: 1.1
  --------------------------- */
include('is_logged.php'); //Archivo verifica que el usario que intenta acceder a la URL esta logueado
$session_id = session_id();
$id_vendedor = $_SESSION['user_id'];

if (isset($_POST['id'])) {
    $id = $_POST['id'];
}
if (isset($_POST['cantidad'])) {
    $cantidad = $_POST['cantidad'];
}
if (isset($_POST['signo'])) {
    $signo = $_POST['signo'];
}

/* Connect To Database */
require_once ("../config/db.php"); //Contiene las variables de configuracion para conectar a la base de datos
require_once ("../config/conexion.php"); //Contiene funcion que conecta a la base de datos
//Archivo de funciones PHP
include("../funciones.php");
ini_set('date.timezone','America/Caracas'); 
$hora= date('H:i:s');  
$fecha = date('Y-m-d');
if (!empty($id) and ! empty($cantidad)) {

    if ($signo == "") {
        $signo =1;
    }
        $count_query = mysqli_query($con, "SELECT count(*) AS numrows from resultados where id_loteria='$id' and id_signo='$signo' and fecha_sorteo='$fecha'");
        $row = mysqli_fetch_array($count_query);
        $numrows = $row['numrows'];        
        if ($numrows > 0) {
            $insert_tmp = mysqli_query($con, "update resultados  set numero='$cantidad'  where id_loteria='$id' and id_signo='$signo' and fecha_sorteo='$fecha'");
        } else {
            $insert_tmp = mysqli_query($con, "INSERT resultados (id_loteria,numero,id_signo,fecha_sorteo) VALUES ('$id','$cantidad','$signo','$fecha')");
        }
  
 
    if($insert_tmp){           
   
        $sql=mysqli_query($con, "SELECT * FROM `detalle_factura` WHERE id_producto='$id' and id_signo=$signo and cantidad='$cantidad' and fecha='$fecha'");
        while ($row=mysqli_fetch_array($sql)){
      
              $numero_factura=$row['numero_factura'];  
              $update=mysqli_query($con, "update facturas set estado_factura='3'  where numero_factura='$numero_factura' "); 
     }
 
}

}
    $simbolo_moneda = get_row('perfil', 'moneda', 'id_perfil', 1);
?>
