<?php
/*-------------------------
Descripcion:Sistema de Venta y Control de juegos de azar
Autor: Ing .Norbelys Naguanagua	 
Mail: norbelysnaguanagua21@gmail.com
Version: 1.1       
---------------------------*/

include('is_logged.php');// Archivo verifica que el usuario que intenta acceder a la URL está logueado
/* Connect To Database*/
require_once ("../config/db.php");// Contiene las variables de configuración para conectar a la base de datos
require_once ("../config/conexion.php");// Contiene función que conecta a la base de datos

$action = (isset($_REQUEST['action']) && $_REQUEST['action'] != NULL) ? $_REQUEST['action'] : '';
$id_vendedor = $_SESSION['user_id'];
?>

<div class="card-body">
    <form id="myForm">
        <div class="form-group">
            <label for="tipoLoteria">Tipo Jugada</label>
            <select class="form-control input-sm" id="tipo_jugada" name="tipo_jugada"  onchange="filtrarLoterias()">
                <option value="0">Seleccione</option>  
                    <option value="loterias">Loteria</option>
                    <option value="animalitos">Animalitos</option>
                    <option value="tripleta">Tripleta</option>
                
            </select>
        </div>
        <div class="form-group">
            <label for="tipoLoteria">Lotería</label>
            <div id="loterias-checkboxes">
                <!-- Los checkboxes se insertan aquí dinámicamente -->
            </div>
          
        </div>
        <div class="form-group">
            <label for="horario">Horarios disponibles</label>
            <div id="horario-checkboxes">
                <!-- Los checkboxes se insertan aquí dinámicamente -->
            </div>
        </div>
        <div class="form-group">
            <label for="numero">Número</label>
            <input type="text" class="form-control" id="cantidad" name="cantidad" value="" required>
        </div>
        <button type="submit" class="btn btn-primary">Enviar</button>
    </form>
</div>

<script>
function filtrarHorarios() {
    var id_producto = document.getElementById('id_tipr').value;

    fetch('filtrar_horarios.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'id_producto=' + id_producto
    })
    .then(response => response.text())
    .then(data => {
        document.getElementById('horario-checkboxes').innerHTML = data;
    })
    .catch(error => console.error('Error:', error));
}

function filtrarLoterias() {
    var tipo_jugada = document.getElementById('tipo_jugada').value;

    fetch('filtrar_loterias.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'tipo_jugada=' + tipo_jugada
    })
    .then(response => response.text())
    .then(data => {
        document.getElementById('loterias-checkboxes').innerHTML = data;
    })
    .catch(error => console.error('Error:', error));
}



// Manejar el envío del formulario
document.getElementById('myForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Evitar el envío normal del formulario

    var formData = new FormData(this);

    fetch('guardar_resultados_loterias.php', {  
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        alert('Datos guardados: ' + data); // Puedes manejar la respuesta como desees
    })
    .catch(error => console.error('Error:', error));
});
</script>