<?php
        /*-------------------------
    Descripcion:Sistema de Venta y Control de juegos de azar
	Autor: Ing .Norbelys Naguanagua	 
	Mail: norbelysnaguanagua21@gmail.com
   Version: 1.1      
	---------------------------*/

	include('is_logged.php');//Archivo verifica que el usario que intenta acceder a la URL esta logueado
	/* Connect To Database*/
	require_once ("../config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
	require_once ("../config/conexion.php");//Contiene funcion que conecta a la base de datos
	
	$action = (isset($_REQUEST['action'])&& $_REQUEST['action'] !=NULL)?$_REQUEST['action']:'';
	if($action == 'ajax'){
           $id_vendedor=$_SESSION['user_id'];
           $sorteo= $_GET['sorteo'];
            $fecha= $_GET['q'];
		// escaping, additionally removing everything that could be (html/javascript-) code
         $q = mysqli_real_escape_string($con,(strip_tags($_REQUEST['q'], ENT_QUOTES)));
		 $aColumns = array('fecha_sorteo',);//Columnas de busqueda
		 $sTable = "resultados";
		 $sWhere = "where  id_loteria='$sorteo' and fecha_sorteo='$fecha'";
 
		include 'pagination.php'; //include pagination file
		//pagination variables
		$page = (isset($_REQUEST['page']) && !empty($_REQUEST['page']))?$_REQUEST['page']:1;
		$per_page = 5; //how much records you want to show
		$adjacents  = 4; //gap between pages after number of adjacents
		$offset = ($page - 1) * $per_page;
		//Count the total number of row in your table*/
		$count_query   = mysqli_query($con, "SELECT count(*) AS numrows FROM $sTable  $sWhere");
		$row= mysqli_fetch_array($count_query);
	 	$numrows = $row['numrows'];
		$total_pages = ceil($numrows/$per_page);
		$reload = './index.php';
		//main query to fetch the data
                
		   $sql="SELECT * FROM  $sTable $sWhere LIMIT $offset,$per_page";
		$query = mysqli_query($con, $sql);
		//loop through fetched data
		if ($numrows>0){
			
			?>
			<div class="table-responsive">
			  <table class="table">
				<tr  class="info">				
					<th class='text-center'>Número Sorteado</th>
					<th class='text-center'>Número Ticket</th>
					<th class='text-center'>Monto Premiado</th>
					<th class='text-center' >Ver Ticket</th>
				</tr>
				<?php
                               
			while ($row=mysqli_fetch_array($query)){
							
				$id_signo=$row['id_signo'];
				$numero=$row['numero'];
					 
			   $sql2="  SELECT numero_factura ,id_producto ,cantidad ,fecha ,sum(premio ) as premio ,precio_venta
			 FROM detalle_factura
					where id_producto=$sorteo
					and id_signo='$id_signo'
					and cantidad='$numero' and fecha='$fecha'";
					$query2 = mysqli_query($con, $sql2); 

					while ($row2=mysqli_fetch_array($query2)){
						$numero_factura=$row2['numero_factura'];
						$monto_j=$row2['precio_venta'];
						$premio=$row2['premio'];

						$sql4=mysqli_query($con, "select * from facturas where numero_factura='$numero_factura' ");                                       
						$row4=mysqli_fetch_array($sql4); 
						$id_moneda =$row4['id_moneda']; 
												
						$sql_moneda=mysqli_query($con,"select * from currencies where id='$id_moneda'"); //simbolo moneda
						$rw_moneda=mysqli_fetch_array($sql_moneda);
						$simbolo_moneda = $rw_moneda["symbol"];
 
				?>
				<tr>					 
					<td class='text-center'><?php echo $numero; ?></td>
					<td class='text-center'><?php echo $numero_factura; ?></td>
					<td class='text-center'><?php echo number_format($premio,2); echo " "; echo $simbolo_moneda; ?></td>   
                                     
 					<td class='text-center'>
					 <a title="Ver Ticket"   data-toggle="modal" data-target="#myModalVer3" onclick="ver_ticket('<?php echo $numero_factura; ?>','2')" >
							<img src="img/iconos/ver.png" width="30px">  
				 
				</tr>
				<?php
                    }
                }
				
				?>
				<tr>
					<td colspan=5><span class="pull-right">
					<?php
					 echo paginate($reload, $page, $total_pages, $adjacents);
					?></span></td>
				</tr>
			  </table>
			</div>
			<?php
		}else{ ?>
			<div class="alert alert-info alert-dismissible" role="alert">
			  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			 <strong>Aviso!</strong>  NO EXISTEN PREMIOS EN ESTE SORTEO
                          
			</div>
				 
		<?php }
	}

        