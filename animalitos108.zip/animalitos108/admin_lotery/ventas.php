<?php
session_start();
if (!isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] != 1) {
	header("location: login.php");
	exit;
	}

/* Connect To Database*/
require_once ("config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
require_once ("config/conexion.php");//Contiene funcion que conecta a la base de datos
$active_facturas="";
$active_productos="";
$active_clientes="";
$active_usuarios="active";	
$title="Admin | Usuarios-Permisos";
?>
<!DOCTYPE html>
<html lang="en">
  <head>
	<?php include("head.php");?>
  </head>
  <body>
 	<?php
	include("navbar.php");
	?> 
    <div class="container">
		<div class="panel panel-info">
		<div class="panel-heading">
		  
		<h4><img src="img/iconos/TICKET VENDIDOS.png" width="30px"> Ventas</h4>
                      
		</div>			
			<div class="panel-body">
			<?php
			include("modal/registro_usuarios.php");
			include("modal/editar_usuarios.php");
			include("modal/cambiar_password.php");
                        include("modal/bloquear_num.php");
                         include("modal/comisiones.php");
			
			?>         <div class="form-group row">
                                           
			<label for="q" class="col-md-1 control-label"> Fecha</label>
			<div class="col-md-2">
					<input type="text" class="tcal form-control" id="q">
			</div>
			<div class="col-md-1"></div>

			<div class="col-md-3">
					<button type="button" class="btn btn-default" onclick='load(1);'>
						   Buscar</button>
					<span id="loader"></span>
			</div>

	</div>
				<div id="resultados"></div><!-- Carga los datos ajax -->
				<div class='outer_div'></div><!-- Carga los datos ajax -->
						
			</div>
		</div>

	</div>
	<hr>
	<?php
	include("footer.php");
	?>
	 	<script type="text/javascript" src="js/usuarios.js"></script>
	<script type="text/javascript" src="js/ventas.js"></script>
  </body>
</html>
<script type="text/javascript">
  
	function get_user_id(id){
		$("#user_id_mod").val(id);
	}

	function obtener_datos(id){
		var nombres = $("#nombres"+id).val();
		var apellidos = $("#apellidos"+id).val();
		var usuario = $("#usuario"+id).val();
		var email = $("#email"+id).val();
		
		$("#mod_id").val(id);
		$("#firstname2").val(nombres);
		$("#lastname2").val(apellidos);
		$("#user_name2").val(usuario);
		$("#user_email2").val(email);
		
	}
 function load(tipo, user_id){
   console.log("iduser", tipo)
   console.log("tipo", tipo)
    var q= $("#q").val(); 
   
    console.log("tipo user select", q)
    $("#loader").fadeIn('slow');
    $.ajax({
              url:'./ajax/buscar_usuarios_ventas.php?action=ajax&page=1&q='+q+'&tipo='+tipo+'&iduser='+user_id,
             beforeSend: function(objeto){
             $('#loader').html('<img src="./img/ajax-loader.gif"> Cargando...');
      },
            success:function(data){ 
                    $(".outer_div").html(data).fadeIn('slow');
                    $('#loader').html('');

            }
    });
}
 
</script>



