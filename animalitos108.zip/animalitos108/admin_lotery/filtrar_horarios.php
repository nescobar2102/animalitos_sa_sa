<?php
/* Connect To Database */
require_once ("config/db.php"); //Contiene las variables de configuracion para conectar a la base de datos
require_once ("config/conexion.php"); //Contiene funcion que conecta a la base de datos

$id_producto = isset($_POST['id_producto']) ? intval($_POST['id_producto']) : 0;

if ($id_producto > 0) {
    // Ajusta esta consulta según cómo se relacionan productos y horarios
    $sql = "SELECT id, descripcion FROM hora_jugadas WHERE  ids_loterias LIKE '%$id_producto%'";    
} else {
    // Si no hay selección válida, no muestra horarios
    $sql = "SELECT id, descripcion FROM hora_jugadas WHERE 1=0";
}
 
$query = mysqli_query($con, $sql);

echo '<div class="form-group">'; 
echo '<select class="form-control" id="horario" name="horario">'; 

while ($row = mysqli_fetch_array($query)) {
    $id = $row['id'];
    $desc = $row['descripcion'];
    echo '<option value="' . $id . '">' . $desc . '</option>';
}

echo '</select>';
echo '</div>';
?>