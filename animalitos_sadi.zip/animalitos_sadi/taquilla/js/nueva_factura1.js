let parameters = []
function removeElement(event, position) {
    event.target.parentElement.remove()
    delete parameters[position]
    recorrerTicket();    
}

const addJsonElement = json => {
    parameters.push(json)
    return parameters.length - 1
}

let monto_total = 0;
let $j=0;
let  myArray =[];
let  myArrayNombre =[];

let mySigno = [];
let mysignoNombre = [];
let myHorario = [] ;
let myHorarioNombre = []; 

function imprimirValor(id_sorteo,nombre ){ 
 var myIndex = myArray.indexOf(id_sorteo);
    if (myIndex !== -1) {
        myArray.splice(myIndex, 1);
    }else{
        console.log(myArray.push(id_sorteo))
    }

    var myIndexNombre = myArrayNombre.indexOf(nombre);
    if (myIndexNombre !== -1) {
        myArrayNombre.splice(myIndexNombre, 1);
    }else{
        console.log(myArrayNombre.push(nombre))
    } 
    console.log(myArrayNombre)
  }

  function imprimirValorSigno(id_signo,nombre ){
   /* console.log("imprimirValorSigno",id_signo),
    console.log("imprimirValorSigno",nombre)
    var myIndex = mySigno.indexOf(id_signo);
   if (myIndex !== -1) {
    mySigno.splice(myIndex, 1);
   }else{
       console.log(mySigno.push(id_signo))
   }

   var myIndexNombre = mysignoNombre.indexOf(nombre);
   if (myIndexNombre !== -1) {
    mysignoNombre.splice(myIndexNombre, 1);
   }else{
       console.log(mysignoNombre.push(nombre))
   }   */
 }

 function imprimirValorHorario(id_horario,nombre ){
    /*console.log("imprimirHorario",id_horario),
    console.log("imprimirHorario",nombre)
    var myIndex = myHorario.indexOf(id_horario);
   if (myIndex !== -1) {
    myHorario.splice(myIndex, 1);
   }else{
       console.log(myHorario.push(id_horario))
   }

   var myIndexNombre = myHorarioNombre.indexOf(nombre);
   if (myIndexNombre !== -1) {
    myHorarioNombre.splice(myIndexNombre, 1);
   }else{
       console.log(myHorarioNombre.push(nombre))
   }   */
 }

 function borrar_todo() {   
     parameters = [];
     myArray =[];
     myArrayNombre =[];    
     mySigno = [];
     mysignoNombre = [];
     myHorario = [] ;
     myHorarioNombre = [];

     monto_total=0.00;
     $j= 0; 
     $("#monto_total").html('Total monto: ' + monto_total + ' VES ' );

     $("#total_jugada").html('Total Jugadas: ' +$j);
     const $divElements = document.getElementById("divElements")
     $divElements.innerHTML = "";
     document.getElementById("frmUsers").reset();

     $('#signo').select2({
        placeholder: "",
        allowClear: true
    });
    $('#horario').select2({
        placeholder: "",
        allowClear: true
    });
  
 
}
  
function imprimir() {
    var id_cliente = $("#id_cliente").val(); 
    var myElement = document.getElementById('id_vendedor'),
    myElementValue = myElement.value; 
    var condiciones =  document.getElementById('condiciones').value; 
   
    if (id_cliente == "") {
        alert("Debes seleccionar un cliente");
        $("#nombre_cliente").focus();
        return false;
    } 

    $.ajax({
    url: './ajax/script.php',
    type: 'GET',
    data: {"variable":parameters},
    success: function(data, textStatus, xhr) {
        $("#resultados").html('');
        
        VentanaCentrada('./pdf/documentos/imp_factura.php?id_cliente=' + id_cliente + '&id_vendedor=' + myElementValue + '&condiciones=' + condiciones+'&data=' + parameters, 'Factura', '', '1024', '768', 'true');
       }
    }); 
  }
  
  function recorrerTicket(){ 
        monto_total=0.00;  
        $j= 0; 
        parameters.forEach(function(preventa) { 
            monto_total = monto_total+ parseFloat(preventa.precio_venta);
            $j++;
     });  

   $("#monto_total").html('');     
   $("#monto_total").html('Total monto: ' + monto_total + ' VES ' );

   $("#total_jugada").html('Total Jugadas: ' +$j);

  }
   var id_tipr;

  function buscar() {
    myArray =[];
    myArrayNombre =[]; 
      id_tipr = $("#id_tipr").val();
     $.ajax({
         url: './ajax/productos_factura_1.php?action=ajax&q=' + id_tipr,
         beforeSend: function (objeto) {
             $('#loader').html('<img src="./img/ajax-loader.gif"> Cargando...');
         },
         success: function (data) {
             $(".outer_div").html(data).fadeIn('slow');
             $('#loader').html('');
 
         }
     }); 
 }

(function load(){
    const $form = document.getElementById("frmUsers")
    const $divElements = document.getElementById("divElements")
    const $btnSave = document.getElementById("btnSave")
    const $btnAdd = document.getElementById("btnAdd")

    const templateElement = (data, position) => {       
        return (`       
         ${data}
        <img src="img/iconos/anular.png" width="20px" 
        title="Eliminar jugada" onclick="removeElement(event, ${position})">   
    `)
    }

    
 $btnAdd.addEventListener("click", (event) => {

     console.log("precio_venta",$("#precio_venta").val());  
     console.log("cantidad",$("#cantidad").val());  
     console.log("id_tipr",$("#id_tipr").val()); 
     console.log("horario",$("#horario").val());  

                // Reiniciar las variables
            myHorario = [];
            myHorarioNombre = [];

            // Recorre los checkboxes seleccionados en el contenedor de horarios
            $('#horario-checkboxes input[type="checkbox"]:checked').each(function () {
                const horarioId = $(this).val();
                const horarioNombre = $('label[for="' + $(this).attr('id') + '"]').text();

                myHorario.push(horarioId);
                myHorarioNombre.push(horarioNombre);
            });
 
    console.log("myHorario",myHorario)
      mySigno = ['1'];
      mysignoNombre='*****';   


     var jugada = $('input[name="jugada"]:checked').val();
        
  if($("#precio_venta").val()!= "" && $("#cantidad").val() != "" ){
 

            let partes = $("#id_tipr").find("option:selected").text().split('-');
 
          //  let abrev = partes[1]; // Esto será "ABC" 
        
            $i=0;
            $h=0; // Iterar sobre HORARIO
            myArray.forEach(function(loteria) { //loterias           
            numero = $("#cantidad").val() ; //$form.cantidad.value;
            $x=0;            
          //  if($form.jugada.value  == 2){ 
                if(jugada == 2){    //serie   

                    mySigno.forEach(function(word_signo) { 
                        var  $h=0; // Iterar sobre signos
                          myHorario.forEach(function(horario) { 
                          
                              for(var k=0; k < 10;k++) { 
                                serie=+k+""+numero;
                                monto_total = monto_total+ parseFloat($("#precio_venta").val());
                                
                                $j++;             
                                // Crear un nuevo elemento para la jugada
                                let index = addJsonElement({
                                    tipo_loteria: $("#id_tipr").val(),
                                    precio_venta: $("#precio_venta").val(),
                                    cantidad: serie,
                                    loteria: loteria,
                                    signo: word_signo,
                                    nombre: myArrayNombre[$i],
                                    nombre_signo: mysignoNombre[$x],
                                    horario: horario,
                                    nombre_horario: myHorarioNombre[$h]
                                });
                     
                                const $div = document.createElement("div");
                                $div.classList.add("notification", "is-link", "is-light", "py-2", "my-1")
                                $div.innerHTML = templateElement(`${myArrayNombre[$i]} ${myHorarioNombre[$h]} --- ${serie} --- ${$("#precio_venta").val()}`, index)
            
                                $divElements.insertBefore($div, $divElements.firstChild)                               
                            }
                            $h++;
                        });  
                                             
                          $x++; 
                        });
                        $i++;

             
            } else if(jugada == 3){ //permuta               
                var permutationString = str => {
                    if (str.length <= 2) return str.length === 2 ? [str[0] + str[1], str[1] + str[0]] : [str];
                    return str
                       .split('')
                       .reduce(
                          (accumulator, letter, i) =>
                           accumulator.concat(permutationString(str.slice(0, i) + str.slice(i+1)).map(val => letter + val)),[]);
                 };
         
                 var permuta = permutationString( $("#cantidad").val());  

                 mySigno.forEach(function(word_signo) {
                    
                    permuta.forEach(function(num) { //permuta 
                        var  $h=0; // Iterar sobre signos
                      myHorario.forEach(function(horario) { 
                          $j++;
                          
                            monto_total += parseFloat($("#precio_venta").val());
                
                            // Crear un nuevo elemento para la jugada
                            let index = addJsonElement({
                                tipo_loteria: $("#id_tipr").val(),
                                precio_venta: $("#precio_venta").val(),
                                cantidad: num,
                                loteria: loteria,
                                signo: word_signo,
                                nombre: myArrayNombre[$i],
                                nombre_signo: mysignoNombre[$x],
                                horario: horario,
                                nombre_horario: myHorarioNombre[$h]
                            }); 
                            console.log(index.tipo_loteria)
                            const $div = document.createElement("div");
                            $div.classList.add("notification", "is-link", "is-light", "py-2", "my-1")
                            $div.innerHTML = templateElement(` ${myArrayNombre[$i]} ${myHorarioNombre[$h]} --- ${mysignoNombre[$x]} --- ${num} --- ${$("#precio_venta").val()}`, index)
        
                            $divElements.insertBefore($div, $divElements.firstChild)
                            $h++;
                           });  
                      });                     
                      $x++;
                  });
                  $i++; 
               
                 
 
            } else { //jugada numero y terminakl (4) 
                var cantidad = $("#cantidad").val();
                if (jugada == 4) {  
                    cantidad = cantidad.substr(-2);
                } 
                
                // Verifica si hay signos disponibles
   
                  //  mySigno.forEach(function(word_signo) {
                  
                        myHorario.forEach(function(horario) { 
                            $j++;
                            // Iterar sobre horarios
                            // Sumar el precio de venta al monto total
                            monto_total += parseFloat($("#precio_venta").val());
                
                            // Crear un nuevo elemento para la jugada
                            let index = addJsonElement({
                                tipo_loteria: $("#id_tipr").val(),
                                precio_venta: $("#precio_venta").val(),
                                cantidad: cantidad,
                                loteria: loteria,
                                signo: 1,
                                nombre: myArrayNombre[$i],
                                nombre_signo: "****",
                                horario: horario,
                                nombre_horario: myHorarioNombre[$h]
                            });
                 
                            const $div = document.createElement("div");
                            $div.classList.add("notification", "is-link", "is-light", "py-2", "my-1")
                            $div.innerHTML = templateElement(`${myArrayNombre[$i]} ${myHorarioNombre[$h]} ---  *** --- ${cantidad} --- ${$("#precio_venta").val()}`, index)
        
                            $divElements.insertBefore($div, $divElements.firstChild)
                     
                         
                        });                     
                        $x++;
                   // });                    
                    $i++; 
               
                }
    })
    myHorario=[]
    $("#monto_total").html('Total monto: ' + monto_total + ' VES ' );

    $("#total_jugada").html('Total Jugadas: ' +$j);
}else{
    alert("Complete los campos")
}
})
    $btnSave.addEventListener("click", (event) =>{
 
        parameters = parameters.filter(el => el != null)
        const $jsonDiv = document.getElementById("jsonDiv")
        $jsonDiv.innerHTML = `JSON: ${JSON.stringify(parameters)}`
        $divElements.innerHTML = "";
        $.ajax({
            url: './ajax/script.php',
            type: 'GET',
            data: {"variable":parameters},
            success: function(data, textStatus, xhr) {  

                VentanaCentrada('./pdf/documentos/imp_factura.php?id_vendedor=' + $form.taquilla.value, 'Factura', '', '1024', '768', 'true');
                 borrar_todo();     
               }
            });
        parameters = [];
        monto_total=0.00;  
        $("#monto_total").html('Total monto: ' + monto_total + ' VES ' );
     
    })
})()