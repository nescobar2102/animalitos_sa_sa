function agregar() {

    var precio_venta = $('#precio_venta').val();
    var cantidad = $('#cantidad').val();

    // recoge los valores de las loterias seleccionadas.
    var loteria = '';
    $('#loteria input[type=checkbox]').each(function () {
        if (this.checked) {
            loteria += $(this).val() + ', ';
        }
    });


    // recoge los valores de los signos seleccionados
    var signo = '';
    $('#signo input[type=checkbox]').each(function () {
        if (this.checked) {
            signo += $(this).val() + ', ';
        }
    });


    // recoge los valores de las jugadas de las loterias
    var jugada = '';
    $('#jugada input[type=radio]').each(function () {
        if (this.checked) {
            jugada += $(this).val() + ' ';
        }
    });


    // Inicia validacion
    if (isNaN(cantidad)) {
        alert('Esto no es un numero');
        document.getElementById('cantidad').focus();
        return false;
    }
    if (isNaN(precio_venta) || (precio_venta < 0)) {
        alert('Esto no es un numero');
        document.getElementById('precio_venta').focus();
        return false;
    }

    // FIN VALIDACION

    $.ajax({
        type: "POST",
        url: "./ajax/agregar_facturacion.php",
        data: "id=" + loteria + "&precio_venta=" + precio_venta + "&cantidad=" + cantidad + "&signo=" + signo + "&jugada=" + jugada,
        beforeSend: function (objeto) {
            $("#resultados").html("Mensaje: Cargando...");
        },
        success: function (datos) {
            $("#resultados").html(datos);
        }
    });
    $("#cantidad").val("");
    $("#precio_venta").val("");
    document.getElementById('cantidad').focus();
}

function eliminar(id) {
    $.ajax({
        type: "GET",
        url: "./ajax/agregar_facturacion.php",
        data: "id=" + id,
        beforeSend: function (objeto) {
            $("#resultados").html("Mensaje: Cargando...");
        },
        success: function (datos) {
            $("#resultados").html(datos);
        }
    });

}  

function anular(id, s) {
    var q = $("#q").val();
    if (confirm("¿Desea anular este ticket?")) {
        $.ajax({
            type: "GET",
            url: "./ajax/buscar_facturas.php", 
            data: "id=" + id + "&s=" + s,
            "q": q,
            beforeSend: function (objeto) {
                $("#resultados").html("Mensaje: Cargando...");
            },
            success: function (datos) {
                $("#resultados").html(datos);
                load(1);
            }
        });
    }
}

  
$("#guardar_cliente").submit(function (event) {
    $('#guardar_datos').attr("disabled", true);

    var parametros = $(this).serialize();
    $.ajax({
        type: "POST",
        url: "ajax/nuevo_cliente.php",
        data: parametros,
        beforeSend: function (objeto) {
            $("#resultados_ajax").html("Mensaje: Cargando...");
        },
        success: function (datos) {
            $("#resultados_ajax").html(datos);
            $('#guardar_datos').attr("disabled", false);
            load(1);
        }
    });
    event.preventDefault();
});

$("#guardar_producto").submit(function (event) {
    $('#guardar_datos').attr("disabled", true);

    var parametros = $(this).serialize();
    $.ajax({
        type: "POST",
        url: "ajax/nuevo_producto.php",
        data: parametros,
        beforeSend: function (objeto) {
            $("#resultados_ajax_productos").html("Mensaje: Cargando...");
        },
        success: function (datos) {
            $("#resultados_ajax_productos").html(datos);
            $('#guardar_datos').attr("disabled", false);
            load(1);
        }
    });
    event.preventDefault();
});
 