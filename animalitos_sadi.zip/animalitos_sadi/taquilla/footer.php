<div class="navbar navbar-default navbar-fixed-bottom">
    <div class="container">     
      <p class="navbar-text pull-left">&copy <?php echo date('Y');?> - NANE CONSULTING
             Solutions
           <a href="" target="_blank" style="color: #ecf0f1">Contáctenos</a>
   </div>
</div>
 <!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
