	<?php
		if (isset($title))
		{
      $session_id=$_SESSION['user_id'];


        require_once ("config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
	require_once ("config/conexion.php");//Contiene funcion que conecta a la base de datos

       $query=mysqli_query($con,"select * from permisos where user_id='$session_id'");
	$rw=mysqli_fetch_array($query);
        $vender_r=$rw['vender_r'];
        $loteria=$rw['vender'];
        $pagar=$rw['pagar'];
        $anular=$rw['anular'];
        $crear_taq=$rw['crear_taquilla'];
        $reportes=$rw['reportes'];
        $crear_lot=$rw['crear_lot'];
        $crear_r=$rw['crear_r'];
        $permisos=$rw['permisos'];
	?>

<nav class="navbar navbar-expand-lg navbar-default">
 <img src="img/iconos/lotto.png" >
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
            Loteria 
        </a>
        <div class="dropdown-menu">
            <?php if ($loteria=='1'){ ?>
              <a class="dropdown-item"href="nueva_taquilla.php">Vender Loteria</a>
              <a class="dropdown-item"href="resultados.php">Resultados</a>
          <?php } ?>         
        </div>
      </li>
         <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
            Ruleta 
        </a>
        <div class="dropdown-menu">
            <?php if ($vender_r=='1'){ ?>
              <a class="dropdown-item" href="nueva_ruleta.php">Vender Animalitos</a>
              <a class="dropdown-item" href="nueva_ruleta_tripleta.php">Vender Tripleta</a>
            <?php } ?>                  
        </div>
      </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
              Reportes 
          </a>
        <div class="dropdown-menu">
            <a class="dropdown-item" href="facturas.php">Tickets Vendidos</a>
            <!--a class="dropdown-item" href="ventas.php">Ventas por Centro de Apuesta</a-->
            <a class="dropdown-item" href="ventas_1.php">Historico de Ventas</a>                     
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="usuarios.php">Usuario</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="login.php?logout">Salir</a>
      </li>
    </ul>    
  </div>
</nav>

<?php
 }
?>