	<?php
  
		if (isset($con))
		{
                     $id_vendedor=$_SESSION['user_id'];
	?>
	<!-- Modal -->
	<div class="modal fade" id="nuevoProducto" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel"><i class='glyphicon glyphicon-edit'></i> Bloquear Número</h4>
		  </div>
		  <div class="modal-body">
                <form class="form-horizontal" method="post" id="guardar_producto" name="guardar_producto">
                <div id="resultados_ajax_productos"></div>
                     <div class="form-group">
                        <label for="codigo" class="col-sm-3 control-label">Loteria</label>
                        <?php
                         $sqlj="select * from products where status_producto='1' and id_vendedor='$id_vendedor' and status_producto='1'";
                                         $queryj=mysqli_query($con, $sqlj);
                                         
                                         ?>
                        <div class="col-sm-8">
                            <select class="form-control" id="producto" name="producto" required>
                                <?php while ($rowj=mysqli_fetch_array($queryj)){
                                echo "<option  value='".$rowj["id_producto"]."'>".$rowj["nombre_producto"]."</option>"; }
                                ?>
                            </select>
                         </div>
                         </div>
			  <div class="form-group">
				<label for="codigo" class="col-sm-3 control-label">Número</label>
				<div class="col-sm-8">
				  <input type="text" class="form-control" id="numero" name="numero" placeholder="Número a bloquear" required>
				</div>
			  </div>
			  
			  <div class="form-group">
				<label for="precio" class="col-sm-3 control-label">Monto</label>
				<div class="col-sm-8">
                                    <input type="text" class="form-control" value="0.00" id="precio" name="precio" placeholder="Monto" required pattern="^[0-9]{1,5}(\.[0-9]{0,2})?$" title="Ingresa sólo números con 0 ó 2 decimales" maxlength="10">
				</div>
			  </div>
                          <div class="form-group">
				<label for="estado" class="col-sm-3 control-label">Estatus</label>
				<div class="col-sm-8">
				 <select class="form-control" id="estado" name="estado" required>
					<option value="">-- Selecciona estado --</option>
					<option value="1" selected>Activo</option>
					<option value="0">Inactivo</option>
				  </select>
				</div>
			  </div>
			 
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
			<button type="submit" class="btn btn-primary" id="guardar_datos">Guardar datos</button>
		  </div>
		  </form>
		</div>
	  </div>
	</div>
	<?php
		}
	?>