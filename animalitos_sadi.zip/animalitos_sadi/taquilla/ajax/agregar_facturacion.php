<?php
/* -------------------------
  Descripcion:Sistema de Venta y Control de juegos de azar
  Autor: Ing .Norbelys Naguanagua
  Mail: norbelysnaguanagua21@gmail.com
  Version: 1.0
  --------------------------- */
include('is_logged.php'); //Archivo verifica que el usario que intenta acceder a la URL esta logueado
$session_id = session_id();
$id_vendedor = $_SESSION['user_id'];
if (isset($_POST['id'])) {
    $id = $_POST['id'];
}
if (isset($_POST['cantidad'])) {
    $cantidad = $_POST['cantidad'];
}
if (isset($_POST['precio_venta'])) {
    $precio_venta = $_POST['precio_venta'];
}
if (isset($_POST['signo'])) {
    $signo = $_POST['signo'];
}
if (isset($_POST['jugada'])) {
    $jugada = $_POST['jugada'];
}

$date = date('Y-m-d');
/* Connect To Database */
require_once ("../config/db.php"); //Contiene las variables de configuracion para conectar a la base de datos
require_once ("../config/conexion.php"); //Contiene funcion que conecta a la base de datos
//Archivo de funciones PHP
include("../funciones.php");
if (!empty($id) && ! empty($cantidad) && ! empty($precio_venta)) {

    $separador = ",";
    $array = explode($separador, $id);
    $cant_elem = count($array); 
     
    for ($a = 0; $a < $cant_elem - 1; $a++) {
        $id_lo = $array [$a];
        if ($jugada == 2) {
            $montolim=0;
            $monto = 0;
              //limites de venta diarios por sorteos
                $fecha = date('Y-m-d');
                $venta = mysqli_query($con, "select * from facturas where id_vendedor='$id_vendedor' and fecha_factura='$fecha'"); 
                while ($bloqrow222 = mysqli_fetch_array($venta)) {
                    $factura = $bloqrow222["numero_factura"]; 
                    $venta111 = mysqli_query($con, "select sum(precio_venta) as venta from detalle_factura where numero_factura='$factura' and fecha='$fecha' and  id_producto='$id_lo'");

                    while ($bloqrow22233 = mysqli_fetch_array($venta111)) {
                        $factura2 = $bloqrow22233["venta"]; 
                        $monto=+ $factura2;
                    }
                }
            //serie de un número
            for ($i = 0; $i < 10; $i++) {
                $cantidadj = $i . "" . $cantidad;

                $sqlimit = mysqli_query($con, "select * from limites where id_loteria='$id_lo' and id_vendedor='$id_vendedor'");
                $rowlimi2 = mysqli_fetch_array($sqlimit);
                $montolim = $rowlimi2["monto"];  
           
                if($montolim > 0){
                    $restam = $montolim - $monto;
                   }
               
                     if ($monto < $montolim) {    
                        if ($restam < $precio_venta) {
                            $precio_venta = $restam; 
                        }
    
                    $bloq = mysqli_query($con, "select * from jug_bloqueo where id_producto='$id_lo' and numero_bloq='$cantidad' and id_vendedor='$id_vendedor' and date='$date'");
                    $count = mysqli_num_rows($bloq);
                    $bloqrow = mysqli_fetch_array($bloq);
                    $mont_max_jug = $bloqrow["monto"];
    
                    if ($count > 0) {    
                        if ($mont_max_jug > $precio_venta) {
                            $monto = $precio_venta;
                        } else {
                            $monto = $mont_max_jug;
                        }
                        $query_update = mysqli_query($con, $sqlupdmonto);
                    } else {
                        $monto = $precio_venta; 
                    }
                    $insert_tmp = mysqli_query($con, "INSERT INTO tmp (id_producto,cantidad_tmp,precio_tmp,signo,jugada,session_id) VALUES ('$id_lo','$cantidadj','$monto','$signo','$jugada','$session_id')");
                }else{
                    $insert_tmp = mysqli_query($con, "INSERT INTO tmp (id_producto,cantidad_tmp,precio_tmp,signo,jugada,session_id) VALUES ('$id_lo','$cantidadj','$precio_venta','$signo','$jugada','$session_id')");
                }
                
            }
        }//permuta de un número
        else if ($jugada == 3) { 
            $numero = $cantidad;
            $cant = strlen($numero);

            $pos = 0;
            $a = 0;
            $b = 1;
            $c = 2;
            $triple = Array();
            $trip = 0;

            for ($x = 0; $x < $numero; $x++) {
                $n[$x] = substr($numero, $x, 1);
            }

            for ($y = 0; $y <= $cant; $y++) {
                for ($z = 0; $z < $cant; $z++) {
                    if ($c < $cant) {
                        if ($n[$a] != $n[$b] && $n[$a] != $n[$c] && $n[$b] != $n[$c]) { 
                            $triple[$pos++] = $n[$a] . "" . $n[$b] . "" . $n[$c];
                            $triple[$pos++] = $n[$a] . "" . $n[$c] . "" . $n[$b];
                            $triple[$pos++] = $n[$b] . "" . $n[$a] . "" . $n[$c];
                            $triple[$pos++] = $n[$b] . "" . $n[$c] . "" . $n[$a];
                            $triple[$pos++] = $n[$c] . "" . $n[$a] . "" . $n[$b];
                            $triple[$pos++] = $n[$c] . "" . $n[$b] . "" . $n[$a];
                        }

                        if (($n[$a] == $n[$b] && $n[$a] != $n[$c]) ||
                                ($n[$a] == $n[$c] && $n[$a] != $n[$b]) ||
                                ($n[$b] == $n[$c] && $n[$a] != $n[$b])) { 
                            $triple[$pos++] = $n[$a] . "" . $n[$b] . "" . $n[$c];
                            $triple[$pos++] = $n[$c] . "" . $n[$a] . "" . $n[$b];
                            $triple[$pos++] = $n[$b] . "" . $n[$c] . "" . $n[$a];
                        }
                        if ($n[$a] == $n[$b] && $n[$a] == $n[$c] && $n[$b] == $n[$c]) { 
                            $triple[$pos++] = $n[$a] . "" . $n[$b] . "" . $n[$c];
                        }
                        $c++;
                    }
                }
                    if ($b != $cant - 2) {
                        $b++;
                        $c = $b + 1;
                    } else {
                        $a++;
                        $b = $a + 1;
                        $c = $b + 1;
                    }
            }
            for ($i = 0; $i < count($triple); $i++) {
                $cantidadj = $triple[$i];

                $bloq = mysqli_query($con, "select * from jug_bloqueo where id_producto='$id_lo' and numero_bloq='$cantidadj' and id_vendedor='$id_vendedor' and date='$date'");
                $count = mysqli_num_rows($bloq);
                $bloqrow = mysqli_fetch_array($bloq);
                $mont_max_jug = $bloqrow["monto"];

                if ($count > 0) {
                    if ($mont_max_jug > $precio_venta) {
                        $monto = $precio_venta;
                    } else {
                        $monto = $mont_max_jug;
                    }
                    $montoresta_ju = bcsub($mont_max_jug, $monto);
                } else {
                    $monto = $precio_venta;
                }

                $insert_tmp = mysqli_query($con, "INSERT INTO tmp (id_producto,cantidad_tmp,precio_tmp,signo,jugada,session_id) VALUES ('$id_lo','$cantidadj','$precio_venta','$signo','$jugada','$session_id')");
            }
        } else if ($jugada == 4) {
            $terminal = substr($cantidad, -2);
            $bloq = mysqli_query($con, "select * from jug_bloqueo where id_producto='$id_lo' and numero_bloq='$cantidad' and id_vendedor='$id_vendedor' and date='$date'");
            $count = mysqli_num_rows($bloq);
            $bloqrow = mysqli_fetch_array($bloq);
            $mont_max_jug = $bloqrow["monto"];

            if ($count > 0) {
                if ($mont_max_jug > $precio_venta) {
                    $monto = $precio_venta;
                } else {
                    $monto = $mont_max_jug;
                }
                $montoresta_ju = bcsub($mont_max_jug, $monto);
            } else {
                $monto = $precio_venta;
            }

            $insert_tmp = mysqli_query($con, "INSERT INTO tmp (id_producto,cantidad_tmp,precio_tmp,signo,jugada,session_id) VALUES ('$id_lo','$terminal','$monto','$signo','$jugada','$session_id')");
        } else { 

            //limites de venta diarios por sorteos
            $fecha = date('Y-m-d');
            $venta = mysqli_query($con, "select * from facturas where id_vendedor='$id_vendedor' and fecha_factura='$fecha'");

            $monto = 0;
            while ($bloqrow222 = mysqli_fetch_array($venta)) {
                $factura = $bloqrow222["numero_factura"];
                $venta111 = mysqli_query($con, "select sum(precio_venta) as venta from detalle_factura where numero_factura='$factura' and fecha='$fecha' and  id_producto='$id_lo'");

                while ($bloqrow22233 = mysqli_fetch_array($venta111)) {
                    $factura2 = $bloqrow22233["venta"];
                    $monto = $monto + $factura2;
                }
            }

            $sqlimit = mysqli_query($con, "select * from limites where id_loteria='$id_lo' and id_vendedor='$id_vendedor'");

            $rowlimi2 = mysqli_fetch_array($sqlimit);
            $montolim = $rowlimi2["monto"];

             if($montolim > 0){
                $restam = $montolim - $monto;
               }
             if ($monto < $montolim) {
                if ($restam < $precio_venta) {
                    $precio_venta = $restam;
                }

                $bloq = mysqli_query($con, "select * from jug_bloqueo where id_producto='$id_lo' and numero_bloq='$cantidad' and id_vendedor='$id_vendedor' and date='$date'");
                $count = mysqli_num_rows($bloq);
                $bloqrow = mysqli_fetch_array($bloq);
                $mont_max_jug = $bloqrow["monto"];

                if ($count > 0) {
                    if ($mont_max_jug > $precio_venta) {
                        $monto = $precio_venta;
                    } else {
                        $monto = $mont_max_jug;
                    }
                    $query_update = mysqli_query($con, $sqlupdmonto);
                } else {
                    $monto = $precio_venta;
                }

                $insert_tmp = mysqli_query($con, "INSERT INTO tmp (id_producto,cantidad_tmp,precio_tmp,signo,jugada,session_id) VALUES ('$id_lo','$cantidad','$monto','$signo','$jugada','$session_id')");
            } else {            
                $insert_tmp = mysqli_query($con, "INSERT INTO tmp (id_producto,cantidad_tmp,precio_tmp,signo,jugada,session_id) VALUES ('$id_lo','$cantidad','$precio_venta','$signo','$jugada','$session_id')");
            }
        }
    }
}
if (isset($_GET['id'])) {//codigo elimina un elemento del array
    $id_tmp = intval($_GET['id']);
    $delete = mysqli_query($con, "DELETE FROM tmp WHERE id_tmp='" . $id_tmp . "'");
}
$simbolo_moneda = get_row('perfil', 'moneda', 'id_perfil', 1);
?>
<div id="div4">
    <table class=" table table-striped">
        <tr>
        </tr>
        <?php
        $sumador_total = 0;
        $sql = mysqli_query($con, "select * from products, tmp,signo,jugada where products.id_producto=tmp.id_producto and signo.id=tmp.signo  and jugada.id=tmp.jugada  and tmp.session_id='" . $session_id . "' order by id_tmp asc");
        while ($row = mysqli_fetch_array($sql)) {
            $id_tmp = $row["id_tmp"];
            $codigo_producto = $row['codigo_producto'];
            $cantidad = $row['cantidad_tmp'];
            $nombre_producto = $row['nombre_producto'];
            $signo = $row['nombre'];

            $precio_venta = $row['precio_tmp'];
            $precio_venta_f = number_format($precio_venta, 2); //Formateo variables
            $precio_venta_r = str_replace(",", "", $precio_venta_f); //Reemplazo las comas
            $precio_total = $precio_venta_r * $cantidad;
            $precio_total_f = number_format($precio_total, 2); //Precio total formateado
            $precio_total_r = str_replace(",", "", $precio_total_f); //Reemplazo las comas
            $sumador_total+=$precio_venta_r; //Sumador
            ?>
            <tr> 
                <td><?php echo $nombre_producto; ?></td>
                <td class='text-center'><?php echo $signo; ?></td>
                <td class='text-center'><?php echo $cantidad; ?></td>			
                <td class='text-right'><?php echo $precio_venta_f; ?></td>
                <td class='text-center'><a title="Quitar Numero"  onclick="eliminar('<?php echo $id_tmp ?>')">  
                                <img src="img/iconos/anular.png" width="20px">
                            </a></td>
            </tr>		
            <?php
        }
        $impuesto = get_row('perfil', 'impuesto', 'id_perfil', 1);
        $subtotal = number_format($sumador_total, 2, '.', '');
        $total_iva = ($subtotal * $impuesto ) / 100;
        $total_iva = number_format($total_iva, 2, '.', '');
        $total_factura = $subtotal + $total_iva;
        ?>
    </table>
</div>
<table>
    <tr>
        <td class='text-center' colspan=3>TOTAL: </td>
        <td class='text-center'><?php echo number_format($subtotal, 2); ?></td>
        <td></td>
    </tr>
</table>
