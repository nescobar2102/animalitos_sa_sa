<?php
include('is_logged.php'); // Verifica que el usuario esté logueado
require_once("../config/db.php");
require_once("../config/conexion.php");

if (isset($_POST['serial']) && isset($_POST['ticket'])) {
    $status = intval($_POST['s']);
    $premio = intval($_POST['p']);
    $id_factura = intval($_POST['id']);
    $serial = intval($_POST['serial']);
    $ticket = intval($_POST['ticket']);
    
    $sql4 = mysqli_query($con, "SELECT * FROM facturas WHERE numero_factura='$ticket' AND serial='$serial'");
    $row4 = mysqli_fetch_array($sql4);
    
    if ($row4) {
        $fecha = $row4['fecha_factura'];
        $condiciones = $row4['condiciones'];
        $total_pag = 0; // Inicializa la variable total_pag
        $all_success = true; // Variable para verificar el éxito de todas las operaciones
        $mensajes = []; // Array para almacenar mensajes de éxito o error

        // Obtener todos los detalles de la factura
        $sql = mysqli_query($con, "SELECT * FROM detalle_factura WHERE numero_factura='$ticket'");
        while ($row = mysqli_fetch_array($sql)) {
            $signo = $row['id_signo'];
            $loteria = $row['id_producto'];
            $cantidad = $row['cantidad'];
            $precio = $row['precio_venta'];
            $id_horario  = $row['id_horario'];
            $id_vendedor = $_SESSION['user_id'];

            // Verificar si el detalle es ganador
            "SELECT * FROM resultados WHERE id_loteria='$loteria' AND numero='$cantidad' AND id_horario='$id_horario' AND id_signo=1 AND fecha_sorteo='$fecha'";
            $sql2 = mysqli_query($con, "SELECT * FROM resultados WHERE id_loteria='$loteria' AND numero='$cantidad' AND id_horario='$id_horario' AND id_signo=1 AND fecha_sorteo='$fecha'");
            $row2 = mysqli_fetch_array($sql2);

            if ($row2) {
                // Si es ganador, calculamos el premio
                if ($condiciones == 2) {
                    $bloq1 = mysqli_query($con, "SELECT * FROM products WHERE id_producto='$loteria'");
                    $bloqrow1 = mysqli_fetch_array($bloq1);
                    $tipo_ruleta = $bloqrow1["id_tipo"];

                    $pago_ruleta = mysqli_query($con, "SELECT paga FROM tipo_ruleta WHERE id='$tipo_ruleta'");
                    $pago_ruleta11 = mysqli_fetch_array($pago_ruleta);
                    $paga = $pago_ruleta11["paga"];

                    $monto_total = $precio * $paga;
                    $total_pag += $monto_total;

                    $update = mysqli_query($con, "UPDATE detalle_factura SET premio='$monto_total' WHERE numero_factura='$ticket' AND id_producto='$loteria'  AND cantidad='$cantidad'  AND id_horario='$id_horario' AND id_signo=1");
                  
                    if ($update) {
                        $mensajes[] = "Ticket pagado exitosamente para el número: $cantidad.";
                    } else {
                        $all_success = false;
                        $mensajes[] = "Error al pagar el ticket para el número: $cantidad.";
                    }
                } else {
                    $sqlpago = mysqli_query($con, "SELECT * FROM comisiones WHERE pago_id_vendedor=$id_vendedor");
                    $rowpago = mysqli_fetch_array($sqlpago);

                    if (strlen($cantidad) < 3) {
                        $monto_pag = $rowpago['pago_terminal'];
                    } else {
                        $monto_pag = $rowpago['pago_triple'];
                    }

                    $monto_pag1 = floatval($monto_pag);
                    $monto_total = $precio * $monto_pag1;
                    $total_pag += $monto_total;

                    $update = mysqli_query($con, "UPDATE detalle_factura SET premio='$monto_total' WHERE numero_factura='$ticket' AND id_producto='$loteria' AND cantidad='$cantidad'   AND id_horario='$id_horario'  AND id_signo=1");
              
                    if ($update) {
                        $mensajes[] = "Ticket pagado exitosamente para el numero: $cantidad.";
                    } else {
                        $all_success = false;
                        $mensajes[] = "Error al pagar el ticket para el numero: $cantidad.";
                    }
                }
            }
        }
         $update = mysqli_query($con, "UPDATE facturas SET estado_factura='$status', premio='$total_pag' WHERE numero_factura='$id_factura'");
        // Mensaje final basado en el resultado de todas las operaciones
        if ($all_success && $update) {
            
            echo json_encode(['success' => true, 'messages' => $mensajes]);
        } else {
            echo json_encode(['success' => false, 'messages' => $mensajes]);
        }
    } else {
        $mensajes[] = "Ticket no encontrado.";
        echo json_encode(['success' => false, 'messages' => $mensajes]);
    }
} else {
         $mensajes[] = "Datos incompletos.";
    echo json_encode(['success' => false, 'messages' => $mensajes]);
}
?>