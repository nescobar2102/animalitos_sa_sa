<?php
/*-------------------------
Descripcion:Sistema de Venta y Control de juegos de azar
Autor: Ing .Norbelys Naguanagua	 
Mail: norbelysnaguanagua21@gmail.com
Version: 1.1       
---------------------------*/
include('is_logged.php');//Archivo verifica que el usario que intenta acceder a la URL esta logueado
/* Connect To Database*/
require_once ("../config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
require_once ("../config/conexion.php");//Contiene funcion que conecta a la base de datos

$action = (isset($_REQUEST['action'])&& $_REQUEST['action'] !=NULL)?$_REQUEST['action']:'';
if (isset($_GET['id'])){
$id_vendedor=$_SESSION['user_id'];
   $status=intval($_GET['s']);
   $numero_factura=intval($_GET['id']);
 
   if ($update1=mysqli_query($con,$upd_anular) ){
           ?>
           <div class="alert alert-success alert-dismissible" role="alert">
             <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
             <strong>Aviso!</strong> Operacion exitosa
           </div>
           <?php 
   }else {
           ?>
           <div class="alert alert-danger alert-dismissible" role="alert">
             <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
             <strong>Error!</strong> No se puedo completar la operacion.
           </div>
           <?php

   }
}
if($action == 'ajax'){
$id_vendedor=$_SESSION['user_id'];
   // escaping, additionally removing everything that could be (html/javascript-) code
$q = mysqli_real_escape_string($con,(strip_tags($_REQUEST['q'], ENT_QUOTES)));
    $sTable = "facturas";
    $sWhere =" order by facturas.id_factura desc";
    include 'pagination.php'; //include pagination file
   //pagination variables
   $page = (isset($_REQUEST['page']) && !empty($_REQUEST['page']))?$_REQUEST['page']:1;
   $per_page = 10; //how much records you want to show
   $adjacents  = 4; //gap between pages after number of adjacents
   $offset = ($page - 1) * $per_page;
   //Count the total number of row in your table*/
   $count_query   = mysqli_query($con, "SELECT count(*) AS numrows FROM $sTable  $sWhere");
   $row= mysqli_fetch_array($count_query);
   $numrows = $row['numrows'];
   $total_pages = ceil($numrows/$per_page);
   $reload = './facturas.php';
   //main query to fetch the data
         $sql=" select sum(facturas.total_venta) as total,user_name,currencies.symbol from facturas,users,currencies
                                where   facturas.condiciones='1' 
                                and    estado_factura='1'
                                and facturas.id_vendedor=users.user_id 
                                and facturas.id_vendedor='$id_vendedor' and facturas.id_moneda=currencies.id GROUP BY id_moneda
                                 ";
            $query5 = mysqli_query($con, $sql);
                $sqlr1=" select sum(facturas.total_venta) as total,user_name,currencies.symbol from facturas,users,currencies
                where   facturas.condiciones='2' 
                and    estado_factura='1'
                and facturas.id_vendedor=users.user_id 
                and facturas.id_vendedor='$id_vendedor'  and facturas.id_moneda=currencies.id GROUP BY id_moneda
                ";

        $queryr1 = mysqli_query($con, $sqlr1); 
   //loop through fetched data
   if ($numrows>0){
           echo mysqli_error($con);
           ?>
                <div class="form-group row">
                    <label for="" class="col-md-2 control-label">Ventas en juego</label>
                </div>
           <div class="table-responsive">
             <table class="table">
                   <tr  class="info">
                           <th>Usuario</th>
                           <th>Apuesta</th>					
                           <th>Montos</th>
                   </tr>
                   <?php
                       while ($row=mysqli_fetch_array($query5)){
                                   $nombre=$row['user_name'];
                                   $total=$row['total'];  
                                   $symbol  =$row['symbol']; 
                                   ?>
                           <tr>
                                   <td><?php echo $nombre; ?></td>
                                   <td>Loteria</td>
                                   <td><?php echo number_format ($total,2);  echo  $symbol; ?></td>						
                           </tr>
                           <?php
                               }
                        while ($row=mysqli_fetch_array($queryr1)){
                                        $nombre=$row['user_name'];
                                        $total=$row['total'];  
                                        $symbol  =$row['symbol']; 
                                        ?>
                                <tr>
                                        <td><?php echo $nombre; ?></td>
                                        <td>Ruleta</td>
                                        <td><?php echo number_format ($total,2);  echo  $symbol; ?></td>						
                                </tr>
                                
                                <?php
                                }
                                ?>
                           <tr>
                                   <td colspan=7><span class="pull-right"></span></td>
                           </tr>
             </table>
           </div>
           <?php
                    }?>
    <div class="form-group row">
                    <label for="" class="col-md-2 control-label">Tickets Pagados</label>
                </div>
<?php 
$sql="select sum(facturas.premio) as total,user_name,currencies.symbol from facturas,users,currencies
                where   facturas.condiciones='1' 
                and    estado_factura='2'
                and facturas.id_vendedor=users.user_id 
                and facturas.id_vendedor='$id_vendedor' and facturas.id_moneda=currencies.id GROUP BY id_moneda
                ";
   $query6 = mysqli_query($con, $sql);

     $sqlr2="select sum(facturas.premio) as total,user_name,currencies.symbol from facturas,users,currencies
                where   facturas.condiciones='2' 
                and    estado_factura='2'
                and facturas.id_vendedor=users.user_id 
                and facturas.id_vendedor='$id_vendedor' and facturas.id_moneda=currencies.id GROUP BY id_moneda
                ";
   $queryr2 = mysqli_query($con, $sqlr2);
   //loop through fetched data
   if ($numrows>0){
           echo mysqli_error($con);
           ?>
           <div class="table-responsive">
           <table class="table">
                   <tr  class="info">
                           <th>Usuario</th>
                           <th>Apuesta</th>					
                           <th>Montos</th>
                   </tr>
                   <?php
                       while ($row=mysqli_fetch_array($query6)){
                                   $nombre=$row['user_name'];
                                   $total=$row['total'];  
                                   $symbol  =$row['symbol']; 
                                   ?>
                           <tr>
                                   <td><?php echo $nombre; ?></td>
                                   <td>Loteria</td>
                                   <td><?php echo number_format ($total,2);  echo  $symbol; ?></td>						
                           </tr>
                           <?php
                               }
                        while ($row=mysqli_fetch_array($queryr2)){
                                        $nombre=$row['user_name'];
                                        $total=$row['total'];  
                                        $symbol  =$row['symbol']; 
                                        ?>
                                <tr>
                                        <td><?php echo $nombre; ?></td>
                                        <td>Ruleta</td>
                                        <td><?php echo number_format ($total,2);  echo  $symbol; ?></td>						
                                </tr>
                                
                                <?php
                                }
                                ?>
                           <tr>
                                   <td colspan=7><span class="pull-right"></span></td>
                           </tr>
             </table>
           </div>
   <?php }?>
  <div class="form-group row">
      <label for="" class="col-md-2 control-label">Tickets Anulados</label>
  </div>
<?php 
   $sql="select sum(facturas.total_venta) as total,user_name,currencies.symbol from facturas,users,currencies
                where   facturas.condiciones='1' 
                and    estado_factura='0'
                and facturas.id_vendedor=users.user_id 
                and facturas.id_vendedor='$id_vendedor' and facturas.id_moneda=currencies.id GROUP BY id_moneda
                ";
   $query = mysqli_query($con, $sql);


$sqlr3="select sum(facturas.total_venta) as total,user_name,currencies.symbol from facturas,users,currencies
                where   facturas.condiciones='2' 
                and    estado_factura='0'
                and facturas.id_vendedor=users.user_id 
                and facturas.id_vendedor='$id_vendedor' and facturas.id_moneda=currencies.id GROUP BY id_moneda
";
$queryr3 = mysqli_query($con, $sqlr3);
   //loop through fetched data
   if ($numrows>0){
           echo mysqli_error($con);
           ?>
           <div class="table-responsive">
           <table class="table">
                   <tr  class="info">
                           <th>Usuario</th>
                           <th>Apuesta</th>					
                           <th>Montos</th>
                   </tr>
                   <?php
                       while ($row=mysqli_fetch_array($query)){
                                   $nombre=$row['user_name'];
                                   $total=$row['total'];  
                                   $symbol  =$row['symbol']; 
                                   ?>
                           <tr>
                                   <td><?php echo $nombre; ?></td>
                                   <td>Loteria</td>
                                   <td><?php echo number_format ($total,2);  echo  $symbol; ?></td>						
                           </tr>
                           <?php
                               }
                        while ($row=mysqli_fetch_array($queryr3)){
                                        $nombre=$row['user_name'];
                                        $total=$row['total'];  
                                        $symbol  =$row['symbol']; 
                                        ?>
                                <tr>
                                        <td><?php echo $nombre; ?></td>
                                        <td>Ruleta</td>
                                        <td><?php echo number_format ($total,2);  echo  $symbol; ?></td>						
                                </tr>
                                
                                <?php
                                }
                                ?>
                           <tr>
                                   <td colspan=7><span class="pull-right"></span></td>
                           </tr>
             </table>
           </div>
                           <?php 
                           }
                           }

