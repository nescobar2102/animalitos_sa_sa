<?php
session_start();
$_SESSION['variable']=$_GET['variable']; 
?>
 