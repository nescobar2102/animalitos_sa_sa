<?php
	/*-------------------------
  Descripcion:Sistema de Venta y Control de juegos de azar
  Autor: Ing .Norbelys Naguanagua	 
  Mail: norbelysnaguanagua21@gmail.com
  Version: 1.1       
	---------------------------*/
	include('is_logged.php');//Archivo verifica que el usario que intenta acceder a la URL esta logueado
	/* Connect To Database*/
	require_once ("../config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
	require_once ("../config/conexion.php");//Contiene funcion que conecta a la base de datos
	 ini_set('date.timezone','America/Caracas'); 
   $hora= date('H:i:s'); 
   $fecha = date('Y-m-d');
   $id_vendedor=$_SESSION['user_id']; 
	if (isset($_POST['serial']) && isset($_POST['ticket']) ){ 
            $update=false;
            $serial=intval($_POST['serial']);
            $ticket=intval($_POST['ticket']);   
            $sql4=mysqli_query($con, "select * from facturas where  numero_factura='$ticket' and serial ='$serial' and fecha_factura='$fecha' ");                                       
            $row4=mysqli_fetch_array($sql4);
            $id_factura=$row4['id_factura']; 
            $estad=$row4['estado_factura'];
            $numero_factura=$row4['numero_factura']; 
          //  $hora_ticket=$row4['hora']; 
 
     if($numero_factura && $estad==1){
                      $sql=mysqli_query($con, "select * from detalle_factura where numero_factura='$numero_factura'");
                  
                      $i= 0;
                      while ($row=mysqli_fetch_array($sql)){  
                           $loteria=$row['id_producto'];  

                            $sql2=mysqli_query($con, "select * from products where status_producto='1' and  id_producto='$loteria' and hora_cierre<='$hora'");   
                            $count=mysqli_num_rows($sql2);
                            if ($count>0)  { 
                              $i++;
                              $msg= "El Ticket tiene sorteos cerrados, no se puede anular!.";
                          }  
                    } 
              
                  if($i==0){
                  $update=mysqli_query($con, "update facturas set estado_factura='0'  where id_factura='$id_factura' and id_vendedor='$id_vendedor' ");
                  }
      }else{
        $msg= "Ticket no encontrado!.";
      }
      if($estad=='2'){  
        $msg = "Ticket Pagado";
      }  
      if($estad=='3'){  
        $msg = "Ticket Premiado";
      }  
      if($estad=='0'){  
        $msg = "Ticket Anulado"; 
     } 
      if($update){ ?>
            <div class="alert alert-success" role="alert">
              <button type="button" class="close" data-dismiss="alert">&times;</button>
              <strong>¡Bien hecho, Ticket Anulado! </strong> 
          </div> 
        <?php  }else{ ?>
          <div class="alert alert-danger" role="alert">
              <button type="button" class="close" data-dismiss="alert">&times;</button>
              <strong> <?= $msg; ?>  </strong> 
          </div>
      <?php  }
    }
 
 
 ?>  
     
  
         
 