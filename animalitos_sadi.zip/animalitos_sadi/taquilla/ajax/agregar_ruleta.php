<?php
/* -------------------------
  Descripcion:Sistema de Venta y Control de juegos de azar
  Autor: Ing .Norbelys Naguanagua
  Mail: norbelysnaguanagua21@gmail.com
  Version: 1.1
  --------------------------- */
include('is_logged.php'); //Archivo verifica que el usario que intenta acceder a la URL esta logueado
$session_id = session_id();
$id_vendedor = $_SESSION['user_id'];
if (isset($_POST['id_ruleta'])) {
    $id_ruleta = $_POST['id_ruleta'];
}
if (isset($_POST['cantidad'])) {
    $cantidad = $_POST['cantidad'];
}
if (isset($_POST['precio_venta'])) {
    $precio_venta = $_POST['precio_venta'];
}

/* Connect To Database */
require_once ("../config/db.php"); //Contiene las variables de configuracion para conectar a la base de datos
require_once ("../config/conexion.php"); //Contiene funcion que conecta a la base de datos
//Archivo de funciones PHP
include("../funciones.php");
if (!empty($id_ruleta) && !empty($precio_venta)) {  

    $separador = ",";
    $array1 =  explode($separador, $id_ruleta);
    $cant_elem1 = count($array1);
   
    for ($a = 0; $a < $cant_elem1 - 1; $a++) {
        $id_lo = $array1 [$a];

        //numero de loteria a jugar
        $separador = "-";
        $array = explode($separador, $cantidad);
        $cant_elem = count($array); 
        for ($i = 0; $i < $cant_elem; $i++) {
            $numero = $array [$i]; 
            $bloq1 = mysqli_query($con, "select * from ruleta where id='$numero'");

            $bloqrow1 = mysqli_fetch_array($bloq1);
            $mont_max_jug1 = $bloqrow1["nombre"];

            $num = explode("-", $mont_max_jug1); 
            $monto = 0;
            //limites de venta diarios por sorteos
              ini_set('date.timezone','America/Caracas');
              $fecha = date('Y-m-d');
              $venta = mysqli_query($con, "select * from facturas where id_vendedor='$id_vendedor' and fecha_factura='$fecha'"); 
              while ($bloqrow222 = mysqli_fetch_array($venta)) {
                  $factura = $bloqrow222["numero_factura"]; 
                  $venta111 = mysqli_query($con, "select sum(precio_venta) as venta from detalle_factura where numero_factura='$factura' and fecha='$fecha' and  id_producto='$id_lo'");

                  while ($bloqrow22233 = mysqli_fetch_array($venta111)) {
                      $factura2 = $bloqrow22233["venta"]; 
                      $monto=+ $factura2;
                  }
              } 
            $sqlimit = mysqli_query($con, "select * from limites where id_loteria='$id_lo' and id_vendedor='$id_vendedor'");

            $rowlimi2 = mysqli_fetch_array($sqlimit);
            $montolim = $rowlimi2["monto"]; 

            $restam = $montolim - $monto;
 
            if ($monto < $montolim) {
                if ($restam < $precio_venta) {
                    $precio_venta = $restam;
                } 

                $bloq = mysqli_query($con, "select * from jug_bloqueo where id_producto='$id_lo' and numero_bloq='$num[0]' and id_vendedor='$id_vendedor'");
                $count = mysqli_num_rows($bloq);
                $bloqrow = mysqli_fetch_array($bloq);
                $mont_max_jug = $bloqrow["monto"];

                if ($count > 0) {
                    if ($mont_max_jug > $precio_venta) {
                        $monto = $precio_venta;
                    } else {
                        $monto = $mont_max_jug;
                    }
                    $montoresta_ju = bcsub($mont_max_jug, $monto);
                } else {
                    $monto = $precio_venta;
                }
                
                $insert_tmp = mysqli_query($con, "INSERT INTO tmp (id_producto,cantidad_tmp,precio_tmp,signo,jugada,session_id) VALUES ('$id_lo','$numero','$monto','0','0','$session_id')");
            }else{               
                $insert_tmp = mysqli_query($con, "INSERT INTO tmp (id_producto,cantidad_tmp,precio_tmp,signo,jugada,session_id) VALUES ('$id_lo','$numero','$precio_venta','0','0','$session_id')");
            }
        }
    }
}

if (isset($_GET['id'])) {//codigo elimina un elemento del array
    $id_tmp = intval($_GET['id']);
    $delete = mysqli_query($con, "DELETE FROM tmp WHERE id_tmp='" . $id_tmp . "'");
}
$simbolo_moneda = get_row('perfil', 'moneda', 'id_perfil', 1);
?>

<div id="div3">
    <table class="table">

    <?php
    $sql = mysqli_query($con, "select LAST_INSERT_ID(numero_factura) as last from facturas order by id_factura desc limit 0,1 ");
    $rw = mysqli_fetch_array($sql);
    $numero_factura = $rw['last'] + 1;
    $simbolo_moneda = get_row('perfil', 'moneda', 'id_perfil', 1);
    $sql_user = mysqli_query($con, "select * from users where user_id='$id_vendedor'");
    $rw_user = mysqli_fetch_array($sql_user);
 
        $sumador_total = 0;
        $sql = mysqli_query($con, "select * from products, tmp where products.id_producto=tmp.id_producto  and tipo = 2  and tmp.session_id='" . $session_id . "' order by id_tmp asc");
        while ($row = mysqli_fetch_array($sql)) {
            $id_tmp = $row["id_tmp"];
            $codigo_producto = $row['codigo_producto'];
            $cantidad = $row['cantidad_tmp'];
            $nombre_producto = $row['nombre_producto'];
            $id_tipo = $row['id_tipo'];

            $precio_venta = $row['precio_tmp'];
            $precio_venta_f = number_format($precio_venta, 2); //Formateo variables
            $precio_venta_r = str_replace(",", "", $precio_venta_f); //Reemplazo las comas
            $precio_total = $precio_venta_r * $cantidad;
            $precio_total_f = number_format($precio_total, 2); //Precio total formateado
            $precio_total_r = str_replace(",", "", $precio_total_f); //Reemplazo las comas
            $sumador_total+=$precio_venta_r; //Sumador
            ?>
            <tr>
            <td><?php ?></td>
            <td><?php echo $nombre_producto; ?></td>                       
            <td><?php echo $cantidad; ?></td>			
            <td><?php echo $precio_venta_f; ?></td>
            <td><a  title="Quitar Numero" onclick="eliminar('<?php echo $id_tmp ?>')">  <img src="img/iconos/anular.png" width="20px"></a></td>
        </tr>	
        <?php
            
            }
            $impuesto = get_row('perfil', 'impuesto', 'id_perfil', 1);
            $subtotal = number_format($sumador_total, 2, '.', '');
            $total_iva = ($subtotal * $impuesto ) / 100;
            $total_iva = number_format($total_iva, 2, '.', '');
            $total_factura = $subtotal + $total_iva;
            ?>
    </table>
</div>

<table>
    <td>
        <button class="btn btn-default"  style="background-color: fuchsia; color: white;" onclick="imprimir()">Vender - Imprimir </button></td>
    <td colspan=3> TOTAL: </td>
    <td> <?php echo number_format($subtotal, 2); ?></td>
</table>
<?php 


