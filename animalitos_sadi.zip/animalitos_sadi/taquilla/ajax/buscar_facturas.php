<?php
/*-------------------------
Descripcion: Sistema de Venta y Control de juegos de azar
Autor: Ing. Norbelys Naguanagua	 
Mail: norbelysnaguanagua21@gmail.com
Version: 1.0       
---------------------------*/

include('is_logged.php'); // Verifica que el usuario está logueado
require_once("../config/db.php"); // Configuración BD
require_once("../config/conexion.php"); // Conexión BD

$action = (isset($_REQUEST['action']) && $_REQUEST['action'] != NULL) ? $_REQUEST['action'] : '';

if (isset($_GET['id'])) {
    $id_vendedor = $_SESSION['user_id'];
    $status = intval($_GET['s']);
    $numero_factura = intval($_GET['id']);

    $upd_anular = "UPDATE facturas 
                   SET estado_factura = '$status' 
                   WHERE numero_factura = '$numero_factura' AND id_vendedor = '$id_vendedor'";

    if (mysqli_query($con, $upd_anular)) {
        echo '<div class="alert alert-success alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong>Aviso!</strong> Ticket anulado exitosamente.
              </div>';
    } else {
        echo '<div class="alert alert-danger alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong>Error!</strong> No se pudo anular el ticket.
              </div>';
    }
}

if ($action == 'ajax') {
    $id_vendedor = $_SESSION['user_id'];
    $q = mysqli_real_escape_string($con, strip_tags($_REQUEST['q'], ENT_QUOTES));

    $sTable = "
        facturas 
        INNER JOIN users ON facturas.id_vendedor = users.user_id
        LEFT JOIN currencies ON facturas.id_moneda = currencies.id
    ";

    $sWhere = "WHERE estado_factura IN (0, 1, 2, 3)";
    if (!empty($q)) {
        $sWhere .= " AND facturas.serial LIKE '%$q%'";
    }

    $sWhere .= " ORDER BY facturas.id_factura DESC";

    include 'pagination.php'; // paginación

    $page = (isset($_REQUEST['page']) && !empty($_REQUEST['page'])) ? $_REQUEST['page'] : 1;
    $per_page = 10;
    $adjacents  = 4;
    $offset = ($page - 1) * $per_page;

    // Total de filas
    $count_query = mysqli_query($con, "SELECT COUNT(*) AS numrows FROM $sTable $sWhere");
    $row = mysqli_fetch_array($count_query);
    $numrows = $row['numrows'];
    $total_pages = ceil($numrows / $per_page);
    $reload = './facturas.php';

    // Consulta principal
      $sql = "SELECT facturas.*, users.firstname, users.lastname, currencies.symbol 
            FROM $sTable 
            $sWhere 
            LIMIT $offset, $per_page";

    $query = mysqli_query($con, $sql);

    if ($numrows > 0) {
?>
<div class="table-responsive">
    <table class="table">
        <tr class="info">
            <th>Nro Ticket</th>
            <th>Serial</th>
            <th>Fecha Jugada</th>					
            <th>Agencia</th>
            <th>Estatus Ticket</th>
            <th class='text-right'>Total</th>
            <th class='text-right'>Acciones</th>
        </tr>
<?php
        while ($row = mysqli_fetch_array($query)) {         
            $serial = $row['serial'];
            $numero_factura = $row['numero_factura'];
            $fecha = date("d/m/Y", strtotime($row['fecha_factura']));
            $nombre_vendedor = $row['firstname'] . " " . $row['lastname'];
            $simbolo_moneda = $row['symbol'];
            $total_venta = $row['total_venta'];
            $estado_factura = $row['estado_factura'];

            // Estado factura
            if ($estado_factura == 1) {
                $text_estado = "Jugando";
                $label_class = 'label-warning';
            } elseif ($estado_factura == 0) {
                $text_estado = "Anulado";
                $label_class = 'label-danger';
            } elseif ($estado_factura == 2) {
                $text_estado = "Pagado";
                $label_class = 'label-success';
            } elseif ($estado_factura == 3) {
                $text_estado = "Premiado";
                $label_class = 'label-info';
            }

            // Permisos
            $perm_query = mysqli_query($con, "SELECT pagar, anular FROM permisos WHERE user_id = {$_SESSION['user_id']}");
            $perm = mysqli_fetch_array($perm_query);
            $pagar = $perm['pagar'];
            $anular = $perm['anular'];
?>
        <tr>
            <td><?= $numero_factura; ?></td>
            <td><?= $serial; ?></td>
            <td><?= $fecha; ?></td>						
            <td><?= $nombre_vendedor; ?></td>
            <td><span class="label <?= $label_class; ?>"><?= $text_estado; ?></span></td>
            <td class='text-right'><?= $simbolo_moneda . " " . number_format($total_venta, 2); ?></td>					
            <td class="text-right">
                <a title="Ver Ticket" data-toggle="modal" data-target="#myModalVer3" onclick="ver_ticket('<?= $numero_factura; ?>','2')">
                    <img src="img/iconos/ver.png" width="30px">
                </a>
<?php if (($estado_factura == 1 || $estado_factura == 3) && $pagar == '1') { ?> 
                <a title="Pagar Ticket" onclick="pagarticket('<?= $numero_factura; ?>','2')">
                    <img src="img/iconos/pagar.png" width="30px">
                </a> 
<?php }  
      if ($estado_factura == 1 && $anular == '1') { ?>
                <a title="Anular Ticket" onclick="eliminar('<?= $numero_factura; ?>','0')">
                    <img src="img/iconos/anular.png" width="30px">
                </a>
<?php } ?>
            </td>
        </tr>
<?php
        } // fin while
?>
        <tr>
            <td colspan="7">
                <span class="pull-right"><?= paginate($reload, $page, $total_pages, $adjacents); ?></span>
            </td>
        </tr>
    </table>
</div>
<?php
    } else {
?>
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong>Aviso!</strong> No existen tickets para la fecha seleccionada.
</div>
<?php
    } // end if numrows
} // end if ajax
?>
