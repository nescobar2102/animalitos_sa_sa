<?php
	
	/*-------------------------
    Descripcion:Sistema de Venta y Control de juegos de azar
    Autor: Ing .Norbelys Naguanagua	 
    Mail: norbelysnaguanagua21@gmail.com
    Version: 1.1       
	---------------------------*/
	include('is_logged.php');//Archivo verifica que el usario que intenta acceder a la URL esta logueado
	require_once ("../config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
	require_once ("../config/conexion.php");//Contiene funcion que conecta a la base de datos
	if (empty($_POST['serial'])){
        $errors[] = "serial vacío";
    } elseif  (empty($_POST['ticket'])){
        $errors[] = "ticket vacío";
    } 

	if ( isset($_POST['serial']) && isset($_POST['ticket']) ){
?>
  
<?php 
 
 $numero_factura=$_POST['ticket'];
 $serial=$_POST['serial'];
 $total_pag=0;
            
 $sql4=mysqli_query($con, "select * from facturas where numero_factura='$numero_factura' and serial ='$serial'  ");                                       
 $row4=mysqli_fetch_array($sql4);
 $fecha=$row4['fecha_factura'];
 $numero_factura=$row4['numero_factura'];
 $condiciones=$row4['condiciones'];
 $estad=$row4['estado_factura'];
 $id_fact= $row4['id_factura'];
 $id_moneda =$row4['id_moneda'];  
  
 $sql_moneda=mysqli_query($con,"select * from currencies where id='$id_moneda'"); //simbolo moneda
 $rw_moneda=mysqli_fetch_array($sql_moneda);
 $simbolo_moneda = $rw_moneda["symbol"];

 $msg='';
 if($numero_factura && ($estad==1 || $estad==3)){  ?>
  <div class="container-fluid">  
    <table class="table table-striped">
        <tr  class="info">
               
                <th>Fecha</th>					
                <th>Loteria</th>
                <th>Número Premiado</th>
                <th>Monto de Apuesta</th>
                <th>Monto Ganado</th>
                    <th></th> 
        </tr>
  <?php 
  $sql=mysqli_query($con, "select * from detalle_factura where numero_factura='$numero_factura'");
             while ($row=mysqli_fetch_array($sql)){ 
         
            $signo=$row['id_signo'];
            $loteria=$row['id_producto'];
            $cantidad=$row['cantidad'];
            $precio=$row['precio_venta']; 
            $fecha_ju=date("Y-m-d",strtotime($fecha));
            $date=  date('Y-m-d');

 
    $dias = (strtotime($date)- strtotime($fecha_ju))/24/3600; 
 
    if ($dias>3){
        $msg = "Ticket Vencido";  
  }

$sql2=mysqli_query($con, "select * from resultados where id_loteria='$loteria' and numero='$cantidad' and id_signo='$signo' and fecha_sorteo='$fecha'");                   

 
 $row2=mysqli_fetch_array($sql2);
  
   $id_loteria=$row2['id_loteria'];
 
 if($id_loteria){
      $id_vendedor=$_SESSION['user_id'];
      if($condiciones==2){
        $bloq1=mysqli_query($con, "select * from products where id_producto='$loteria'");
      
       $bloqrow1=mysqli_fetch_array($bloq1);	 
        $tipo_ruleta=$bloqrow1["id_tipo"]; 
        $nom_loteria=$bloqrow1['nombre_producto'];					 
       //monto a pagar por el tipo de ruleta 
         $pago_ruleta=mysqli_query($con, "select paga from tipo_ruleta where id='$tipo_ruleta'");
            $pago_ruleta11=mysqli_fetch_array($pago_ruleta);	 
            $paga=$pago_ruleta11["paga"];  //monto a pagar por ruleta
                
      		 					 
        $monto_total=$precio*$paga;    
        $total_pag=$total_pag+$monto_total;   
            
  } 
 if($condiciones==1){ 
                
$sql3=mysqli_query($con, "select * from products where id_producto='$id_loteria'");
$row1=mysqli_fetch_array($sql3);

     
  $sqlpago=mysqli_query($con,"select * from comisiones where pago_id_vendedor=$id_vendedor");
             $rowpago=mysqli_fetch_array($sqlpago);
          if (strlen($cantidad)<3){
            $monto_pag=$rowpago['pago_terminal'];	 
          }
          if (strlen($cantidad)==3){
            $monto_pag=$rowpago['pago_triple'];	             
          }
         
            $monto_pag1= floatval($monto_pag);  
            $nom_loteria=$row1['nombre_producto'];					 
            $monto_total=$precio*$monto_pag1;    
            $total_pag=$total_pag+$monto_total;

}

					?>  

				 
        <tr> 
                  <td><?php echo $fecha; ?></td>
                  <td><?php echo $nom_loteria; ?></td>

                  <td><?php echo $cantidad; ?></td>
              <td><?php echo number_format ( $precio,2);  echo " "; echo $simbolo_moneda; ?> </td>
              <td><?php echo number_format($monto_total,2);  echo " "; echo $simbolo_moneda; ?></td>
              </tr>
              <?php
             }
             }
                               
 ?> 
       </table>
         
            <table class="table table-striped">
                <tr  class="info"> 
                <th>Monto total a Pagar</th>	
                <th>Nro Ticket</th>	
                <th>Serial</th>	
                  <th>Acciones</th>	
                 
                </tr>     
                <tr> 
               <td><?php echo number_format ( $total_pag,2);  echo " "; echo $simbolo_moneda; ?></td>
               <td><?php echo $numero_factura;?></td>
               <td><?php echo $serial;?></td>
               
               <td>
                   <?php if($total_pag>0){ ?>
                <span class="">Ticket Premiado</span> 
                   <a href="" class='btn btn-default' title='Pagar Ticket ' onclick="premiar_t('<?php echo $id_fact; ?>','2','<?php echo $total_pag; ?>')"><img src="img/iconos/pagar.png" width="30px"></a>
   
                <?php   }  else { ?>
                     <span class="">Ticket No premiado</span>
                     <?php        
                
            }?> 
                   
               </td> 
                </tr>
            </table> 
            
        </div>
      <?php
 } else {
  $msg= "Ticket no encontrado!.";
 } 
 
 if($estad=='2'){  
    $msg = "Ticket Pagado";
  }  
  if($estad=='0'){  
    $msg = "Ticket Anulado"; 
}  
     if($msg!=''){ ?>
      <div class="alert alert-danger" role="alert">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong><?= $msg ?></strong> 
    </div> 
   <?php  } 
    } 
	?>   
      <script type="text/javascript" src="js/pagar.js"></script>
 
