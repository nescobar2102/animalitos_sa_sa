<?php
/*-------------------------
    Descripcion:Sistema de Venta y Control de juegos de azar
    Autor: Ing .Norbelys Naguanagua	 
    Mail: norbelysnaguanagua21@gmail.com
    Version: 1.1       
	---------------------------*/

	include('is_logged.php');//Archivo verifica que el usario que intenta acceder a la URL esta logueado
	/* Connect To Database*/
	require_once ("../config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
	require_once ("../config/conexion.php");//Contiene funcion que conecta a la base de datos
	
	$action = (isset($_REQUEST['action'])&& $_REQUEST['action'] !=NULL)?$_REQUEST['action']:'';
 
 
if($action == 'ajax'){ 
    $id_tipo=intval($_GET['q']);
    $id_vendedor=$_SESSION['user_id'];
    ini_set('date.timezone','America/Caracas'); 
    $hora= date('H:i:s');
     
 
    $sql_producto=mysqli_query($con,"select id_producto,codigo_producto, nombre_producto,img 
    from products where status_producto='1' and tipo='1' and id_tipo='$id_tipo' ");
  
    ?> 
   <div class="col-lg-3">
    <div id="div1">
        <form id="loteria" >
        <table  class="table table-striped" width="25%" cellspacing="5">
        <thead>
            <tr>     <?php echo $hora;?>
                  <p class="bg-primary">SORTEOS</p>
            </tr>
        </thead>
        <tbody>
               <?php while ($row=mysqli_fetch_array($sql_producto)){
                   $id_producto=$row['id_producto'];
                   $codigo_producto=$row['codigo_producto'];
                   $nombre_producto=$row['nombre_producto'];
                   $img=$row['img'];
                ?>                 
            <tr>
               <tr>
                   <td><img src="img/loteria/<?php echo $img; ?>" alt="..." width="40px"><input type="checkbox" id="loteria[]" name="loteria[]"  value="<?= $id_producto;?>"   onClick="imprimirValor(<?= $id_producto;?>,'<?= $nombre_producto;?>')"><?= $nombre_producto;?></td>
              </tr>              
               <?php }
               ?>
        </tbody>
    </table>
        </form>
  </div>
        </div>
 
 <?php }?>
 
 