<?php
/*-------------------------
    Descripcion:Sistema de Venta y Control de juegos de azar
	Autor: Ing .Norbelys Naguanagua	 
	Mail: norbelysnaguanagua21@gmail.com
    Version: 1.1       
---------------------------*/
	session_start();
	if (!isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] != 1) {
		header("location: login.php");
		exit;
	}

	$active_facturas="active";
	$active_productos="";
	$active_clientes="";
	$active_usuarios="";	
	$title="Tickets | Ventas";
?>
<!DOCTYPE html>
<html lang="en">
  <head>
	<?php include("head.php");?>
  </head>
  <body>
	<?php
	include("navbar.php");
	include("modal/pagar_anular.php");
	?>  
    <div class="container">
		<div class="panel panel-info">
		<div class="panel-heading">
		    
			<h4><img src="img/iconos/TICKET VENDIDOS.png" width="25px"> Tickets</h4>
		</div>
			<div class="panel-body">
			<?php 
				include("modal/ver_ticket.php");
			?>
				<form class="form-horizontal" role="form" id="datos_cotizacion">

				<div class="form-group row">
						<label for="q" class="col-md-2 control-label"># Tickets o Serial</label>
						<div class="col-md-5">
								<input type="text" class="form-control" id="q" placeholder="Número de Ticket" onkeyup='load(1);'>
						</div>

						<div class="col-md-3">
								<button type="button" class="btn btn-info" onclick='load(1);'>
										Buscar</button>
								<span id="loader"></span>
						</div>
						<div class="btn-group pull-right">
							<a href="nueva_taquilla.php" class="btn btn-info">Nuevo Ticket</a>
						</div>
				</div>
				 
			</form>
				<div id="resultados"></div><!-- Carga los datos ajax -->
				<div class='outer_div'></div><!-- Carga los datos ajax -->
			</div>
		</div>	
		
	</div>
	<hr>
	<?php
	include("footer.php");
	?>
	<script type="text/javascript" src="js/VentanaCentrada.js"></script>
	<script type="text/javascript" src="js/facturas.js"></script>
	<script>
		function ver_ticket(id){ 
			$('.modal-body-ticket').load('getTicket.php?id='+id,function(){
				$('#myModal').modal({show:true});
			});
		} 
		function eliminar(id){ 
			$('#myModalAnular').modal({show:true});
		 }

		$('.modal').on('hidden.bs.modal', function(){  
			$("#resultados_ajax3").html("");
			$("#resultados_ajax2").html("");
			$(this).find('form')[0].reset();  
			$("label.error").remove();  
		});

            $("#anular_ticket" ).submit(function( event ) {
            $('#btnanular').attr("disabled", true);
			$("#resultados_ajax2").html("");
			$("#resultados_ajax3").html("");
            var parametros = $(this).serialize();
                $.ajax({
                        type: "POST",
                        url: "ajax/anular_ticket.php",
                        data: parametros,
                        beforeSend: function(objeto){
                            $("#resultados_ajax2").html("Mensaje: Cargando...");
                        },
                        success: function(datos){
 
							$("#resultados_ajax2").html(datos);
                        $('#btnanular').attr("disabled", false);  
                    }
                });
            event.preventDefault();
            })
	 
</script>
  </body>
</html>