<?php
	
	/*-------------------------
        Descripcion:Sistema de Venta y Control de juegos de azar
	Autor: Ing .Norbelys Naguanagua	 
	Mail: norbelysnaguanagua21@gmail.com
        Version: 1.0       
	---------------------------*/
	session_start();
	if (!isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] != 1) {
        header("location: login.php");
		exit;
        }
	$active_facturas="active";
	$active_productos="";
	$active_clientes="";
	$active_usuarios="";	
	$title="Nueva Ruleta | Venta";
	
	/* Connect To Database*/
	require_once ("config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
	require_once ("config/conexion.php");//Contiene funcion que conecta a la base de datos
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include("head.php");?>
  </head>
  <body>
	<?php
	include("navbar.php");
	?>  
      <div class="container-fluid" style="display: none;">	 
      <form class="form-horizontal" role="form" id="datos_factura">
            <div class="form-group row">
                <label for="empresa" class="col-md-1 control-label">Agencia</label>
                <div class="col-md-3">
                        <select class="form-control input-sm" id="id_vendedor">
                         
                                <?php
                                        $sql_vendedor=mysqli_query($con,"select * from users where user_id= $_SESSION[user_id]");
                                        while ($rw=mysqli_fetch_array($sql_vendedor)){
                                                $id_vendedor=$rw["user_id"];
                                                $nombre_vendedor=$rw["firstname"]." ".$rw["lastname"];
                                                if ($id_vendedor==$_SESSION['user_id']){
                                                        $selected="selected";
                                                } else {
                                                        $selected="";
                                                }
                                                ?>
                                                <option value="<?php echo $id_vendedor?>" <?php echo $selected;?>><?php echo $nombre_vendedor?></option>
                                                <?php
                                        }
                                ?>
                        </select>
                </div>
                    <label for="tel2" class="col-md-1 control-label">Fecha</label>
                    <div class="col-md-2">
                            <input type="text" class="form-control input-sm" id="fecha" value="<?php echo date("d/m/Y");?>" readonly>
                    </div>
                    <label for="email" class="col-md-1 control-label">Pago</label>
                    <div class="col-md-3">
                            <select class='form-control input-sm' id="condiciones">
                                    <option value="2">Efectivo</option>
                             </select>
                    </div>
             </div>

    </form>
    </div>
      <div class="container-fluid" style="display: block;">	 
      <div class="form-group row">
         <label for="email" class="col-md-1 control-label">Tipo Ruleta</label>
                    <div class="col-md-2">
                <select class="form-control input-sm" id="id_tipr" onchange="buscar()">
                       <option value="0" >Seleccione</option>
                    <?php
                    $sql_tip_rule=mysqli_query($con,"select * from tipo_ruleta where status='1'");
                    while ($rw=mysqli_fetch_array($sql_tip_rule)){

                            $tipo_ruleta=$rw["id"];
                             $nombre_tipo_r=$rw["nombre"];

                            ?>
                    <option  value="<?php echo $tipo_ruleta?>"><?php echo $nombre_tipo_r?></option>
                            <?php
                    }
                      ?>
                </select>
            </div>
     </div>
           
          <div class="outer_div"></div>
      
    <div class="col-md-3">
           
   <table class="table" >
                      <thead>
                          <tr>
                             <p class="bg-primary">TICKET EN VENTA</p>
                          </tr>
                      </thead>
                      <tbody>
                     <div id="resultados" class='col-md-1' >
                     </div> 
                      </tbody>
                  </table>
           </div>
          
	
	<?php
	include("footer.php");
	?>
	<script type="text/javascript" src="js/VentanaCentrada.js"></script>
	<script type="text/javascript" src="js/nueva_ruleta.js"></script>
    <link href="css/jquery-ui.css" rel="stylesheet" type="text/css"/>
    <script src="boostrap/jquery-iu.js" type="text/javascript"></script>
    <link href="css/style_1.css" rel="stylesheet" type="text/css"/> 
  </body>
</html>