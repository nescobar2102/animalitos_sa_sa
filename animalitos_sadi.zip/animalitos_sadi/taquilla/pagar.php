<?php
/*-----------------------------
  Descripcion: Sistema de Venta y Control de juegos de azar
  Autor: Ing. Norbelys Naguanagua
  Mail: norbelysnaguanagua21@gmail.com
  Version: 1.1       
--------------------------------*/
session_start();
if (!isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] != 1) {
    header("location: login.php");
    exit;
}
$active_facturas = "active";
$active_productos = "";
$active_clientes = "";
$active_usuarios = "";    
$title = "Nuevo Ticket | Venta";

/* Connect To Database*/
require_once("config/db.php"); // Contiene las variables de configuracion para conectar a la base de datos
require_once("config/conexion.php"); // Contiene funcion que conecta a la base de datos
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("head.php"); ?>
</head>
<body>
    <?php include("navbar.php"); ?>  

    <div class="container-fluid">  
        <table class="table table-striped">
            <tr class="info">               
                <th>Fecha</th>					
                <th>Loteria</th>
                <th>Número Premiado</th>
                <th>Monto de Apuesta</th>
                <th>Monto Ganado</th>
                <th></th> 
            </tr>  
<?php 
$id_fact = $_GET['id'];
$total_pag = 0;

$sql4 = mysqli_query($con, "SELECT * FROM facturas WHERE numero_factura='$id_fact'");                                       
$row4 = mysqli_fetch_array($sql4);
$fecha = $row4['fecha_factura'];
$numero_factura = $row4['numero_factura'];
$condiciones = $row4['condiciones'];
$estad = $row4['estado_factura'];
$id_moneda = $row4['id_moneda']; 

$sql_moneda = mysqli_query($con, "SELECT * FROM currencies WHERE id='$id_moneda'"); // simbolo moneda
$rw_moneda = mysqli_fetch_array($sql_moneda);
$simbolo_moneda = $rw_moneda["symbol"];

$sql = mysqli_query($con, "SELECT * FROM detalle_factura WHERE numero_factura='$numero_factura'");
while ($row = mysqli_fetch_array($sql)) {
    $signo = $row['id_signo'];
    $loteria = $row['id_producto'];
    $id_horario = $row['id_horario'];
    $cantidad = $row['cantidad'];
    $precio = $row['precio_venta'];

    $fecha_ju = date("Y-m-d", strtotime($fecha));
    $date = date('Y-m-d');
    $dias = (strtotime($date) - strtotime($fecha_ju)) / 24 / 3600;

    if ($dias > 3) {
        echo "<script>alert('Ticket Vencido')</script>";
        echo "<script>window.close(); </script>";
        echo "<script>window.location.href='facturas.php'</script>"; 
    }
    if ($estad == 2) {
        echo "<script>alert('Ticket Pagado')</script>";
        echo "<script>window.close(); </script>";
        echo "<script>window.location.href='facturas.php'</script>";         
    }

    $sql2 = mysqli_query($con, "SELECT * FROM resultados WHERE id_loteria='$loteria' AND numero='$cantidad' AND id_signo='$signo' AND id_horario='$id_horario' AND fecha_sorteo='$fecha'");                   
    while ($row2 = mysqli_fetch_array($sql2)) {
        $id_loteria = $row2['id_loteria'];
        if ($id_loteria) {
            $id_vendedor = $_SESSION['user_id'];
            if ($condiciones == 2) {
                $bloq1 = mysqli_query($con, "SELECT * FROM products WHERE id_producto='$loteria'");
                $bloqrow1 = mysqli_fetch_array($bloq1);	 

                $tipo_ruleta = $bloqrow1["id_tipo"]; 
                $nom_loteria = $bloqrow1['nombre_producto'];					 
                $pago_ruleta = mysqli_query($con, "SELECT paga FROM tipo_ruleta WHERE id='$tipo_ruleta'");
                $pago_ruleta11 = mysqli_fetch_array($pago_ruleta);	 
                $paga = $pago_ruleta11["paga"];  
                $monto_total = $precio * $paga;    
                $total_pag += $monto_total;   
            } 
            if ($condiciones == 1) { 
                $sql3 = mysqli_query($con, "SELECT * FROM products WHERE id_producto='$id_loteria'");
                $row1 = mysqli_fetch_array($sql3);
                $sqlpago = mysqli_query($con, "SELECT * FROM comisiones WHERE pago_id_vendedor=$id_vendedor");
                $rowpago = mysqli_fetch_array($sqlpago);
                if (strlen($cantidad) < 3) {
                    $monto_pag = $rowpago['pago_terminal'];	  
                }
                if (strlen($cantidad) == 3) {
                    $monto_pag = $rowpago['pago_triple'];	 
                }
                $monto_pag1 = floatval($monto_pag);  
                $nom_loteria = $row1['nombre_producto'];					 
                $monto_total = $precio * $monto_pag1;    
                $total_pag += $monto_total; 
            }
?>  
            <tr> 
                <td><?php echo $fecha; ?></td>
                <td><?php echo $nom_loteria; ?></td>
                <td><?php echo $cantidad; ?></td>
                <td><?php echo number_format($precio, 0); ?>  </td>
                <td><?php echo number_format($monto_total, 0); ?></td>
            </tr>
<?php
        }
    }
}
?>
        </table>
        
        <table class="table table-striped">
            <tr class="info"> 
                <th>Nro Ticket</th>	
                <th>Serial</th>	
                <th>Monto Premio</th>	
                <th>Acciones</th>	 
            </tr>     
            <tr>  
                <td style="width: 200px;">
                    <?php if ($total_pag > 0): ?>
                        <input type="text" class="form-control" id="ticket" placeholder="Nro Ticket" minlength="1">
                    <?php endif; ?>
                </td>
                <td style="width: 200px;">
                    <?php if ($total_pag > 0): ?>
                        <input type="text" class="form-control" id="serial" placeholder="Serial" minlength="6">
                    <?php endif; ?>
                </td>
                <td style="width: 200px;">
                    <?php if ($total_pag > 0): ?>
                        <input type="text" class="form-control" id="monto_premio" value="<?php echo number_format($total_pag, 0); ?>" readonly>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($total_pag > 0): ?>
                        <span class="">Ticket Premiado</span> 
                        <button type="button" class='btn btn-default' title='Pagar Ticket' onclick="premiar_t('<?= $id_fact; ?>', '2', '<?= $total_pag; ?>')">
                            <img src="img/iconos/pagar.png" width="30px">
                        </button>
                    <?php else: ?>
                        <span class="">Ticket No premiado</span>
                    <?php endif; ?> 
                </td> 
            </tr>
        </table>
        <a type="button" class="btn btn-success" href="facturas.php">Premiar otro Ticket</a>
    </div>
    <?php include("footer.php"); ?>   

    <script>
    function premiar_t(id, s, p) {
        alert("ID Factura: " + id + "\nEstado: " + s + "\nTotal a Pagar: " + p);
        
        $.ajax({
            url: 'ajax/pagar_ticket.php',
            type: 'POST',
            data: {
                id: id,
                s: s,
                p: p,
                serial: $('#serial').val(),
                ticket: $('#ticket').val()
            },
            success: function(response) {
                var result = JSON.parse(response);                
                    var mensajeFinal = result.messages.join("\n");
                     alert(mensajeFinal);               
            },
            error: function(xhr, status, error) {
                console.error(error);
                alert("Error al procesar el pago.");
            }
        });
    }
    </script>
</body>
</html>