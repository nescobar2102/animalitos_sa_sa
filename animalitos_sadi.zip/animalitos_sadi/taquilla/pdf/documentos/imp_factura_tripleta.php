<?php
/* -------------------------
  Descripcion:Sistema de Venta y Control de juegos de azar
  Autor: Ing .Norbelys Naguanagua
  Mail: norbelysnaguanagua21@gmail.com
  Version: 1.1
  --------------------------- */
session_start();
if (!isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] != 1) {
    header("location: ../../login.php");
    exit;
}
/* Connect To Database */
include("../../config/db.php");
include("../../config/conexion.php");
//Archivo de funciones PHP
include("../../funciones.php");
$session_id = session_id(); 
ini_set('date.timezone','America/Caracas'); 
$hora= date('H:i:s');

//$sql_count = mysqli_query($con, "select * from tmp where session_id='" . $session_id . "'");
if (!isset($_SESSION['variable'])){
    echo "<script>alert('No hay jugadas agregados al ticket')</script>";
    echo "<script>window.close();</script>";
    exit;
}
$jugada = $_SESSION['variable'];  

//Variables por GET
$id_cliente = 0;
$id_vendedor = intval($_GET['id_vendedor']);
$condiciones = 3;
$serial =   rand(111111, 999999);
//Fin de variables por GET
$sql = mysqli_query($con, "select LAST_INSERT_ID(numero_factura) as last from facturas order by id_factura desc limit 0,1 ");
$rw = mysqli_fetch_array($sql);
$numero_factura = $rw['last'] + 1;
 
$sqlmoneda =   mysqli_query($con, "select currencies.id, currencies.name , currencies.symbol , currencies.code
                                    from comisiones,currencies where pago_id_vendedor='$_SESSION[user_id]'
                                    and comisiones.id_moneda=currencies.id and estatus=1");
$rw_mod = mysqli_fetch_array($sqlmoneda);
$id_moneda = $rw_mod["id"]; 
$simbolo_moneda = $rw_mod["symbol"];

?> 
<html><body> 
        <style type="text/css" media="print">
            @media print {
                #btn_print {display:none;}
                .fontmin {display:none;}
                #muestra {width:40%;}
                .headline{display:none;}
                .div-footer{display:none;}
                .div-footer-img{display:none;}
                .copy{display:none;}
                .msj{ffont-size: 9px;line-height: 1.5em;width: 90%;margin: 0 auto;;}
                .p{text-align: justify;}
                @page { margin: 0; }
            }
        </style>

        <div id="muestra"> 
            <br>
            <br>
            <?php
            
           $sql_user = mysqli_query($con, "select firstname,lastname from users where user_id='$id_vendedor'");
            $rw_user = mysqli_fetch_array($sql_user);
            ?>
            <span style="font-size:9pt;">SABANETA</span>
            <span style="font-size:9pt;"><br>VENDEDOR: <?= $rw_user['firstname'] . " " . $rw_user['lastname']; ?></span>
            
            <span style="font-size:9pt;"><br>TICKET: <?= $numero_factura; ?></span>
            <span style="font-size:9pt;"><br>CP: <?= $serial; ?></span>      
            <span style="font-size:9pt;"><br><?= date("d/m/Y") . "  :::  " . date("H:m:s") ?></span>      
            <div>-------------------------------</div>

            <?php
                $nums = 1;
                $sumador_total = 0; //loteria  $num_jugados = 0;
                $num_jugados = 0;
                
                for($x = 0; $x < count($jugada); $x++) {	
          

                 $idloteria = $jugada[$x]['tipo_loteria'];
                 $precio_venta = $jugada[$x]['precio_venta']; 
                 $cantidad = $jugada[$x]['cantidad'];
                     
                $sql = mysqli_query($con, "select * from products
                  where products.id_producto=$idloteria ");
   
                while ($row = mysqli_fetch_array($sql)) {
                    $num_jugados ++;
                    $id_producto = $row["id_producto"];
                    $codigo_producto = $row['codigo_producto'];                    
                    $nombre_producto = $row['nombre_producto'];
                    $id_horario = $jugada[$x]['horario'];
                    $nombre_horario = $jugada[$x]['nombre_horario'];
                 
                    $precio_venta_f = number_format($precio_venta, 2); //Formateo variables
                    $precio_venta_r = str_replace(",", "", $precio_venta_f); //Reemplazo las comas
                    $precio_total = $precio_venta_r;
                    $precio_total_f = number_format($precio_total, 2); //Precio total formateado
                    $precio_total_r = str_replace(",", "", $precio_total_f); //Reemplazo las comas
                    $sumador_total+=$precio_total_r; //Sumador
                    if ($nums % 2 == 0) {
                        $clase = "clouds";
                    } else {
                        $clase = "silver";
                    }
                    $loteria = $nombre_producto . " " .$nombre_horario ;
                    ?>                         
                <span style="font-size:9pt;"><br>
                 <?= "(".$cantidad . ")  " . $loteria . "  " . $precio_venta_f ?></span>    
                <?php
                ini_set('date.timezone','America/Caracas');
                $date = date("Y-m-d");
                //Insert en la tabla detalle_cotizacion
               
                $insert_detail = mysqli_query($con, "INSERT INTO detalle_factura ( `numero_factura`, `id_producto`, `id_horario`,
                 `cantidad`, `precio_venta`,  `fecha`) 
                 VALUES ('$numero_factura','$id_producto','$id_horario','$cantidad','$precio_venta_r','$date')");

                //actualiza monto disponible de los números 
                /*$sqlupdmonto = "UPDATE jug_bloqueo SET monto=monto-'$precio_venta_r' where id_vendedor='$id_vendedor' 
                            and numero_bloq='$cantidad' and id_producto='$id_producto'";
                $query_update = mysqli_query($con, $sqlupdmonto);*/

                $nums++;
            }
        }
            $impuesto = get_row('perfil', 'impuesto', 'id_perfil', 1);
            $subtotal = number_format($sumador_total, 2, '.', '');
            $total_iva = ($subtotal * $impuesto ) / 100;
            $total_iva = number_format($total_iva, 2, '.', '');
            $total_factura = $subtotal; 

            $date = date("Y-m-d"); 
             
            $insert = mysqli_query($con, "INSERT INTO facturas ( `numero_factura`, `fecha_factura`, `id_cliente`, `id_vendedor`, 
                                        `condiciones`, `total_venta`, `premio`, `estado_factura`, `id_moneda`, `serial`) 
                                        VALUES  ( '$numero_factura','$date','$id_cliente','$id_vendedor','$condiciones','$subtotal',
                                        '0','1','$id_moneda' ,'$serial')");
         unset($_SESSION['variable']); 
            ?>

            <div>-------------------------------</div>
            <span style="font-size:9pt;"><br>NUMEROS JUGADOS:  <?= $num_jugados; ?></span>
            <span style="font-size:9pt;"><br>TOTAL TICKET:   <?= $total_factura; ?> Bs</span>   
            <span style="font-size:9pt;"><br>CADUCA A LOS 3 DIAS</span> 
         
        </div>
        <script>
            function imprSelec(muestra) {
                var ficha = document.getElementById(muestra);
                var ventimp = window.open(' ', 'popimpr');
                ventimp.document.write(ficha.innerHTML);
                ventimp.document.close();
                ventimp.print();
               ventimp.close();
            }
            document.addEventListener("DOMContentLoaded", function (event) {
                imprSelec('muestra');
            });
        </script>
    </body>
</html>
