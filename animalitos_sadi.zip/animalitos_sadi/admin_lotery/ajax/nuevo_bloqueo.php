<?php
/*-------------------------
        Descripcion:Sistema de Venta y Control de juegos de azar
	Autor: Ing .Norbelys Naguanagua	 
	Mail: norbelysnaguanagua21@gmail.com
        Version: 1.0       
	---------------------------*/
include('is_logged.php');//Archivo verifica que el usario que intenta acceder a la URL esta logueado
	/*Inicia validacion del lado del servidor*/
	if (empty($_POST['producto'])) {
           $errors[] = "Producto vacío";
        } else if (empty($_POST['numero'])){
			$errors[] = "Numero vacío";
		} else if (empty($_POST['precio'])){
			$errors[] = "Precio de bloqueo";
		} else if (
			!empty($_POST['producto']) &&
			!empty($_POST['numero']) &&
			
			!empty($_POST['precio'])
		){
		/* Connect To Database*/
		require_once ("../config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
		require_once ("../config/conexion.php");//Contiene funcion que conecta a la base de datos
		// escaping, additionally removing everything that could be (html/javascript-) code
		$producto=mysqli_real_escape_string($con,(strip_tags($_POST["producto"],ENT_QUOTES)));
		$numero=mysqli_real_escape_string($con,(strip_tags($_POST["numero"],ENT_QUOTES)));
		
		$precio_venta=floatval($_POST['precio']);
		  ini_set('date.timezone','America/Caracas');
		$date_added=date("Y-m-d");
                $id_vendedor=$_POST['usuario'];
		$sql="INSERT INTO jug_bloqueo (id_producto, numero_bloq, status, date, monto,id_vendedor) VALUES ('$producto','$numero','1','$date_added','$precio_venta','$id_vendedor')";
		$query_new_insert = mysqli_query($con,$sql);
			if ($query_new_insert){
				$messages[] = "Número Bloqueado exitosamente";
			} else{
				$errors []= "Lo siento algo ha salido mal intenta nuevamente.".mysqli_error($con);
			}
		} else {
			$errors []= "Error desconocido.";
		}
		
		if (isset($errors)){
			
			?>
			<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert">&times;</button>
					<strong>Error!</strong> 
					<?php
						foreach ($errors as $error) {
								echo $error;
							}
						?>
			</div>
			<?php
			}
			if (isset($messages)){
				
				?>
				<div class="alert alert-success" role="alert">
						<button type="button" class="close" data-dismiss="alert">&times;</button>
						<strong>¡Bien hecho!</strong>
						<?php
							foreach ($messages as $message) {
									echo $message;
								}
							?>
				</div>
				<?php
			}

?>