<?php
	/*-------------------------
        Descripcion:Sistema de Venta y Control de juegos de azar
	Autor: Ing .Norbelys Naguanagua	 
	Mail: norbelysnaguanagua21@gmail.com
        Version: 1.1       
	---------------------------*/
	include('is_logged.php');//Archivo verifica que el usario que intenta acceder a la URL esta logueado
	/* Connect To Database*/
	require_once ("../config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
	require_once ("../config/conexion.php");//Contiene funcion que conecta a la base de datos
	
	$action = (isset($_REQUEST['action'])&& $_REQUEST['action'] !=NULL)?$_REQUEST['action']:'';
	if (isset($_GET['id'])){
             $id_vendedor=$_SESSION['user_id'];
                $status=intval($_GET['s']);
				$numero_factura=intval($_GET['id']);
                $upd_anular="update facturas set estado_factura='$status' where numero_factura='$numero_factura' and id_vendedor='$id_vendedor'";
	 
		if ($update1=mysqli_query($con,$upd_anular) ){
			?>
			<div class="alert alert-success alert-dismissible" role="alert">
			  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			  <strong>Aviso!</strong> Ticket anulado exitosamente.
			</div>
			<?php 
		}else {
			?>
			<div class="alert alert-danger alert-dismissible" role="alert">
			  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			  <strong>Error!</strong> No se puedo anular el ticket.
			</div>
			<?php
			
		}
	}
	if($action == 'ajax'){
             $id_vendedor=$_SESSION['user_id'];
		// escaping, additionally removing everything that could be (html/javascript-) code
         $q = mysqli_real_escape_string($con,(strip_tags($_REQUEST['q'], ENT_QUOTES)));
		 $sTable = "facturas, users";
			if($id_vendedor==='1'){
				$sWhereadmin = "";
				$sWhereadmin.=" WHERE facturas.id_vendedor=users.user_id and estado_factura in (1,2,3,0)" ;
				if ( $_GET['q'] != "" )
				{
					$sWhereadmin.= " and  ( facturas.fecha_factura= '$q')";						
				}
				$sWhereadmin.=" order by facturas.id_factura desc";		
			}else{
		
				$sWhere = "";
				$sWhere.=" WHERE facturas.id_vendedor=users.user_id and estado_factura in (1,2,3) and users.user_id='$id_vendedor'" ;
				if ( $_GET['q'] != "" )
					{
						$sWhere.= " and  ( facturas.fecha_factura= '$q')";						
					}
				 $sWhere.=" order by facturas.id_factura desc";		
			 }
                  
			
		include 'pagination.php'; //include pagination file
		//pagination variables
		$page = (isset($_REQUEST['page']) && !empty($_REQUEST['page']))?$_REQUEST['page']:1;
		$per_page = 10; //how much records you want to show
		$adjacents  = 4; //gap between pages after number of adjacents
		$offset = ($page - 1) * $per_page;
		//Count the total number of row in your table*/
			if($id_vendedor==='1'){
				$count_query   = mysqli_query($con, "SELECT count(*) AS numrows FROM $sTable  $sWhereadmin");
			}else{
				$count_query   = mysqli_query($con, "SELECT count(*) AS numrows FROM $sTable  $sWhere");
			}
		$row= mysqli_fetch_array($count_query);
		$numrows = $row['numrows'];
		$total_pages = ceil($numrows/$per_page);
		$reload = './facturas.php';
		//main query to fetch the data
			
			if ($id_vendedor==='1'){
			 	 $sql="SELECT * FROM $sTable $sWhereadmin LIMIT $offset,$per_page";
			}else{
			 	 $sql="SELECT * FROM  $sTable $sWhere LIMIT $offset,$per_page";
			}
		 
		$query = mysqli_query($con, $sql);
		//loop through fetched data
		if ($numrows>0){
			echo mysqli_error($con);
			?>
			<div class="table-responsive">
			  <table class="table">
				<tr  class="info">
					<th>#</th>
					<th>Fecha</th>					
					<th>Agencia</th>
					<th>Estado</th>
					<th class='text-right'>Total</th>
					<th class='text-right'>Acciones</th>					
				</tr>
				<?php
				while ($row=mysqli_fetch_array($query)){
						$id_factura=$row['id_factura'];
						$numero_factura=$row['numero_factura'];
						$fecha=date("d/m/Y", strtotime($row['fecha_factura']));
						$nombre_vendedor=$row['firstname']." ".$row['lastname'];
						$id_moneda =$row['id_moneda']; 
                                                
						$sql_moneda=mysqli_query($con,"select * from currencies where id='$id_moneda'"); //simbolo moneda
						$rw_moneda=mysqli_fetch_array($sql_moneda);
						$simbolo_moneda = $rw_moneda["symbol"];

						$estado_factura=$row['estado_factura'];
						if ($estado_factura==1){$text_estado="Jugando";$label_class='label-warning';}
                         elseif($estado_factura==0){$text_estado="Anulado";$label_class='label-danger';}
						elseif($estado_factura==2){$text_estado="Pagado";$label_class='label-success';} 
						elseif($estado_factura==3){$text_estado="Premiado";$label_class='label-info';}
						$total_venta=$row['total_venta'];
					?>
					<tr>
						<td><?php echo $numero_factura; ?></td>
						<td><?php echo $fecha; ?></td>						
						<td><?php echo $nombre_vendedor; ?></td>
						<td><span class="label <?php echo $label_class;?>"><?php echo $text_estado; ?></span></td>
						<td class='text-right'><?php echo number_format ($total_venta,2);  echo " ";?></td>					
					<td class="text-right">
							<a title="Ver Ticket"   data-toggle="modal" data-target="#myModalVer3" onclick="ver_ticket('<?php echo $numero_factura; ?>','2')" >
							<img src="img/iconos/ver.png" width="30px">
							</a>     
                    </td>
						
					</tr>
					<?php
                                            }
                                        ?>
				<tr>
					<td colspan=7><span class="pull-right"><?php
					 echo paginate($reload, $page, $total_pages, $adjacents);
					?></span></td>
				</tr>
			  </table>
			</div>
			<?php
		}else{ ?>              
                <div class="alert alert-success alert-dismissible" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<strong>Aviso!</strong> No existen tickets para la fecha seleccionada.
				</div>
               <?php 
			   } 
	}
?>