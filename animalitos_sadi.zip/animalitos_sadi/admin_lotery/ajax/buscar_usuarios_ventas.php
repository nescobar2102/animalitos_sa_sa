<?php
/* -------------------------
  Descripcion:Sistema de Venta y Control de juegos de azar
  Autor: Ing .Norbelys Naguanagua
  Mail: norbelysnaguanagua21@gmail.com
  Version: 1.0
  --------------------------- */
/* Connect To Database */
require_once ("../config/db.php"); //Contiene las variables de configuracion para conectar a la base de datos
require_once ("../config/conexion.php"); //Contiene funcion que conecta a la base de datos
include('is_logged.php'); //Archivo verifica que el usario que intenta acceder a la URL esta logueado
$action = (isset($_REQUEST['action']) && $_REQUEST['action'] != NULL) ? $_REQUEST['action'] : '';
$id_vendedor = $_SESSION['user_id'];
 
if ($action == 'ajax') {
    // escaping, additionally removing everything that could be (html/javascript-) code
    $q = mysqli_real_escape_string($con, (strip_tags($_REQUEST['q'], ENT_QUOTES)));
    $aColumns = array('user_name'); //Columnas de busqueda
    
    $sWhere = "";
    
    if ($_GET['tipo'] != "") { 
        $user_tipo = $_GET['tipo'];
    }
    if ($_GET['iduser'] != "") { 
        $user_depende = $_GET['iduser'];
    }


 
    // escaping, additionally removing everything that could be (html/javascript-) code
  $q = mysqli_real_escape_string($con,(strip_tags($_REQUEST['q'], ENT_QUOTES)));
  $sTable_account = "facturas,users,comisiones,currencies";
  $sTable = "users";
  $sWhere = "";
  
    $fecha=$q;
   // $sWhere.="  order by user_id desc";
    include 'pagination.php'; //include pagination file
    //pagination variables
    $page = (isset($_REQUEST['page']) && !empty($_REQUEST['page'])) ? $_REQUEST['page'] : 1;
    $per_page = 10; //how much records you want to show
    $adjacents = 4; //gap between pages after number of adjacents
    $offset = ($page - 1) * $per_page;  
    $search = '';
    $reload = './usuarios.php';
    //main query to fetch the data
    $id_vendedor = $_SESSION['user_id']; 
  
    if($user_tipo>0  &&  ($user_depende >0 ||  $user_depende!='undefined' )){     
    switch ($user_tipo) {         
            case '1': 
                $search = "and id_administrador='$user_depende' and id_banca=0 ";                               
               break;
           case '2':                    
               $search = "and id_banca='$user_depende' and id_intermediario=0";     
             break; 
           case '4':
               $search = "and id_intermediario='$user_depende'  and  id_agencia=0 ";    
               break;
           case '5':
               $search = "and id_agencia='$user_depende' ";    
               break;
     }
    }  else { 
         $search = "and tipo_user='".$_SESSION['tipo_user']."'";    
    }
    $sql = "SELECT * FROM  $sTable where id_admin='$id_vendedor' $search order by id_admin  LIMIT $offset,$per_page";
 
    $query = mysqli_query($con, $sql);
    $numrows=mysqli_num_rows($query);
    $total_pages = ceil($numrows / $per_page);
    //loop through fetched data
    if ($numrows > 0) {
        ?>
       <div class="table-responsive"> 
       <table class="table">
                <tr class="info">
                    <th >Id</th> 
                    <th>Usuario</th>
                    <th> </th>
                    <th>Ventas</th>
                    <th>Premios</th>
                    <th>Comision</th>
                    <th>Participacion</th> 
                    <th>Total</th> 
                </tr>
    </table>
 <?php
 		     $ventast=0;
             $premiost=0;
             $comisiont=0;
             $particit=0;
             $total_venta=0;
          while ($row = mysqli_fetch_array($query)) {
                    $user_id = $row['user_id']; 
                    $user_name = $row['user_name'];
                   $user_tipo_o = $row['tipo_user']; 
                
                    switch ($user_tipo_o) {
                        case '4':                        
                         $user_tipo = 'Intermediario';     
                         $search_account = "SELECT sum(total_venta) as ventas, sum(premio) as premios ,
                            sum(total_venta*comision_terminal/100) as comision,currencies.symbol  FROM facturas,users,comisiones,currencies
                              WHERE facturas.id_vendedor=users.user_id and users.user_id= comisiones.pago_id_vendedor
                                and comisiones.pago_id_vendedor=users.user_id and comisiones.pago_id_vendedor=facturas.id_vendedor 
                                and estado_factura in (1,2,3) and fecha_factura='$q' and facturas.id_moneda=currencies.id 
                                and id_intermediario ='$user_id '
                                GROUP BY facturas.id_moneda,id_vendedor LIMIT 0,10";   

                            break;
                        case '2':                    
                            $user_tipo = 'Banca';
                            $search_account = "SELECT sum(total_venta) as ventas, sum(premio) as premios ,
                            sum(total_venta*comision_terminal/100) as comision,currencies.symbol 
                            FROM facturas,users,comisiones,currencies
                              WHERE facturas.id_vendedor=users.user_id and users.user_id= comisiones.pago_id_vendedor
                                and comisiones.pago_id_vendedor=users.user_id and comisiones.pago_id_vendedor=facturas.id_vendedor 
                                and estado_factura in (1,2,3) and fecha_factura='$q' and facturas.id_moneda=currencies.id 
                                and id_banca ='$user_id '
                                GROUP BY facturas.id_moneda,id_vendedor LIMIT 0,10";
                          break;
                        case '3':
                            $user_tipo = 'Taquilla';
                        $search_account = "SELECT sum(total_venta) as ventas, sum(premio) as premios ,
                            sum(total_venta*comision_terminal/100) as comision,currencies.symbol 
                            FROM facturas,users,comisiones,currencies
                              WHERE facturas.id_vendedor=users.user_id and users.user_id= comisiones.pago_id_vendedor
                                and comisiones.pago_id_vendedor=users.user_id and comisiones.pago_id_vendedor=facturas.id_vendedor 
                                and estado_factura in (1,2,3) and fecha_factura='$q' and facturas.id_moneda=currencies.id 
                                and facturas.id_vendedor ='$user_id'
                                GROUP BY facturas.id_moneda,id_vendedor LIMIT 0,10";
                            break;
                        case '1':
                            $user_tipo = 'Administrador';   
                            $search_account = "SELECT sum(total_venta) as ventas, sum(premio) as premios ,
                            sum(total_venta*comision_terminal/100) as comision,currencies.symbol
                             ,(select user_name from users where user_id='$id_vendedor ') as user_name ,
                             (select tipo_user from users where user_id='$id_vendedor ') as tipo_user ,
                              $id_vendedor as user_id FROM facturas,users,comisiones,currencies
                              WHERE facturas.id_vendedor=users.user_id and users.user_id= comisiones.pago_id_vendedor
                                and comisiones.pago_id_vendedor=users.user_id and comisiones.pago_id_vendedor=facturas.id_vendedor 
                                and estado_factura in (1,2,3) and fecha_factura='$q' and facturas.id_moneda=currencies.id 
                                and id_administrador ='$user_id'
                                GROUP BY facturas.id_moneda,id_vendedor LIMIT 0,10";                  
                            break;
                        case '5':
                            $user_tipo = 'Agencia';
                            $search_account = "SELECT sum(total_venta) as ventas, sum(premio) as premios ,
                            sum(total_venta*comision_terminal/100) as comision,currencies.symbol 
                            FROM facturas,users,comisiones,currencies
                              WHERE facturas.id_vendedor=users.user_id and users.user_id= comisiones.pago_id_vendedor
                                and comisiones.pago_id_vendedor=users.user_id and comisiones.pago_id_vendedor=facturas.id_vendedor 
                                and estado_factura in (1,2,3) and fecha_factura='$q' and facturas.id_moneda=currencies.id 
                                and id_agencia ='$user_id'
                                GROUP BY facturas.id_moneda,id_vendedor LIMIT 0,10";
                            break;
                    }
                    
            
                    $querycom = mysqli_query($con, $search_account);
                 
                        ?>
                         <div class="panel-group" id="accordion">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                 <h4 class="panel-title">
                                 <p data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $user_id; ?>"><?php echo $user_name; ?></p>
                                 </h4>

                                 </div>
                                 <div id="collapse<?php echo $user_id; ?>" class="panel-collapse collapse">
                                 <div class="panel-body"> 
                                    <?php  
                                     
                                    while ($rowcom = mysqli_fetch_array($querycom)) {
                                        
                                            $ventast=0;
                                            $premiost=0;
                                            $comisiont=0;
                                            $particit=0;
                                            $total_venta=0;
                                        $ventas=$rowcom['ventas'];
                                        $premios=$rowcom['premios'];
                                        $comision=$rowcom['comision'];	
                                        $symbol=$rowcom['symbol'];			
                                        $total=$ventas-($premios+$comision);
                                        ?> 
                                           <table class="table"> 
                                            <tr>
                                            <td><?php echo $id_vendedor; ?></td>
                                            <td> <a  onclick="load('<?=$user_tipo_o; ?>' ,'<?= $user_id; ?>')" ><?php echo $user_name; ?> (<?= $user_tipo; ?>)</a></td>
                                            <td><?php echo number_format ($ventas,2);  echo " ";echo $symbol;  ?></td>						 
                                            <td><?php echo number_format ($premios,2);  echo " ";echo $symbol; ?></td>
                                            <td><?php echo number_format ($comision,2); echo " ";echo $symbol;  ?></td>	
                                            <td><?php echo number_format ($particit,2); echo " ";echo $symbol;  ?></td>	
                                            <td><?php echo number_format ($total,2); echo " ";echo $symbol;  ?></td>		 
                                            </tr>
                                </table>
                                <?php  
                 
                            }
                            ?>  
                            </div>
                        </div>
                        </div>
                        <?php  
                 
                }
                ?>  
   
</div>
       
 
        <?php
    } 
}
?>
<script type="text/javascript">
function ver(id){
   var fecha= $('#fecha').val();
window.location="../admin_lotery/ver_ticket.php?id="+id+"&fecha="+fecha;
}
</script>
