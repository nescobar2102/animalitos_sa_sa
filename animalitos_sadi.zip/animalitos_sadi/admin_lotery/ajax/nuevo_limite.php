<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=gb18030">
        <?php include("head.php"); ?>

    </head>
    <body>
        <?php
        include("navbar.php");
       /* Connect To Database */
    ("config/db.php"); //Contiene las variables de configuracion para conectar a la base de datos
            require_once ("config/conexion.php"); //Contiene funcion que conecta a la base de datos


          /* -------------------------
          Descripcion:Sistema de Venta y Control de juegos de azar
          Autor: Ing .Norbelys Naguanagua
          Mail: norbelysnaguanagua21@gmail.com
          Version: 1.0
          --------------------------- */
        include('is_logged.php'); //Archivo verifica que el usario que intenta acceder a la URL esta logueado
        /* Inicia validacion del lado del servidor */


        if (empty($_POST['producto'])) {
            $errors[] = "Loteria vacía";
        } else if (empty($_POST['numero'])) {
            $errors[] = "Numero vacío";
        } else if (
                !empty($_POST['producto']) &&
                !empty($_POST['numero'])
        ) {
            /* Connect To Database */
      
           
            // escaping, additionally removing everything that could be (html/javascript-) code
            $producto = mysqli_real_escape_string($con, (strip_tags($_POST["producto"], ENT_QUOTES)));

            $numero = floatval($_POST['numero']);
            $date_added = date("Y-m-d");
            $id_vendedor = $_POST['usuario'];

            $sql = "INSERT INTO limites (id_loteria, monto,id_vendedor) VALUES ('$producto','$numero','$id_vendedor')";


            $query_new_insert = mysqli_query($con, $sql);
            if ($query_new_insert) {
                $messages[] = "Su cambio fue realizado con éxito";
            } else {
                $errors [] = "Lo siento algo ha salido mal intenta nuevamente." . mysqli_error($con);
            }
        } else {
            $errors [] = "Error desconocido.";
        }

        if (isset($errors)) {
            ?>
            <div class="alert alert-danger" role="alert">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong>Error!</strong> 
                <?php
                foreach ($errors as $error) {
                    echo $error;
                }
                ?>
            </div>
            <?php
        }
        if (isset($messages)) {
            ?>
            <div class="alert alert-success" role="alert">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong>¡Bien hecho!</strong>
    <?php
    foreach ($messages as $message) {
        echo $message;
    }
    ?>
            </div>
                <?php
            }


            include 'footer.php';
            ?>

    </body>
 

<script type="text/javascript">
    function redireccionar() {
     window.history.back();
     
    }
    setTimeout("redireccionar()", 2000);
</script>
