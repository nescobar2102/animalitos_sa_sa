<?php

/* Connect To Database*/
session_start();
require_once ("../config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
require_once ("../config/conexion.php");//Contiene funcion que conecta a la base de datos
  $id_vendedor = $_SESSION['user_id'];
if(isset($_POST['id']))
{
 $id = $_POST['id']; 
  
 switch ($id) {
    case 4: 
       echo "<select id='id_banca' name='id_banca'  class='form-control'>";
        $find=mysqli_query($con,"SELECT user_id,user_name ,
        case tipo_user  when 1 then 'Administrador'  when 2 then 'Banca'  when 3 then 'Taquilla' when 4 then 'Intermediarios' when 5 then 'Agencia'   end as tipo_usuario 
        FROM users  
        WHERE id_admin='$id_vendedor'  and tipo_user='2'");
        
        while($row=mysqli_fetch_array($find))
           { 
           echo "<option value=".$row['user_id']." >".$row['user_name']." - (".$row['tipo_usuario'].")</option>";
           } 
       echo "</select>";
        break;
    case 2:
        echo "<select id='id_administrador' name='id_administrador'   class='form-control'>";
        $find=mysqli_query($con,"SELECT user_id,user_name ,
        case tipo_user  when 1 then 'Administrador'  when 2 then 'Banca'  when 3 then 'Taquilla' when 4 then 'Intermediarios' when 5 then 'Agencia'   end as tipo_usuario 
        FROM users  
        WHERE id_admin='$id_vendedor' or user_id='$id_vendedor'  and tipo_user='1'");
        
        while($row=mysqli_fetch_array($find))
           { 
           echo "<option value=".$row['user_id']." >".$row['user_name']." - (".$row['tipo_usuario'].")</option>";
           } 
       echo "</select>";
        break;
    case 3:
        echo "<select id='id_banca' name='id_banca'   class='form-control'>";
        $find=mysqli_query($con,"SELECT user_id,user_name ,
        case tipo_user  when 1 then 'Administrador'  when 2 then 'Banca'  when 3 then 'Taquilla' when 4 then 'Intermediarios' when 5 then 'Agencia'   end as tipo_usuario 
        FROM users  
        WHERE id_admin='$id_vendedor'  and tipo_user='2'");
        
        while($row=mysqli_fetch_array($find))
           { 
           echo "<option value=".$row['user_id']." >".$row['user_name']." - (".$row['tipo_usuario'].")</option>";
           } 
       echo "</select>";
       echo "<select id='id_intermediario' name='id_intermediario'   class='form-control'>";
            $find=mysqli_query($con,"SELECT user_id,user_name ,
            case tipo_user  when 1 then 'Administrador'  when 2 then 'Banca'  when 3 then 'Taquilla' when 4 then 'Intermediarios' when 5 then 'Agencia'   end as tipo_usuario 
            FROM users  
            WHERE id_admin='$id_vendedor' and tipo_user='4'");
            
            while($row=mysqli_fetch_array($find))
                { 
                echo "<option value=".$row['user_id']." >".$row['user_name']." - (".$row['tipo_usuario'].")</option>";
                } 
            echo "</select>";
            echo "<select id='id_agencia'  name='id_agencia'   class='form-control'>";
            $find=mysqli_query($con,"SELECT user_id,user_name ,
            case tipo_user  when 1 then 'Administrador'  when 2 then 'Banca'  when 3 then 'Taquilla' when 4 then 'Intermediarios' when 5 then 'Agencia'   end as tipo_usuario 
            FROM users  
            WHERE id_admin='$id_vendedor' and tipo_user='5'");
            
            while($row=mysqli_fetch_array($find))
                { 
                echo "<option value=".$row['user_id']." >".$row['user_name']." - (".$row['tipo_usuario'].")</option>";
                } 
            echo "</select>";
        break;
  
    case 5:
        echo "<select id='id_banca' name='id_banca'   class='form-control'>";
        $find=mysqli_query($con,"SELECT user_id,user_name ,
        case tipo_user  when 1 then 'Administrador'  when 2 then 'Banca'  when 3 then 'Taquilla' when 4 then 'Intermediarios' when 5 then 'Agencia'   end as tipo_usuario 
        FROM users  
        WHERE id_admin='$id_vendedor'  and tipo_user='2'");
        
        while($row=mysqli_fetch_array($find))
           { 
           echo "<option value=".$row['user_id']." >".$row['user_name']." - (".$row['tipo_usuario'].")</option>";
           } 
       echo "</select>";
       echo "<select id='id_intermediario'  name='id_intermediario'  class='form-control'>";
            $find=mysqli_query($con,"SELECT user_id,user_name ,
            case tipo_user  when 1 then 'Administrador'  when 2 then 'Banca'  when 3 then 'Taquilla' when 4 then 'Intermediarios' when 5 then 'Agencia'   end as tipo_usuario 
            FROM users  
            WHERE id_admin='$id_vendedor' and tipo_user='4'");
            
            while($row=mysqli_fetch_array($find))
                { 
                echo "<option value=".$row['user_id']." >".$row['user_name']." - (".$row['tipo_usuario'].")</option>";
                } 
            echo "</select>";
      break;
    }
} 
 

?>