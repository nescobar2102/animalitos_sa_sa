<?php
	/*-------------------------
        Descripcion:Sistema de Venta y Control de juegos de azar
		Autor: Ing .Norbelys Naguanagua	 
		Mail: norbelysnaguanagua21@gmail.com
        Version: 1.1       
	---------------------------*/
	include('is_logged.php');//Archivo verifica que el usario que intenta acceder a la URL esta logueado
	/* Connect To Database*/
	require_once ("../config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
	require_once ("../config/conexion.php");//Contiene funcion que conecta a la base de datos
	
	$action = (isset($_REQUEST['action'])&& $_REQUEST['action'] !=NULL)?$_REQUEST['action']:'';	
	
            if($action == 'ajax'){
                  $id_vendedor=$_SESSION['user_id'];
                    // escaping, additionally removing everything that could be (html/javascript-) code
                  $q = mysqli_real_escape_string($con,(strip_tags($_REQUEST['q'], ENT_QUOTES)));
                  $sTable = "facturas,users,comisiones,currencies";
				  $sWhere = "";
					if ($id_vendedor==='1'){              
							$sWhere.="WHERE facturas.id_vendedor=users.user_id and users.user_id=pago_id_vendedor
							  and estado_factura in (1,2,3) and fecha_factura='$q' and facturas.id_moneda=currencies.id GROUP BY facturas.id_moneda,id_vendedor ";										
						} else {	 
							$sWhere.="WHERE facturas.id_vendedor=users.user_id and users.user_id=pago_id_vendedor
							  and users.id_admin='$id_vendedor' and estado_factura in (1,2,3) and fecha_factura='$q' and facturas.id_moneda=currencies.id GROUP BY facturas.id_moneda,id_vendedor ";							
					}
                $fecha=$q;
         		
	//	$sWhere.=" group by id_vendedor ";
		include 'pagination.php'; //include pagination file
		//pagination variables
		$page = (isset($_REQUEST['page']) && !empty($_REQUEST['page']))?$_REQUEST['page']:1;
		$per_page = 10; //how much records you want to show
		$adjacents  = 4; //gap between pages after number of adjacents
		$offset = ($page - 1) * $per_page;
		//Count the total number of row in your table*/
	 
		$count_query   = mysqli_query($con, "SELECT count(*) AS numrows FROM $sTable  $sWhere");
		$row= mysqli_fetch_array($count_query);
		$numrows = $row['numrows'];
		$total_pages = ceil($numrows/$per_page);
		$reload = './ventas.php';
		//main query to fetch the data
	 	$sql=" SELECT id_vendedor,sum(total_venta) as ventas, sum(premio) as premios ,sum(total_venta*comision_terminal/100) as comision,currencies.symbol 
			   FROM  $sTable $sWhere LIMIT $offset,$per_page";
		$query = mysqli_query($con, $sql);
		//loop through fetched data
		if ($numrows>0){
			echo mysqli_error($con);
			?>
                <input value="<?php echo $fecha; ?>" name="fecha" id="fecha" type="hidden">
			<div class="table-responsive">
			  <table class="table">
				<tr  class="info">
					<th>ID</th>
					<th>Nombre</th>					
					<th>Ventas</th>
					<th>Premios</th>
                    <th>Comision</th>					
					<th>Participacion</th>
					<th>Total</th> 
					<th></th>
				</tr>
				<?php						
						$ventast=0;
						$premiost=0;
						$comisiont=0;
						$particit=0;
						$total_venta=0;
				while ($row=mysqli_fetch_array($query)){
						$id_vendedor=$row['id_vendedor'];
						$ventas=$row['ventas'];
                        $premios=$row['premios'];
                        $comision=$row['comision'];	
						$symbol=$row['symbol'];			
                        $total=$ventas-($premios+$comision);
                        
					$sql1="select * from users where user_id=$id_vendedor "; 
					$query1 = mysqli_query($con, $sql1);
					$row1= mysqli_fetch_array($query1);
					$user_name=$row1['user_name'];
                                
					?>
					<tr>
					    	<td><?php echo $id_vendedor; ?></td>
							<td><?php echo $user_name; ?></td>
							<td><?php echo number_format ($ventas,2);  echo " ";echo $symbol;  ?></td>						 
							<td><?php echo number_format ($premios,2);  echo " ";echo $symbol; ?></td>
							<td><?php echo number_format ($comision,2); echo " ";echo $symbol;  ?></td>	
							<td><?php echo number_format ($particit,2); echo " ";echo $symbol;  ?></td>	
							<td><?php echo number_format ($total,2); echo " ";echo $symbol;  ?></td>								
							<td>
								<button type="button" class="btn btn-default" onclick="ver(<?php echo $id_vendedor; ?>)">
								<span></span> Detalle</button>
							</td>	
					</tr>
					<?php							
						$ventast=$ventast+$ventas;
						$premiost=$premiost+$premios;
						$comisiont=$comisiont+$comision;
						$particit=$particit+$particit;
						$total_venta=$total_venta+$total;							
						}
                      ?>
                                       
				<tr>
					<td colspan=8><span class="pull-right"><?php
					 echo paginate($reload, $page, $total_pages, $adjacents);
					?></span></td>
				</tr>
                <!--tr  class="info">
					<th>******</th>                                      
					<th>******</th>					
					<th><?php echo number_format ($ventast,2); ?></th>
					<th><?php echo number_format ($premiost,2); ?></th>
                    <th><?php echo number_format ($comisiont,2); ?></th>					
					<th><?php echo number_format ($particit,2); ?></th>
					<th><?php echo number_format ($total_venta,2); ?></th>  
					<th></th-->                                      
				</tr>
			  </table>
			</div>
			<?php		
                } else { ?>
              
                <div class="alert alert-success alert-dismissible" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<strong>Aviso!</strong> No existen ventas  para la fecha seleccionada.
				</div>
             <?php }  
	}
?>
<script type="text/javascript">
function ver(id){
   var fecha= $('#fecha').val();
window.location="../admin_lotery/ver_ticket.php?id="+id+"&fecha="+fecha;
}
</script>

