﻿<?php
/*-------------------------
    Descripcion:Sistema de Venta y Control de juegos de azar
    Autor: Ing .Norbelys Naguanagua	 
    Mail: norbelysnaguanagua21@gmail.com
    Version: 1.1       
	---------------------------*/
include('is_logged.php');//Archivo verifica que el usario que intenta acceder a la URL esta logueado
// checking for minimum PHP version
if (version_compare(PHP_VERSION, '5.3.7', '<')) {
    exit("Sorry, Simple PHP Login does not run on a PHP version smaller than 5.3.7 !");
} else if (version_compare(PHP_VERSION, '5.5.0', '<')) {
    // if you are using PHP 5.3 or PHP 5.4 you have to include the password_api_compatibility_library.php
    // (this library adds the PHP 5.5 password hashing functions to older versions of PHP)
    require_once("../libraries/password_compatibility_library.php");
}		
		if (empty($_POST['firstname'])){
			$errors[] = "Nombres vacíos";
		} elseif (empty($_POST['lastname'])){
			$errors[] = "Apellidos vacíos";
		} elseif (empty($_POST['tipo_user'])){
			$errors[] = "Tipo de usuario vacio";
		}elseif (empty($_POST['user_name'])) {
            $errors[] = "Nombre de usuario vacío";
        } elseif (empty($_POST['user_password_new']) || empty($_POST['user_password_repeat'])) {
            $errors[] = "Contraseña vacía";
        } elseif ($_POST['user_password_new'] !== $_POST['user_password_repeat']) {
            $errors[] = "la contraseña y la repetición de la contraseña no son lo mismo";
        } elseif (strlen($_POST['user_password_new']) < 6) {
            $errors[] = "La contraseña debe tener como mínimo 6 caracteres";
        } elseif (strlen($_POST['user_name']) > 64 || strlen($_POST['user_name']) < 2) {
            $errors[] = "Nombre de usuario no puede ser inferior a 2 o más de 64 caracteres";
        } elseif (!preg_match('/^[a-z\d]{2,64}$/i', $_POST['user_name'])) {
            $errors[] = "Nombre de usuario no encaja en el esquema de nombre: Sólo aZ y los números están permitidos , de 2 a 64 caracteres"; 
        }elseif (   
			!empty($_POST['user_name'])
			&& !empty($_POST['firstname'])
			&& !empty($_POST['lastname'])
            && strlen($_POST['user_name']) <= 64
            && strlen($_POST['user_name']) >= 2
            && preg_match('/^[a-z\d]{2,64}$/i', $_POST['user_name'])
 
            && !empty($_POST['user_password_new'])
            && !empty($_POST['user_password_repeat'])
            && ($_POST['user_password_new'] === $_POST['user_password_repeat'])
        ) {
            require_once ("../config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
	        require_once ("../config/conexion.php");//Contiene funcion que conecta a la base de datos
			
				// escaping, additionally removing everything that could be (html/javascript-) code
                $firstname = mysqli_real_escape_string($con,(strip_tags($_POST["firstname"],ENT_QUOTES)));
				$lastname = mysqli_real_escape_string($con,(strip_tags($_POST["lastname"],ENT_QUOTES)));
				$user_name = mysqli_real_escape_string($con,(strip_tags($_POST["user_name"],ENT_QUOTES))); 
                 $tipo_user = mysqli_real_escape_string($con,(strip_tags($_POST["tipo_user"],ENT_QUOTES)));
                 $user_password = $_POST['user_password_new'];

                 if(isset($_POST['id_administrador'])){
                    $id_administrador = mysqli_real_escape_string($con,(strip_tags($_POST["id_administrador"],ENT_QUOTES))) ;
                 }else{
                    $id_administrador ='';
                 }
                 
                 if(isset($_POST['id_banca'])){
                    $id_banca = mysqli_real_escape_string($con,(strip_tags($_POST["id_banca"],ENT_QUOTES))) ;
                 }else{
                    $id_banca ='';
                 }
                 
                 if(isset($_POST['id_intermediario'])){
                    $id_intermediario = mysqli_real_escape_string($con,(strip_tags($_POST["id_intermediario"],ENT_QUOTES))) ;
                 }else{
                    $id_intermediario ='';
                 }
                 
                 if(isset($_POST['id_agencia'])){
                    $id_agencia = mysqli_real_escape_string($con,(strip_tags($_POST["id_agencia"],ENT_QUOTES))) ;
                 }else{
                    $id_agencia ='';
                 }
                
                              
		$date_added=date("Y-m-d H:i:s");
                // crypt the user's password with PHP 5.5's password_hash() function, results in a 60 character
                // hash string. the PASSWORD_DEFAULT constant is defined by the PHP 5.5, or if you are using
                // PHP 5.3/5.4, by the password hashing compatibility library
		$user_password_hash = password_hash($user_password, PASSWORD_DEFAULT);
					
                // check if user or email address already exists
                $sql = "SELECT * FROM users WHERE user_name = '" . $user_name . "';";
                $query_check_user_name = mysqli_query($con,$sql);
	        	$query_check_user=mysqli_num_rows($query_check_user_name);
                if ($query_check_user == 1) {
                    $errors[] = "Lo sentimos , el nombre de usuario esta en uso.";
                } else {
                      $id_vendedor=$_SESSION['user_id'];
                      
                      
                        //buscar el admin al que pertenece 
        
                /* $sqLid = "select id_admin  from users  where id_admin='$id_vendedor'  ";
                        $qsql11 = mysqli_query($con, $sqLid);
                        $rw11 = mysqli_fetch_array($qsql11);                   
                        $id_admin = $rw11['id_admin'];*/
                    
                    
					// write new user's data into database
                    $sql = "INSERT INTO users (firstname, lastname, user_name, user_password_hash,  date_added,tipo_user,id_admin)
                            VALUES('".$firstname."','".$lastname."','" . $user_name . "', '" . $user_password_hash . "','".$date_added."','".$tipo_user."','".$id_vendedor."');";
                    $query_new_user_insert = mysqli_query($con,$sql);
                   

                    $sqL1="select LAST_INSERT_ID(user_id) as last from users order by date_added desc limit 0,1  ";
                    $qsql = mysqli_query($con,$sqL1);
                    $rw=mysqli_fetch_array($qsql);
                    $num_usu=$rw['last'];
 

                    if($id_administrador!=''){ 
                        $sql = "UPDATE users SET  id_administrador='".$id_administrador."' WHERE user_id='".$num_usu."'";
                        $query = mysqli_query($con,$sql); 
                      }
                      if($id_banca!=''){  
                            //buscar el admin al que pertenece 
                        $sqLid = "select id_administrador from users  where user_id='$id_banca'  ";
                        $qsql11 = mysqli_query($con, $sqLid);
                        $rw11 = mysqli_fetch_array($qsql11);                   
                       
                        $sql = "UPDATE users SET id_administrador='".$rw11['id_administrador']."',  id_banca='".$id_banca."' WHERE user_id='".$num_usu."'";
                        $query = mysqli_query($con,$sql); 
                      }
                      if($id_intermediario!=''){  
                            //buscar el admin y la banca al que pertenece 
                            $sqLid = "select id_administrador,id_banca from users  where user_id='$id_intermediario'  ";
                            $qsql11 = mysqli_query($con, $sqLid);
                            $rw11 = mysqli_fetch_array($qsql11);      


                        $sql = "UPDATE users SET  id_administrador='".$rw11['id_administrador']."',  id_banca='".$rw11['id_banca']."',  id_intermediario='".$id_intermediario."' WHERE user_id='".$num_usu."'";
                        $query = mysqli_query($con,$sql); 
                      }
                      if($id_agencia!=''){ 
                             //buscar el admin y la banca, id_intermediario,al que pertenece 
                             $sqLid = "select id_administrador,id_banca,id_intermediario from users  where user_id='$id_agencia'  ";
                             $qsql11 = mysqli_query($con, $sqLid);
                             $rw11 = mysqli_fetch_array($qsql11);      
 
                        $sql = "UPDATE users SET  id_administrador='".$rw11['id_administrador']."',  id_banca='".$rw11['id_banca']."',  id_intermediario='".$rw11['id_intermediario']."' ,id_agencia='".$id_agencia."' WHERE user_id='".$num_usu."'";
                        $query = mysqli_query($con,$sql); 
                      }
                   
                    $sql2="INSERT INTO permisos (vender_r, vender, pagar, anular, crear_taquilla, reportes, crear_lot, crear_r, permisos,  user_id) VALUES ('0', '0', '0', '0', '0', '0', '0', '0', '0', '$num_usu');"; 
                    $sqlcomisiones="INSERT INTO comisiones (comision_triple, comision_terminal, pago_triple, pago_terminal, pago_id_vendedor) VALUES ('0', '0', '0', '0', '$num_usu');"; 
                    $query_new_user_insert1 = mysqli_query($con,$sql2);
                    $query_new_user_insert2 = mysqli_query($con,$sqlcomisiones);
                    
                    if ($query_new_user_insert1 && $query_new_user_insert2 && $query_new_user_insert ) {
                        $messages[] = "Usuario creado con éxito.";
                    } else {
                        $errors[] = "Lo sentimos , el registro falló. Por favor, regrese y vuelva a intentarlo.";
                    }
                }
            
            } else {
                $errors[] = "Un error desconocido ocurrió.";
            }
		
		if (isset($errors)){
			
			?>
			<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert">&times;</button>
                                <strong>Error!</strong> 
                                <?php
                                        foreach ($errors as $error) {
                                                        echo $error;
                                                }
                                        ?>
                </div>
			<?php
			}
			if (isset($messages)){
				
				?>
				<div class="alert alert-success" role="alert">
                                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                                    <strong>¡Bien hecho!</strong>
                                    <?php
                                            foreach ($messages as $message) {
                                                            echo $message;
                                                    }
                                            ?>
				</div>
				<?php
			}

?>
