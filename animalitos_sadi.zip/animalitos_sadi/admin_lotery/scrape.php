<?php
session_start();
if (!isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] != 1) {
    header("location: login.php");
    exit;
}

$active_facturas = "active";
$active_productos = "";
$active_clientes = "";
$active_usuarios = "";    
$title = "Nuevo Ticket | Venta";

/* Connect To Database */
require_once ("config/db.php"); // Contiene las variables de configuracion para conectar a la base de datos
require_once ("config/conexion.php"); // Contiene funcion que conecta a la base de datos

// Función para obtener resultados de la lotería
function obtenerResultadosLoteria($url) {
    $html = file_get_contents($url);
    if ($html === FALSE) {
        return "Error al acceder a la página.";
    }

    // Crear un objeto DOMDocument
    $dom = new DOMDocument();
    @$dom->loadHTML($html); // Suprimir advertencias por HTML mal formado

    // Crear un objeto DOMXPath
    $xpath = new DOMXPath($dom);
    
    // Obtener la tabla de resultados
    $resultados = $xpath->query('//table[@class="resultados"]/tbody/tr');

    $datos = [];
    foreach ($resultados as $resultado) {
        // Extraer la hora
          $tds = $resultado->getElementsByTagName('td');       
        
            $hora = $tds->length > 0 ? trim($tds->item(0)->nodeValue) : null;
            $numeroA = $tds->length > 1 ? trim($tds->item(1)->nodeValue) : null;
            $numeroB = $tds->length > 2 ? trim($tds->item(2)->nodeValue) : null;
        
        // Almacenar en el array
        $datos[] = ['HORA:' => $hora, 'A:' => $numeroA, 'B:' => $numeroB];
    }
    return $datos;
}

// URLs de las loterías
$loterias = [
    'Triple Chance' => 'https://loteriadehoy.com/loteria/triplechance/resultados/',
    'Triple Zulia' => 'https://loteriadehoy.com/loteria/triplezulia/resultados/',
    'Triple Táchira' => 'https://loteriadehoy.com/loteria/tripletachira/resultados/',
    'Triple Caracas' => 'https://loteriadehoy.com/loteria/triplecaracas/resultados/',
];

$resultadosLoterias = [];
foreach ($loterias as $nombre => $url) {
    $resultadosLoterias[$nombre] = obtenerResultadosLoteria($url);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("head.php"); ?>
</head>
<body>
    <?php include("navbar.php"); ?>
    <div class="container">
        <div class="panel panel-info">
            <div class="panel-heading">
                <h4><img src="img/iconos/reportes.png" width="30px"> Resultados de Lotería del día</h4>
            </div>
            <div class="panel-body">
                <form class="form-horizontal" role="form" id="datos_factura">
                    <!-- Aquí podrías agregar más formularios si es necesario -->
                </form>
                
                <div id="resultados" class='col-md-12' style="margin-top:10px">
                    <?php foreach ($resultadosLoterias as $nombre => $resultados): ?>
                        <div class="loteria" style="border: 1px solid #ccc; padding: 10px; margin-bottom: 10px;">
                            <h5><?php echo $nombre; ?></h5>
                            <?php if (empty($resultados)): ?>
                                <p>No se encontraron resultados.</p>
                            <?php else: ?>
                                <?php foreach ($resultados as $resultado): ?>
                                <p>
                                    Hora: <strong><?php echo $resultado['HORA:']; ?></strong> -
                                    <strong><?php echo $resultado['A:']; ?></strong> - 
                                    <strong><?php echo $resultado['B:']; ?></strong>
                                </p>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>

            </div>
        </div>
    </div>
    <hr>
    <?php include("footer.php"); ?>
    <link href="css/jquery-ui.css" rel="stylesheet" type="text/css"/>
    <script src="boostrap/jquery-iu.js" type="text/javascript"></script>
</body>
</html>