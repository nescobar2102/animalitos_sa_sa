	<?php
		if (isset($con))
		{
	?>
	<!-- Modal -->
	<div class="modal fade" id="nuevoProducto" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">Agregar nueva Ruleta</h4>
		  </div>
		  <div class="modal-body">
			<form class="form-horizontal" method="post" id="guardar_producto" name="guardar_producto">
			<div id="resultados_ajax_productos"></div>
			  <div class="form-group">
				<label for="codigo" class="col-sm-3 control-label">Código</label>
				<div class="col-sm-8">
				  <input type="text" class="form-control" id="codigo" name="codigo" placeholder="Código" required>
				</div>
			  </div>
			  
			  <div class="form-group">
				<label for="nombre" class="col-sm-3 control-label">Nombre Ruleta</label>
				<div class="col-sm-8">
					<textarea class="form-control" id="nombre" name="nombre" placeholder="Nombre de la Ruleta" required maxlength="255" ></textarea>
				  
				</div>
			  </div>
			  
		 <div class="form-group">
				<label for="estado" class="col-sm-3 control-label">Tipo Ruleta</label>
				<div class="col-sm-8">
                 <select class="form-control" id="estado" name="estado" required>
                     <option value="">-- Seleccionar --</option>
                    <?php
                    $sql_tip_rule=mysqli_query($con,"select * from tipo_ruleta where  status='1'");
                    while ($rw=mysqli_fetch_array($sql_tip_rule)){

                            $tipo_ruleta=$rw["id"];
                             $nombre_tipo_r=$rw["nombre"];

                            ?>
                    <option  value="<?php echo $tipo_ruleta?>"><?php echo $nombre_tipo_r?></option>
                            <?php
                    }
                      ?>
                </select>
                    </div>
		</div>
               
                        <div class="form-group">
				<label for="nombre" class="col-sm-3 control-label">Hora de apertura</label>
				<div class="col-sm-8">
				  <input type="text" class="form-control" id="hinicio" name="hinicio" placeholder="06:00:00" title="Ingresa sólo números con 0 ó 2 decimales" maxlength="10">
				  
				</div>
			  </div>
                        <div class="form-group">
				<label for="nombre" class="col-sm-3 control-label">Hora cierre</label>
				<div class="col-sm-8">
				  <input type="text" class="form-control" id="hcierre" name="hcierre" placeholder="11:59:00" title="Ingresa sólo números con 0 ó 2 decimales" maxlength="10">
				  
				</div>
			  </div>
			 
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
			<button type="submit" class="btn btn-primary" id="guardar_datos">Guardar datos</button>
		  </div>
		  </form>
		</div>
	  </div>
	</div>
	<?php
		}
	?>