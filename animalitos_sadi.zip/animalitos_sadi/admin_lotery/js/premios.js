$(document).ready(function () {
    load(1);

});

function load(page) {
    var q = $("#q").val();
    var sorteo = $("#sorteo").val();
    $("#loader").fadeIn('slow');
    $.ajax({
        url: './ajax/nuevos_premios.php?action=ajax&page=' + page + '&q=' + q + '&sorteo=' + sorteo,
        beforeSend: function (objeto) {
            $('#loader').html('<img src="./img/ajax-loader.gif"> Cargando...');
        },
        success: function (data) {
            $(".outer_div").html(data).fadeIn('slow');
            $('#loader').html('');
            $('[data-toggle="tooltip"]').tooltip({html: true});

        }
    })
}

function eliminar(id, s) {
    var q = $("#q").val();
    if (confirm("¿Estas seguro que desea anular el Ticket?")) {
        $.ajax({
            type: "GET",
            url: "./ajax/nuevos_premios.php",
            // data: "id="+id,"q":q,
            data: "id=" + id + "&s=" + s,
            "q": q,
            beforeSend: function (objeto) {
                $("#resultados").html("Mensaje: Cargando...");
            },
            success: function (datos) {
                $("#resultados").html(datos);
                load(1);
            }
        });
    }
}

function pagarticket(id, s) {
    var q = $("#q").val();
    if (confirm("¿Desea pagar este ticket?")) {
        $.ajax({
            type: "GET",
            url: "./ajax/nuevos_premios.php",
            // data: "id="+id,"q":q,
            data: "id=" + id + "&s=" + s,
            "q": q,
            beforeSend: function (objeto) {
                $("#resultados").html("Mensaje: Cargando...");
            },
            success: function (datos) {
                $("#resultados").html(datos);
                load(1);
            }
        });
    }
}
 
function imprimir_factura(id_factura) {
    VentanaCentrada('./pdf/documentos/imp_factura.php?id_factura=' + id_factura, 'Factura', '', '1024', '768', 'true');
}

 
function ver_ticket(id){ 
    $('.modal-body').load('getTicket.php?id='+id,function(){
        $('#myModal').modal({show:true});
    });
} 