$(document).ready(function(){
        load(0,0);
});

function load(tipo, user_id){ 
    var q= $("#q").val();  
    $("#loader").fadeIn('slow');
    $.ajax({
        url:'./ajax/buscar_usuarios.php?action=ajax&page=1&q='+q+'&tipo='+tipo+'&iduser='+user_id,
        beforeSend: function(objeto){
        $('#loader').html('<img src="./img/ajax-loader.gif"> Cargando...');
        },
        success:function(data){ 
                $(".outer_div").html(data).fadeIn('slow');
                $('#loader').html('');

        }
    });
}
                
function eliminar (id)
    {
    var q= $("#q").val();
    if (confirm("Realmente deseas eliminar el usuario")){	
    $.ajax({
    type: "GET",
    url: "./ajax/buscar_usuarios.php",
    data: "id="+id,"q":q,
             beforeSend: function(objeto){
                    $("#resultados").html("Mensaje: Cargando...");
              },
    success: function(datos){
            $("#resultados").html(datos);
            load(1);
            }
                    });
            }
 }

	       	
function redirect (id)
    {
    window.location="./permisos.php?id="+id;
    }
    
    function limitar (id)
    {
    window.location="./bloqueo.php?id="+id;
    }


		
		
		

