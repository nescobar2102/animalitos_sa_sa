<?php

$numero=345;

$cant = strlen($numero);


$pos=0;
$a=0;
$b=1;
$c=2;
$triple = Array();
$trip=0;


for($x=0;$x<$numero;$x++){
$n[$x] = substr($numero,$x,1);
}


for($y=0;$y<=$cant;$y++){

for($z=0;$z<$cant;$z++){
if($c<$cant){

if($n[$a]!=$n[$b] && $n[$a]!=$n[$c] && $n[$b]!=$n[$c]){
//echo "<script>alert('Si Todos son Diferentes');</script>";
$triple[$pos++] = $n[$a]."".$n[$b]."".$n[$c];
$triple[$pos++] = $n[$a]."".$n[$c]."".$n[$b];
$triple[$pos++] = $n[$b]."".$n[$a]."".$n[$c];
$triple[$pos++] = $n[$b]."".$n[$c]."".$n[$a];
$triple[$pos++] = $n[$c]."".$n[$a]."".$n[$b];
$triple[$pos++] = $n[$c]."".$n[$b]."".$n[$a];

}


if(($n[$a]==$n[$b] && $n[$a]!=$n[$c]) ||
($n[$a]==$n[$c] && $n[$a]!=$n[$b]) ||
($n[$b]==$n[$c] && $n[$a]!=$n[$b])){
//echo "<script>alert(' Sin dos son iguales');</script>";
$triple[$pos++] = $n[$a]."".$n[$b]."".$n[$c];
$triple[$pos++] = $n[$c]."".$n[$a]."".$n[$b];
$triple[$pos++] = $n[$b]."".$n[$c]."".$n[$a];
}
if($n[$a]==$n[$b] && $n[$a]==$n[$c] && $n[$b]==$n[$c]){
//echo "<script>alert(' Todos iguales');</script>";
$triple[$pos++] = $n[$a]."".$n[$b]."".$n[$c];
}
$c++;
}
}
if($b!=$cant-2){
$b++;
$c = $b + 1;
}else{
$a++;
$b = $a + 1;
$c = $b + 1;
}
}



?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>
<title>Sans Titre</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<meta name="generator" content="HAPedit 3.1">
</head>
<body bgcolor="#FFFFFF">
<br><br>

<form action="permuta.php" name="frmPermuta" method="post">
Permuta:
<input type="text" name="txtpermuta" size="20" value="<?php echo $txtpermuta; ?>" tabindex="1"/><br><br>
Monto:
<input type="text" name="txtmonto" size="10" value="<?php echo $txtmonto; ?>" tabindex="2"/><br><br>
<input type="submit" name="btn" value="Permutar" tabindex="3"/>
</form>

<textarea name="txtriples" rows="10" cols="20" readonly>
<?php
for($i=0;$i<=count($triple);$i++){echo $triple[$i]."-";}
?>
</textarea>
<br>
Triples: <input type="text" name="txtCantTrip" value="<?php echo count($triple); ?>" size="20" /><br>
</body>

</html>