<html lang="en">
  <head><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
	<?php  
  require_once ("config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
  require_once ("config/conexion.php");//Contiene funcion que conecta a la base de datos
 // include("head.php");?>
  </head>
  <body>
	<?php
	//include("navbar.php");
	?>  
<?php
 
$user_id=$_POST['user_id'];
$activar=$_POST['activar'];  
if($activar!=""){
    
      $sqlstatus = "UPDATE users SET status='$activar'  WHERE user_id='".$user_id."'";
      $querystatus = mysqli_query($con,$sqlstatus);
      
       if ($querystatus) {
           if($activar=="1"){
                        $messages[] = "Usuario - Taquilla Habilitado.";
           }else{
                    $messages[] = "Usuario - Taquilla Deshabilitado.";
           }
      } else {
          $errors[] = " La actualización falló. Por favor, regrese y vuelva a intentarlo.";
      }
    
} 
foreach ($_POST as $clave=>$valor)
    
    {
    if($valor!=""){

      $sql = "UPDATE permisos SET $clave='".$valor."' WHERE user_id='".$user_id."'";
      $query = mysqli_query($con,$sql);

       }
    }
   if ($query) {
            $messages[] = "Su cambio fue realizado con éxito. Permisos actualizados satisfactoriamente";
        } else {
            $errors[] = " La actualización falló. Por favor, regrese y vuelva a intentarlo.";
        }
            
 
 
		if (isset($errors)){
			
			?>
      
        <div class="container">
            <div class="panel panel">
                <div class="panel-heading">
                      <div class="panel-body">
                        <div class="form-group row">
                            <div class="form-group">
			<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert">&times;</button>
					<strong>Error!</strong> 
					<?php
						foreach ($errors as $error) {
								echo $error;
							}
						?>
			</div>
                            </div>
                        </div>
                      </div>
                </div>
            </div>
        </div>
			<?php
			}
			if (isset($messages)){
				
				?>
      
        <div class="container">
            <div class="panel panel">
                <div class="panel-heading">
                      <div class="panel-body">
                        <div class="form-group row">
                            <div class="form-group">
				<div class="alert alert-success" role="alert">
                                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                                    <strong>¡Bien hecho!</strong>
                                    <?php
                                            foreach ($messages as $message) {
                                                            echo $message;
                                                    }
                                            ?>
				</div>
                            </div>
                        </div>
                </div>
                </div>
            </div>
        </div>
				<?php
			}
 
 
	include("footer.php");
	?>
	 
  </body>
  
<script type="text/javascript">
    function redireccionar() {
     window.history.back();      
    }
   setTimeout("redireccionar()", 2000);
</script>
</html>