<?php
/* -------------------------
  Descripcion:Sistema de Venta y Control de juegos de azar
  Autor: Ing .Norbelys Naguanagua
  Mail: norbelysnaguanagua21@gmail.com
  Version: 1.0
  --------------------------- */
session_start();
if (!isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] != 1) {
    header("location: login.php");
    exit;
}

/* Connect To Database */
require_once ("config/db.php"); //Contiene las variables de configuracion para conectar a la base de datos
require_once ("config/conexion.php"); //Contiene funcion que conecta a la base de datos

$active_facturas = "";
$active_productos = "active";
$active_clientes = "";
$active_usuarios = "";
$title = "Admin |Limites ";
    
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include("head.php"); ?>
    </head>
    <body>
        <?php
        include("navbar.php");
        ?>

        <div class="container">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <div class="btn-group pull-right">
                    </div>
                    <h4><img src="img/iconos/LOTERIA.png" width="25px"> Limites por sorteos</h4>
                </div>
                <div class="panel-body">			
                    <?php
                    include("modal/bloquear_num.php");
                    ?>
                    <form class="form-horizontal" action="nuevo_limites.php" method="post" id="limites" name="guardar_limites">

                        <div class="form-group row">
                            <div class="form-group">
                                <label for="codigo" class="col-sm-1 control-label">Loteria</label>
                                <?php
                                $sqlj = "select * from products where status_producto='1' and status_producto='1'";
                                $queryj = mysqli_query($con, $sqlj);
                                ?>
                                <div class="col-sm-4">
                                    <select class="form-control" id="producto" name="producto" required>
                                        <option value="0">Seleccione</option>
                                        <?php
                                        while ($rowj = mysqli_fetch_array($queryj)) {
                                            echo "<option  value='" . $rowj["id_producto"] . "'>" . $rowj["nombre_producto"] . "</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <input type="hidden" id="usuario" name="usuario" value="<?php echo $_GET["id"]?>" placeholder="9999">

                                <input type="text" id="numero" name="numero" value="" placeholder="9999">
                                <button type="submit" class="btn btn-info" >
                                    Guardar</button>
                                <span id="loader"></span>

                            </div>


                        </div>
                    </form>
                    <div id="resultados"></div><!-- Carga los datos ajax -->
                    <div class='outer_div'></div><!-- Carga los datos ajax -->
                </div>
            </div>

        </div>
        <hr>
        <?php
        include("footer.php");
        ?>
    </body>
</html>  