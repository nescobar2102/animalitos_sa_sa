<?php
	/*-------------------------
    Descripcion:Sistema de Venta y Control de juegos de azar
    Autor: Ing .Norbelys Naguanagua	 
    Mail: norbelysnaguanagua21@gmail.com
    Version: 1.1      
	---------------------------*/
	session_start();
	if (!isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] != 1) {
        header("location: login.php");
		exit;
        }
  $id=$_GET['id'];
                 
	/* Connect To Database*/
	require_once ("config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
	require_once ("config/conexion.php");//Contiene funcion que conecta a la base de datos
	
	$active_facturas="";
	$active_productos="active";
	$active_clientes="";
	$active_usuarios="";	
	$title="Admin | Permisos";
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include("head.php");?>
  </head>
  <body>
	<?php
	include("navbar.php");
	?>
	
    <div class="container">
	<div class="panel panel-info">
		<div class="panel-heading">
    <?php   $id_vendedor=$_SESSION['user_id'];
                          $sql_tip_rule=mysqli_query($con,"select * from users where user_id='$id'");
                          $rw_user=mysqli_fetch_array($sql_tip_rule);
                          $nombre = $rw_user['firstname']." ".$rw_user['lastname']; 
                          $usuario = $rw_user['user_name'];
                          $status=$rw_user["status"];  

                          $sql_tip_permisos=mysqli_query($con,"select * from permisos where user_id='$id'");
                          $rw=mysqli_fetch_array($sql_tip_permisos); 
                          $vender_r=$rw["vender_r"];  
                          $loteria=$rw["vender"];  
                          $pagar=$rw["pagar"];  
                          $anular=$rw["anular"]; 
                          $crear_taquilla=$rw["crear_taquilla"];  
                          $crear_lot=$rw["crear_lot"];  
                          $reportes=$rw["reportes"];  
                          $crear_r=$rw["crear_r"];  
                          $permisos=$rw["permisos"];  
                          $tiempo_anular=$rw["tiempo_anular"]; 

                        ?>  
			<h4> <img src="img/iconos/permisos.png" width="35px">
      Configurar Permisos de <?php  echo $nombre; echo " - "; echo $usuario;?> </h4>
		</div>
		 
		<div class="panel-body">
                    <form class="form-horizontal" role="form" id="datos_cotizacion" action="upd_permisos.php" method="POST">  
                   <h5> Activar - Desactivar Usuarios.</h5> 
			             <div class="col-md-2">
                    
                        <select class="form-control input-sm" id="activar" name="activar" > 
                          <option value="" >Seleccione</option>
                 
                          <option  value="1" <?php if ($status == 1) { echo "selected";  } ?>> Usuario Activo</option>
                          <option  value="2" <?php if ($status == 2) { echo "selected";  } ?>>Usuario Inactivo</option>
                       </select>
                   </div>  
                   <hr>  
                        <input type="hidden" name="user_id" value="<?php echo $id; ?>">
                            <label for="email" class="col-md-2 control-label">Ruleta</label>
                    <div class="col-md-2">
                        <select class="form-control input-sm" id="vender_r" name="vender_r" >
                       <option value="" >Seleccione</option>                    
                    <option  value="0" <?php if ($vender_r == 0) { echo "selected";  } ?>>Desactivo</option>
                    <option  value="1" <?php if ($vender_r == 1) { echo "selected";  } ?>>Activo</option> 
                    
                 </select>
            </div>   
                 <label for="email" class="col-md-2 control-label">Loteria</label>
                    <div class="col-md-2">
                        <select class="form-control input-sm" id="vender" name="vender" >
                       <option value="" >Seleccione</option> 
                 
                   <option  value="0" <?php if ($loteria == 0) { echo "selected";  } ?>>Desactivo</option>
                   <option  value="1" <?php if ($loteria == 1) { echo "selected";  } ?>>Activo</option> 
                   
                </select>
            </div>  
                 <label for="email" class="col-md-2 control-label">Pagar</label>
                    <div class="col-md-2">
                        <select class="form-control input-sm" id="pagar" name="pagar" >
                       <option value="" >Seleccione</option>
                   
                     <option  value="0" <?php if ($pagar == 0) { echo "selected";  } ?>>Desactivo</option>
                     <option  value="1" <?php if ($pagar == 1) { echo "selected";  } ?>>Activo</option> 
                </select>
            </div>  
                  <label for="email" class="col-md-2 control-label">Anular</label>
                    <div class="col-md-2">
                        <select class="form-control input-sm" id="anular" name="anular" >
                       <option value="" >Seleccione</option> 
                       <option  value="0" <?php if ($anular == 0) { echo "selected";  } ?>>Desactivo</option>
                       <option  value="1" <?php if ($anular == 1) { echo "selected";  } ?>>Activo</option>  
                   
                </select>
            </div>  
                                        <label for="email" class="col-md-2 control-label">Crear Taquilla</label>
                    <div class="col-md-2">
                        <select class="form-control input-sm" id="crear_taquilla" name="crear_taquilla" >
                       <option value="" >Seleccione</option> 
                    <option  value="0" <?php if ($crear_taquilla == 0) { echo "selected";  } ?>>Desactivo</option>
                    <option  value="1" <?php if ($crear_taquilla == 1) { echo "selected";  } ?>>Activo</option>  
                   
                </select>
            </div>  
                      <label for="email" class="col-md-2 control-label">Reportes</label>
                    <div class="col-md-2">
                        <select class="form-control input-sm" id="reportes" name="reportes">
                       <option value="" >Seleccione</option> 
                      <option  value="0" <?php if ($reportes == 0) { echo "selected";  } ?>>Desactivo</option>
                      <option  value="1" <?php if ($reportes == 1) { echo "selected";  } ?>>Activo</option>  
                   
                </select>
            </div>  
                    <label for="email" class="col-md-2 control-label">Crear Loteria</label>
                    <div class="col-md-2">
                        <select class="form-control input-sm" id="crear_lot" name="crear_lot" >
                       <option value="" >Seleccione</option> 
                    <option  value="0" <?php if ($crear_lot == 0) { echo "selected";  } ?>>Desactivo</option>
                    <option  value="1" <?php if ($crear_lot == 1) { echo "selected";  } ?>>Activo</option>  
                </select>
            </div>  
                     <label for="email" class="col-md-2 control-label">Config Ruleta</label>
                    <div class="col-md-2">
                        <select class="form-control input-sm" id="crear_r" name="crear_r" >
                       <option value="" >Seleccione</option>
                 
              <option  value="0" <?php if ($crear_r == 0) { echo "selected";  } ?>>Desactivo</option>
              <option  value="1" <?php if ($crear_r == 1) { echo "selected";  } ?>>Activo</option> 
                 
               
                </select>
            </div>  
                                            
              <label for="email" class="col-md-2 control-label">Permisos</label>
              <div class="col-md-2">
                  <select class="form-control input-sm" id="permisos" name="permisos" >
                  <option value="" >Seleccione</option> 
              <option  value="0" <?php if ($permisos == 0) { echo "selected";  } ?>>Desactivo</option>
              <option  value="1" <?php if ($permisos == 1) { echo "selected";  } ?>>Activo</option>
                
          </select>
            </div>  
            <label for="email" class="col-md-2 control-label">Tiempo de anulaciòn</label>
              <div class="col-md-2">
             
              <input class="form-control" type="number" id="tiempo_anular" name="tiempo_anular" value="<?= $tiempo_anular ?>">
            </div>  
                          
                   <div class="col-md-2">
                       <button class=" btn btn-info" onclick="guardar('<?php echo $id_producto; ?>')"> Guardar</button>
                  </div>
                 
			</form>
          
			
  </div>
</div>
		 
	</div>
	<hr>
	<?php
	include("footer.php");
	?>
      
  </body>
</html>
