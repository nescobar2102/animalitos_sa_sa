<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include("head.php");?>
  </head>
<?php
if (isset($_POST['cargar_resultados'])) {
    $url = "https://loteriadehoy.com/loteria/triplechance/resultados/";
    
    // Obtener el contenido de la página
    $html = file_get_contents($url);
    
    if ($html === FALSE) {
        echo "Error al acceder a la página.";
        exit;
    }
    
    // Crear un objeto DOMDocument
    $dom = new DOMDocument();
    @$dom->loadHTML($html); // Suprimir advertencias por HTML mal formado

    // Crear un objeto DOMXPath
    $xpath = new DOMXPath($dom);
    
    // Obtener la tabla de resultados
    $resultados = $xpath->query('//table[@class="resultados"]/tbody/tr'); // Selecciona todas las filas en el cuerpo de la tabla

    if ($resultados->length === 0) {
        echo "No se encontraron resultados.";
    } else {
        foreach ($resultados as $resultado) {
            // Extraer la hora
            $hora = trim($resultado->getElementsByTagName('td')->item(0)->nodeValue); // Primer <td> es la hora
            
            // Extraer los números A y B
            $numeroA = trim($resultado->getElementsByTagName('td')->item(1)->nodeValue); // Segundo <td> es A
            $numeroB = trim($resultado->getElementsByTagName('td')->item(2)->nodeValue); // Tercer <td> es B
            
            // Mostrar los resultados
            echo "Hora: $hora, $numeroA, $numeroB<br>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Scraping Resultados</title>
</head>
<body>
    <form method="post">
        <button type="submit" name="cargar_resultados">Cargar Resultados Chance</button>
    </form>
    <div id="resultados">
        <!-- Aquí se mostrarán los resultados -->
    </div>
</body>
</html>