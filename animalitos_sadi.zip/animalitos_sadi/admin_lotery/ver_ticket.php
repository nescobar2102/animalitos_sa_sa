<?php
	/*-------------------------
        Descripcion:Sistema de Venta y Control de juegos de azar
	Autor: Ing .Norbelys Naguanagua	 
	Mail: norbelysnaguanagua21@gmail.com
        Version: 1.1      
	---------------------------*/ 
		session_start();
	if (!isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] != 1) {
        header("location: login.php");
		exit;
        }
	$active_facturas="active";
	$active_productos="";
	$active_clientes="";
	$active_usuarios="";	
	$title="Admin | Ver Ticket";
	
	/* Connect To Database*/
	require_once ("config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
	require_once ("config/conexion.php");//Contiene funcion que conecta a la base de datos
	
	$id_vendedor=intval($_GET['id']); 
	$fecha=$_GET['fecha'];
                
                       
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include("head.php");?>
  </head>
  <body>
	<?php
	include("navbar.php");
	?>  
    <div class="container">
	<div class="panel panel-info">
		<div class="panel-heading">
			<h4> Listado de Ticket</h4>
		</div>
		<div class="panel-body">
                    <div class="table-responsive">
			  <table class="table">
				<tr  class="info">
					<th>N# Ticket</th>
					<th>Nombre</th>					
					<th>Estado</th>
					<th>Monto</th>
                   <th> </th>
					 
					
				</tr>
		<?php 
                $sql_factura=mysqli_query($con,"select * from facturas where  id_vendedor='".$id_vendedor."' and fecha_factura='$fecha'");
		
                while ($rw_factura=mysqli_fetch_array($sql_factura)){
				$monto=$rw_factura['total_venta'];
				
				$fecha_factura=date("d/m/Y", strtotime($rw_factura['fecha_factura']));
				$condiciones=$rw_factura['condiciones'];
				$estado_factura=$rw_factura['estado_factura'];
				$numero_factura=$rw_factura['numero_factura'];
				$id_moneda=$rw_factura['id_moneda'];
					                         
				$sql_moneda=mysqli_query($con,"select * from currencies where id='$id_moneda'"); //simbolo moneda
				$rw_moneda=mysqli_fetch_array($sql_moneda);
				$simbolo_moneda = $rw_moneda["symbol"];
                $sql1="select * from users where user_id=$id_vendedor "; 
				$query1 = mysqli_query($con, $sql1);
						$row1= mysqli_fetch_array($query1);
						$user_name=$row1['user_name'];
                               
						if ($estado_factura==1){$text_estado="Jugando";$label_class='label-warning';}
                         elseif($estado_factura==0){$text_estado="Anulado";$label_class='label-danger';}
						elseif($estado_factura==2){$text_estado="Pagado";$label_class='label-success';}
						elseif($estado_factura==3){$text_estado="Premiado";$label_class='label-info';}
                        ?>
				
			<tr>
						<td><?php echo $numero_factura; ?></td>
                                                <td><?php echo $user_name; ?></td>
                                              	<td><span class="label <?php echo $label_class;?>"><?php echo $text_estado; ?></span></td>
                                                 <td><?php echo number_format ($monto,2); echo " "; echo $simbolo_moneda; ?></td>						 
                                            
 
					</tr>
                <?php } ?>
                                          </table>
			</div>
                                
		</div>
	</div>		
		 
	</div>
	<hr>
	<?php
	include("footer.php");
	?>
	<script type="text/javascript" src="js/VentanaCentrada.js"></script>
	
        <link href="css/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <script src="boostrap/jquery-iu.js" type="text/javascript"></script>
	

  </body>
</html>