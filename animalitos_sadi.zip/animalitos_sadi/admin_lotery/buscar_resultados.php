<?php
require_once("config/db.php");
require_once("config/conexion.php");

if (isset($_POST['fecha'])) {
    $fecha = mysqli_real_escape_string($con, $_POST['fecha']);

    $sql = mysqli_query($con, "
        SELECT r.*, hj.*
        FROM resultados r
        JOIN hora_jugadas hj ON r.id_horario = hj.id
        WHERE fecha_sorteo = '$fecha'
    ");

    echo '
    <table class="table">
        <tr>
            <th></th>
            <th class="text-left">LOTERIA</th>
            <th class="text-center">HORARIO</th>
            <th class="text-center">NÚMERO</th>
            <th class="text-center">FECHA</th>
            <th></th>
        </tr>';

    while ($row = mysqli_fetch_array($sql)) {
        $id = $row["id"];
        $id_tmp = $row["id_loteria"];
        $numero = $row['numero'];
        $id_signo = $row['id_signo'];
        $fecha_sorteo = $row['fecha_sorteo'];
        $horario = $row['descripcion'];

        $sql2 = mysqli_query($con, "SELECT * FROM products WHERE id_producto = '$id_tmp'");
        $row2 = mysqli_fetch_array($sql2);
        $nombre_lo = $row2['nombre_producto'];

        $sql3 = mysqli_query($con, "SELECT * FROM signo WHERE id = '$id_signo'");
        $row3 = mysqli_fetch_array($sql3);
        $signo = $row3['nombre'];

        echo "
            <tr>
                <td class='text-center'></td>
                <td>$nombre_lo</td>
                <td class='text-center'>$horario</td>
                <td class='text-center' contenteditable='true' onBlur=\"saveToDatabase(this, 'numero', '$id')\" onClick=\"showEdit(this);\">$numero</td>
                <td class='text-center'>$fecha_sorteo</td>
                <td></td>
            </tr>
        ";
    }

    echo "</table>";
}
?>
