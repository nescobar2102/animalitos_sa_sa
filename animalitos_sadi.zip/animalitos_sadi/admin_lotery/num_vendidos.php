<?php
/* -------------------------
  Descripcion:Sistema de Venta y Control de juegos de azar
  Autor: Ing .Norbelys Naguanagua
  Mail: norbelysnaguanagua21@gmail.com
  Version: 1.1
  --------------------------- */
session_start();
if (!isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] != 1) {
    header("location: login.php");
    exit;
}

$active_facturas = "active";
$active_productos = "";
$active_clientes = "";
$active_usuarios = "";
$title = "Números mas Vendidos | Reportes";
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include("head.php"); ?>

    </head>
    <body>
        <?php
        include("navbar.php");
        ?>  
        <div class="container">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <div class="btn-group pull-right">
                    </div>
                    <h4><img src="img/iconos/TICKET VENDIDOS.png" width="30px"> Números mas vendidos</h4>
                </div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" id="datos_cotizacion">

                        <div class="form-group row">
                        <label for="q" class="col-md-1 control-label">Fecha</label>
                        <div class="col-md-2">
                            <input type="text" class="tcal form-control" id="q">
                        </div>
                            <label for="q" class="col-md-2 control-label">Sorteos </label>
                            <?php $sqlsig = "select * from products where status_producto='1' ";
                            $querysig = mysqli_query($con, $sqlsig);
                            ?>
                            <div class="col-md-3">
                                <select id="sorteo" name="sorteo" class="form-control">
                                    <option value="0">Seleccione </option>
                                    <?php
                                    while ($rowsig = mysqli_fetch_array($querysig)) {
                                        echo "<option  value='" . $rowsig["id_producto"] . "'>" . $rowsig["nombre_producto"] . "</option>";
                                    }
                                    ?>
                                </select>
                            </div>

                            <div class="col-md-1"></div>
                            <button type="button" class="btn btn-default" onclick='load(1);'>
                                Buscar</button>
                            <span id="loader"></span>
                        </div>
                    </form>
                </div>
                <div id="resultados"></div><!-- Carga los datos ajax -->
                <div class='outer_div'></div><!-- Carga los datos ajax -->
            </div>
        </div>	
    </div>
    <hr>
<?php
include("footer.php");
?>
    <script type="text/javascript" src="js/VentanaCentrada.js"></script>
    <script type="text/javascript" src="js/num_vend.js"></script>
</body>
</html>