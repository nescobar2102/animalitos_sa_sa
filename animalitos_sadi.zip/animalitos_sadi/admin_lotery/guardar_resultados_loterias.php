<?php
 /* Connect To Database */
require_once ("config/db.php"); //Contiene las variables de configuracion para conectar a la base de datos
require_once ("config/conexion.php"); //Contiene funcion que conecta a la base de datos
 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tipoLoteria = mysqli_real_escape_string($con, $_POST['tipoLoteria']);
    $cantidad = mysqli_real_escape_string($con, $_POST['cantidad']);
    $horario = mysqli_real_escape_string($con, $_POST['horario']); 
     ini_set('date.timezone','America/Caracas');
    $date=  date('Y-m-d');
    // Insertar en la base de datos
    $query = "INSERT INTO resultados (id_loteria, numero, id_signo, id_horario, fecha_sorteo)
                VALUES('$tipoLoteria', '$cantidad', '1', '$horario', '$date')"; 
    
    if (mysqli_query($con, $query)) {
        echo "Resultado guardado.";
    } else {
        echo "Error al guardar: " . mysqli_error($con);
    }
}
?>